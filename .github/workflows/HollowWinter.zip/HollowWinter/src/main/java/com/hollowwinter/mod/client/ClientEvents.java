package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Sadece istemcide: HUD katmanlarini ve varlik gorsellerini kaydeder. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll("cold_frost", ColdOverlay::renderFrost);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "cold_bar", ColdOverlay::renderBar);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.YETI.get(), YetiRenderer::new);
        event.registerEntityRenderer(ModEntities.YETI_SNOW_BLOCK.get(), ThrownItemRenderer::new);
    }
}
