package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, HollowWinter.MODID);

    /** Karda ayak izi (yere yatik iki boyutlu iz). Hizlar: x = yon (radyan), y = boyut carpani. */
    public static final RegistryObject<SimpleParticleType> FOOTPRINT =
            PARTICLES.register("footprint", () -> new SimpleParticleType(true));

    public static void register(IEventBus bus) {
        PARTICLES.register(bus);
    }
}
