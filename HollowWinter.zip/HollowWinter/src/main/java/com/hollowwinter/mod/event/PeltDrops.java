package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

/** Hayvanlar oldurulunce kurk parcasi (pelt) dusurur. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class PeltDrops {

    /** Her oldurmede bir parca fazladan dusme sansi (0.05 = %5). Temel dusus zaten her seferinde kesindir. */
    private static final float EXTRA_PELT_CHANCE = 0.05F;

    /** Hayvan -> en fazla kac pelt dusurur (en az 1). */
    private static final Map<EntityType<?>, Integer> MAX_DROPS = Map.ofEntries(
            Map.entry(EntityType.COW, 2),
            Map.entry(EntityType.MOOSHROOM, 2),
            Map.entry(EntityType.SHEEP, 1),
            Map.entry(EntityType.PIG, 1),
            Map.entry(EntityType.GOAT, 1),
            Map.entry(EntityType.HORSE, 3),
            Map.entry(EntityType.DONKEY, 2),
            Map.entry(EntityType.MULE, 2),
            Map.entry(EntityType.LLAMA, 2),
            Map.entry(EntityType.POLAR_BEAR, 3),
            Map.entry(EntityType.WOLF, 1),
            Map.entry(EntityType.FOX, 1)
    );

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;
        if (entity.isBaby()) return;

        Integer max = MAX_DROPS.get(entity.getType());
        if (max == null) return;

        int count = 1 + entity.getRandom().nextInt(max) + event.getLootingLevel();
        if (entity.getRandom().nextFloat() < EXTRA_PELT_CHANCE) {
            count++; // sansli oldurme: bir parca fazladan
        }
        event.getDrops().add(new ItemEntity(entity.level(),
                entity.getX(), entity.getY(), entity.getZ(),
                new ItemStack(ModItems.PELT.get(), count)));
    }
}
