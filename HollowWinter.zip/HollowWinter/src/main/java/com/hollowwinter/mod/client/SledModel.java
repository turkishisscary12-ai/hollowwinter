package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.SledEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/** Kizak modeli: iki demir kufe, ahsap taban, sirt dayanagi, yan korkuluklar, one kivrik uclar. On = -Z. Doku 128x64. */
public class SledModel extends EntityModel<SledEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowWinter.MODID, "sled"), "main");
    private final ModelPart root;
    private final ModelPart lamp;
    private final ModelPart heater;

    public SledModel(ModelPart root) {
        this.root = root;
        this.lamp = root.getChild("all").getChild("lamp");
        this.heater = root.getChild("all").getChild("heater");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition all = r.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.ZERO);
        // taban
        all.addOrReplaceChild("deck", CubeListBuilder.create().texOffs(0, 0).addBox(-8.0F, 2.0F, -12.0F, 16.0F, 2.0F, 24.0F), PartPose.ZERO);
        // kufeler (yere degen demirler)
        all.addOrReplaceChild("runnerL", CubeListBuilder.create().texOffs(0, 26).addBox(5.0F, 4.0F, -14.0F, 2.0F, 2.0F, 28.0F), PartPose.ZERO);
        all.addOrReplaceChild("runnerR", CubeListBuilder.create().texOffs(0, 26).addBox(-7.0F, 4.0F, -14.0F, 2.0F, 2.0F, 28.0F), PartPose.ZERO);
        // one dogru yukari kivrilan uclar
        all.addOrReplaceChild("curlL", CubeListBuilder.create().texOffs(64, 26).addBox(5.0F, 2.0F, -17.0F, 2.0F, 2.0F, 3.0F).texOffs(64, 26).addBox(5.0F, 0.0F, -18.0F, 2.0F, 2.0F, 3.0F), PartPose.ZERO);
        all.addOrReplaceChild("curlR", CubeListBuilder.create().texOffs(64, 26).addBox(-7.0F, 2.0F, -17.0F, 2.0F, 2.0F, 3.0F).texOffs(64, 26).addBox(-7.0F, 0.0F, -18.0F, 2.0F, 2.0F, 3.0F), PartPose.ZERO);
        // sirt dayanagi
        all.addOrReplaceChild("back", CubeListBuilder.create().texOffs(80, 0).addBox(-8.0F, -4.0F, 10.0F, 16.0F, 6.0F, 2.0F), PartPose.ZERO);
        // yan korkuluklar
        all.addOrReplaceChild("railL", CubeListBuilder.create().texOffs(80, 10).addBox(7.0F, 0.0F, -9.0F, 1.0F, 2.0F, 18.0F), PartPose.ZERO);
        all.addOrReplaceChild("railR", CubeListBuilder.create().texOffs(80, 10).addBox(-8.0F, 0.0F, -9.0F, 1.0F, 2.0F, 18.0F), PartPose.ZERO);
        // on aparatlar: fener ve isitici
        all.addOrReplaceChild("lamp", CubeListBuilder.create().texOffs(96, 32).addBox(-2.0F, -4.0F, -11.0F, 4.0F, 6.0F, 4.0F), PartPose.ZERO);
        all.addOrReplaceChild("heater", CubeListBuilder.create().texOffs(96, 44).addBox(-3.0F, -3.0F, -12.0F, 6.0F, 5.0F, 4.0F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(SledEntity e, float a, float b, float c, float d, float f) {
        lamp.visible = e.getAttachment() == SledEntity.ATTACH_LIGHT;
        heater.visible = e.getAttachment() == SledEntity.ATTACH_HEATER;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer buf, int light, int overlay, float r, float g, float bl, float al) {
        root.render(ps, buf, light, overlay, r, g, bl, al);
    }
}
