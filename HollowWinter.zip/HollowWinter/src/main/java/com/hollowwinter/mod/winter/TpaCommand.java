package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Opsuz teleport istegi:
 *  /tpa <oyuncu>   : istek yollar (60 sn gecerli)
 *  /tpaccept       : gelen istegi kabul eder, isteyen kisi sana isinlanir
 *  /tpdeny         : gelen istegi reddeder
 *  /tpcancel       : yolladigin istegi iptal eder
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class TpaCommand {
    private static final long EXPIRE_TICKS = 20L * 60;
    private static final long COOLDOWN_TICKS = 20L * 5;

    private record Request(UUID from, long time) {}

    /** hedef oyuncu -> bekleyen istek */
    private static final Map<UUID, Request> PENDING = new HashMap<>();
    private static final Map<UUID, Long> LAST_SENT = new HashMap<>();

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("tpa")
                .then(Commands.argument("oyuncu", EntityArgument.player()).executes(TpaCommand::send)));
        event.getDispatcher().register(Commands.literal("tpaccept").executes(ctx -> answer(ctx, true)));
        event.getDispatcher().register(Commands.literal("tpdeny").executes(ctx -> answer(ctx, false)));
        event.getDispatcher().register(Commands.literal("tpcancel").executes(TpaCommand::cancel));
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        PENDING.remove(id);
        PENDING.values().removeIf(r -> r.from().equals(id));
        LAST_SENT.remove(id);
    }

    private static int send(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer from = ctx.getSource().getPlayerOrException();
        ServerPlayer to = EntityArgument.getPlayer(ctx, "oyuncu");
        long now = from.serverLevel().getServer().getTickCount();
        if (from == to) {
            from.sendSystemMessage(Component.literal("Kendine istek atamazsın.").withStyle(ChatFormatting.RED));
            return 0;
        }
        Long last = LAST_SENT.get(from.getUUID());
        if (last != null && now - last < COOLDOWN_TICKS) {
            from.sendSystemMessage(Component.literal("Biraz bekle, çok hızlı istek atıyorsun.").withStyle(ChatFormatting.RED));
            return 0;
        }
        LAST_SENT.put(from.getUUID(), now);
        PENDING.put(to.getUUID(), new Request(from.getUUID(), now));

        from.sendSystemMessage(Component.literal(to.getGameProfile().getName() + " oyuncusuna ışınlanma isteği gönderildi.")
                .withStyle(ChatFormatting.YELLOW));
        MutableComponent msg = Component.literal(from.getGameProfile().getName() + " sana ışınlanmak istiyor. ")
                .withStyle(ChatFormatting.AQUA)
                .append(button("[Kabul]", ChatFormatting.GREEN, "/tpaccept", "Kabul et"))
                .append(Component.literal(" "))
                .append(button("[Reddet]", ChatFormatting.RED, "/tpdeny", "Reddet"));
        to.sendSystemMessage(msg);
        return 1;
    }

    private static MutableComponent button(String text, ChatFormatting color, String cmd, String hover) {
        return Component.literal(text).withStyle(s -> s.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, cmd))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(hover))));
    }

    private static int answer(CommandContext<CommandSourceStack> ctx, boolean accept) throws CommandSyntaxException {
        ServerPlayer target = ctx.getSource().getPlayerOrException();
        Request req = PENDING.remove(target.getUUID());
        long now = target.serverLevel().getServer().getTickCount();
        if (req == null || now - req.time() > EXPIRE_TICKS) {
            target.sendSystemMessage(Component.literal("Bekleyen ışınlanma isteği yok.").withStyle(ChatFormatting.RED));
            return 0;
        }
        ServerPlayer from = target.getServer().getPlayerList().getPlayer(req.from());
        if (from == null) {
            target.sendSystemMessage(Component.literal("İsteği yollayan oyuncu artık oyunda değil.").withStyle(ChatFormatting.RED));
            return 0;
        }
        if (!accept) {
            target.sendSystemMessage(Component.literal("İstek reddedildi.").withStyle(ChatFormatting.YELLOW));
            from.sendSystemMessage(Component.literal(target.getGameProfile().getName() + " ışınlanma isteğini reddetti.")
                    .withStyle(ChatFormatting.RED));
            return 1;
        }
        from.teleportTo(target.serverLevel(), target.getX(), target.getY(), target.getZ(), from.getYRot(), from.getXRot());
        from.fallDistance = 0;
        from.sendSystemMessage(Component.literal(target.getGameProfile().getName() + " isteğini kabul etti, ışınlandın.")
                .withStyle(ChatFormatting.GREEN));
        target.sendSystemMessage(Component.literal("İstek kabul edildi.").withStyle(ChatFormatting.GREEN));
        return 1;
    }

    private static int cancel(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer from = ctx.getSource().getPlayerOrException();
        boolean removed = PENDING.values().removeIf(r -> r.from().equals(from.getUUID()));
        from.sendSystemMessage(Component.literal(removed ? "İstek iptal edildi." : "İptal edilecek istek yok.")
                .withStyle(removed ? ChatFormatting.YELLOW : ChatFormatting.RED));
        return removed ? 1 : 0;
    }
}
