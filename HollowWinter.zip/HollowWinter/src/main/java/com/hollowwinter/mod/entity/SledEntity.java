package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.item.BatteryItem;
import com.hollowwinter.mod.item.HeaterItem;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Objects;

/**
 * Kizak: tekne gibi surulur (W ileri, A/D donus), karda ve buzda iyi kayar, cimde yavas gider, suda batar.
 * On aparat: fener/mesale (gittigin yeri aydinlatir) ya da el isitici (onunu eritir, pil ister).
 * Aparati takmak: elinde tutarak kizaga sag tik. Cikarmak: bos elle egilerek sag tik.
 */
public class SledEntity extends Boat {
    public static final int ATTACH_NONE = 0;
    public static final int ATTACH_LIGHT = 1;
    public static final int ATTACH_HEATER = 2;

    private static final EntityDataAccessor<Integer> ATTACH =
            SynchedEntityData.defineId(SledEntity.class, EntityDataSerializers.INT);

    private ItemStack attachStack = ItemStack.EMPTY;
    private int heaterCharge = 0;
    private BlockPos lightPos = null;

    public SledEntity(EntityType<? extends Boat> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ATTACH, ATTACH_NONE);
    }

    public int getAttachment() {
        return this.entityData.get(ATTACH);
    }

    /** Kizak suda yuzmez, batar. */
    @Override
    public boolean canBoatInFluid(net.minecraft.world.level.material.FluidState state) {
        return false;
    }

    @Override
    public boolean canBoatInFluid(net.minecraftforge.fluids.FluidType type) {
        return false;
    }

    @Override
    public Item getDropItem() {
        return ModItems.SLED.get();
    }

    /** Kar ve buzda surtunme azdir -> kayar. Cimen/toprakta normal (yavas). */
    @Override
    public float getGroundFriction() {
        float f = super.getGroundFriction();
        BlockPos pos = this.blockPosition();
        BlockState below = this.level().getBlockState(pos.below());
        BlockState here = this.level().getBlockState(pos);
        if (below.is(BlockTags.ICE)) return Math.min(f, 0.93F);
        if (here.is(Blocks.SNOW) || below.is(Blocks.SNOW_BLOCK) || below.is(Blocks.SNOW) || below.is(Blocks.POWDER_SNOW)) {
            return Math.max(f, 0.86F);
        }
        return f;
    }

    // ---- Aparat takma / cikarma

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        int kind = getAttachment();

        // Egilerek bos elle: aparati geri al
        if (player.isSecondaryUseActive() && held.isEmpty() && kind != ATTACH_NONE) {
            if (!this.level().isClientSide) {
                ItemStack back = attachStack.copy();
                if (kind == ATTACH_HEATER) HeaterItem.setCharge(back, heaterCharge);
                if (!player.getInventory().add(back)) player.drop(back, false);
                clearAttachment();
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (kind == ATTACH_NONE && !held.isEmpty()) {
            int newKind = ATTACH_NONE;
            if (held.is(Items.LANTERN) || held.is(Items.SOUL_LANTERN) || held.is(Items.TORCH)) newKind = ATTACH_LIGHT;
            else if (held.getItem() instanceof HeaterItem) newKind = ATTACH_HEATER;
            if (newKind != ATTACH_NONE) {
                if (!this.level().isClientSide) {
                    attachStack = held.copyWithCount(1);
                    heaterCharge = newKind == ATTACH_HEATER ? HeaterItem.getCharge(held) : 0;
                    this.entityData.set(ATTACH, newKind);
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.NEUTRAL, 1.0F, 1.0F);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
        }

        // Isitici takili: pil ile sarj et
        if (kind == ATTACH_HEATER && held.getItem() instanceof BatteryItem && !BatteryItem.isDepleted(held)
                && heaterCharge < HeaterItem.MAX_CHARGE) {
            if (!this.level().isClientSide) {
                float fraction = (held.getMaxDamage() - held.getDamageValue()) / (float) held.getMaxDamage();
                heaterCharge = Math.min(HeaterItem.MAX_CHARGE, heaterCharge + Math.round(HeaterItem.TICKS_PER_BATTERY * fraction));
                if (!player.getAbilities().instabuild) held.shrink(1);
                this.level().playSound(null, this.blockPosition(), SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.NEUTRAL, 1.0F, 1.3F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.interact(player, hand);
    }

    private void clearAttachment() {
        attachStack = ItemStack.EMPTY;
        heaterCharge = 0;
        this.entityData.set(ATTACH, ATTACH_NONE);
        clearLight();
    }

    // ---- Her tick: isik ve isitma

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        updateLight();
        if (getAttachment() == ATTACH_HEATER && heaterCharge > 0 && this.getFirstPassenger() != null
                && this.getDeltaMovement().horizontalDistance() > 0.03) {
            heaterCharge--;
            if (this.tickCount % 4 == 0) {
                float yaw = this.getYRot() * Mth.DEG_TO_RAD;
                Vec3 dir = new Vec3(-Mth.sin(yaw), 0.0, Mth.cos(yaw));
                HeaterItem.heatAhead((ServerLevel) this.level(), this.getX(), this.getY(), this.getZ(), dir, 4);
            }
        }
    }

    private void updateLight() {
        BlockPos want = null;
        if (getAttachment() == ATTACH_LIGHT) {
            BlockPos above = this.blockPosition().above();
            BlockPos here = this.blockPosition();
            if (isFreeForLight(above)) want = above;
            else if (isFreeForLight(here)) want = here;
        }
        if (Objects.equals(want, lightPos)) return;
        clearLight();
        if (want != null) {
            this.level().setBlock(want, Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 14), 3);
            lightPos = want;
        }
    }

    private boolean isFreeForLight(BlockPos p) {
        BlockState s = this.level().getBlockState(p);
        return s.isAir() || (lightPos != null && lightPos.equals(p) && s.is(Blocks.LIGHT));
    }

    private void clearLight() {
        if (lightPos != null && this.level().getBlockState(lightPos).is(Blocks.LIGHT)) {
            this.level().setBlock(lightPos, Blocks.AIR.defaultBlockState(), 3);
        }
        lightPos = null;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!this.level().isClientSide) {
            clearLight();
            if ((reason == RemovalReason.KILLED || reason == RemovalReason.DISCARDED) && !attachStack.isEmpty()) {
                ItemStack back = attachStack.copy();
                if (getAttachment() == ATTACH_HEATER) HeaterItem.setCharge(back, heaterCharge);
                attachStack = ItemStack.EMPTY;
                this.spawnAtLocation(back);
            }
        }
        super.remove(reason);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("AttachKind", getAttachment());
        tag.putInt("HeaterCharge", heaterCharge);
        if (!attachStack.isEmpty()) tag.put("AttachItem", attachStack.save(new CompoundTag()));
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(ATTACH, tag.getInt("AttachKind"));
        heaterCharge = tag.getInt("HeaterCharge");
        attachStack = tag.contains("AttachItem") ? ItemStack.of(tag.getCompound("AttachItem")) : ItemStack.EMPTY;
    }
}
