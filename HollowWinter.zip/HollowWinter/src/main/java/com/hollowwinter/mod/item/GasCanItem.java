package com.hollowwinter.mod.item;

import com.hollowwinter.mod.registry.ModBlocks;
import com.hollowwinter.mod.registry.ModFluids;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Benzin kutusu. Bos hali benzin kaynagindan doldurur; dolu hali (1000 birim) makineye yakit olur ya da yere bosaltilir. */
public class GasCanItem extends Item {
    public static final int FUEL_UNITS = 1000;
    private final boolean full;

    public GasCanItem(Properties properties, boolean full) {
        super(properties);
        this.full = full;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!full) {
            BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.SOURCE_ONLY);
            if (hit.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = hit.getBlockPos();
                FluidState fs = level.getFluidState(pos);
                if (fs.isSource() && fs.getType() == ModFluids.GASOLINE.get() && level.mayInteract(player, pos)) {
                    if (!level.isClientSide) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);
                        level.playSound(null, pos, SoundEvents.BUCKET_FILL_LAVA, SoundSource.BLOCKS, 1.0F, 1.0F);
                    }
                    ItemStack filled = new ItemStack(ModItems.GAS_CAN_FULL.get());
                    return InteractionResultHolder.sidedSuccess(ItemUtils.createFilledResult(stack, player, filled),
                            level.isClientSide());
                }
            }
            return InteractionResultHolder.pass(stack);
        }

        // Dolu kutu: baktigin yere benzin dok
        BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.NONE);
        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = hit.getBlockPos().relative(hit.getDirection());
            BlockState existing = level.getBlockState(pos);
            if ((existing.isAir() || existing.canBeReplaced()) && level.mayInteract(player, hit.getBlockPos())) {
                if (!level.isClientSide) {
                    level.setBlock(pos, ModBlocks.GASOLINE_BLOCK.get().defaultBlockState(), 11);
                    level.playSound(null, pos, SoundEvents.BUCKET_EMPTY_LAVA, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                ItemStack empty = new ItemStack(ModItems.GAS_CAN_EMPTY.get());
                return InteractionResultHolder.sidedSuccess(ItemUtils.createFilledResult(stack, player, empty),
                        level.isClientSide());
            }
        }
        return InteractionResultHolder.pass(stack);
    }
}
