package com.hollowwinter.mod.block;

import com.hollowwinter.mod.item.BatteryItem;
import com.hollowwinter.mod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

/**
 * Su isiticisi: suyun yanindaki bloga konur, onundeki buzu eritir. Pilli, 0-15 isi ayarli.
 * Disarida (acik havada, 4. gunden sonra) 1 dakika kalirsa donar ve bozulur.
 */
public class WaterHeaterBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final BooleanProperty RUNNING = BooleanProperty.create("running");
    public static final BooleanProperty FROZEN = BooleanProperty.create("frozen");
    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);

    public WaterHeaterBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH).setValue(RUNNING, false).setValue(FROZEN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, RUNNING, FROZEN);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        // Suyun direk icine konmaz (kenara konur)
        if (!ctx.getLevel().getFluidState(ctx.getClickedPos()).isEmpty()) return null;
        // Oyuncunun baktigi yone uflar
        return this.defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WaterHeaterBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : createTickerHelper(type, ModBlockEntities.WATER_HEATER.get(), WaterHeaterBlockEntity::serverTick);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof WaterHeaterBlockEntity be)) return InteractionResult.PASS;

        if (state.getValue(FROZEN)) {
            player.displayClientMessage(Component.translatable("message.hollowwinter.water_heater_frozen"), true);
            return InteractionResult.CONSUME;
        }

        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof BatteryItem) {
            if (be.insertBattery(held)) {
                level.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 1.0F, 1.2F);
            } else {
                player.displayClientMessage(Component.translatable("message.hollowwinter.water_heater_full"), true);
            }
            return InteractionResult.CONSUME;
        }
        if (held.isEmpty() && be.takeDepleted(player)) {
            level.playSound(null, pos, SoundEvents.ITEM_FRAME_REMOVE_ITEM, SoundSource.BLOCKS, 1.0F, 1.0F);
            return InteractionResult.CONSUME;
        }
        NetworkHooks.openScreen((ServerPlayer) player, be, pos);
        return InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof WaterHeaterBlockEntity be) {
                Containers.dropContents(level, pos, be);
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    /** Calisirken onundeki suya baloncuk uflar (balik tankı hava pompasi gibi). */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource rand) {
        if (!state.getValue(RUNNING)) return;
        Direction d = state.getValue(FACING);
        Direction side = d.getClockWise();
        for (int i = 0; i < 6; i++) {
            double f = 0.7 + rand.nextDouble() * 5.0;
            double s = (rand.nextDouble() - 0.5) * (1.0 + f * 0.5);
            double x = pos.getX() + 0.5 + d.getStepX() * f + side.getStepX() * s;
            double y = pos.getY() - 2.5 + rand.nextDouble() * 3.0;
            double z = pos.getZ() + 0.5 + d.getStepZ() * f + side.getStepZ() * s;
            // Sadece suda gorunur (BubbleParticle sudan cikinca kendini siler)
            level.addParticle(ParticleTypes.BUBBLE, x, y, z, d.getStepX() * 0.05, 0.08, d.getStepZ() * 0.05);
        }
        // Namlu cikisinda hava baloncuklari
        level.addParticle(ParticleTypes.BUBBLE_POP, pos.getX() + 0.5 + d.getStepX() * 0.6,
                pos.getY() + 0.45, pos.getZ() + 0.5 + d.getStepZ() * 0.6, 0.0, 0.02, 0.0);
        if (rand.nextInt(12) == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.BLOCKS, 0.4F, 1.0F, false);
        }
    }
}
