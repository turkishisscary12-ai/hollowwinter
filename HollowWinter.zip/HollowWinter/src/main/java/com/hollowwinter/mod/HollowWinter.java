package com.hollowwinter.mod;

import com.hollowwinter.mod.network.ModNetwork;
import com.hollowwinter.mod.registry.ModBlockEntities;
import com.hollowwinter.mod.registry.ModBlocks;
import com.hollowwinter.mod.registry.ModMenus;
import com.hollowwinter.mod.registry.ModCreativeTabs;
import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(HollowWinter.MODID)
public class HollowWinter {
    public static final String MODID = "hollowwinter";
    public static final Logger LOGGER = LogUtils.getLogger();

    public HollowWinter() {
        LOGGER.info("Hollow Winter yukleniyor... Kis basliyor.");
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(modBus);
        ModItems.register(modBus);
        ModCreativeTabs.register(modBus);
        ModEntities.register(modBus);
        ModSounds.register(modBus);
        ModBlockEntities.register(modBus);
        ModMenus.register(modBus);
        com.hollowwinter.mod.registry.ModFluidTypes.register(modBus);
        com.hollowwinter.mod.registry.ModFluids.register(modBus);
        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ModNetwork::register);
    }
}
