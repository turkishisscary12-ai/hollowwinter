package com.hollowwinter.mod.network;

import com.hollowwinter.mod.client.ClientFogData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucu -> Istemci: kar firtinasi gorsellerini (sis, savrulan kar) ac / kapat. */
public class StormPacket {
    private final boolean on;

    public StormPacket(boolean on) {
        this.on = on;
    }

    public static void encode(StormPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.on);
    }

    public static StormPacket decode(FriendlyByteBuf buf) {
        return new StormPacket(buf.readBoolean());
    }

    public static void handle(StormPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ClientFogData.setStormTarget(msg.on ? 1.0F : 0.0F);
    }
}
