package com.hollowwinter.mod.item;

import com.hollowwinter.mod.winter.HeatZones;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * El tipi isi makinesi. Sag tik basili tutulunca oyuncunun baktigi yondeki kari yavas yavas eritir ve
 * 3 genis / 3 yuksek, oyuncunun rahatca gecebilecegi bir gecit acar (kar ne kadar yuksek olursa olsun).
 * Gecit her ~0.5 saniyede 1 blok ilerler. Isittigi sutunlarda 2 saniye boyunca kar birikmez.
 */
public class HeaterItem extends Item {
    private static final int RANGE = 12;            // en fazla gecit uzunlugu
    private static final int RUN_INTERVAL = 10;     // tick: gecit bu surede 1 blok ilerler
    private static final int HEAT_TICKS = 40;       // 2 saniye
    private static final int HALF_WIDTH = 1;        // 3 genis
    private static final int HEIGHT = 3;            // 3 yuksek

    /** Her oyuncu icin gecidin ulastigi mesafe. */
    private static final Map<UUID, Integer> FRONT = new HashMap<>();

    public HeaterItem(Properties properties) {
        super(properties);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        FRONT.remove(entity.getUUID());
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel server)) return;
        int used = getUseDuration(stack) - remaining;

        Direction dir = entity.getDirection();
        Direction side = dir.getClockWise();
        BlockPos origin = entity.blockPosition();

        // Her tick isitilan sutunlari kar birikmesine karsi isaretle
        int reach = FRONT.getOrDefault(entity.getUUID(), 1);
        long now = server.getGameTime();
        for (int d = 1; d <= Math.min(RANGE, reach + 1); d++) {
            for (int l = -HALF_WIDTH; l <= HALF_WIDTH; l++) {
                int x = origin.getX() + dir.getStepX() * d + side.getStepX() * l;
                int z = origin.getZ() + dir.getStepZ() * d + side.getStepZ() * l;
                HeatZones.mark(x, z, now + HEAT_TICKS);
            }
        }

        if (used % 10 == 0) {
            server.playSound(null, origin, SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.6F, 0.8F);
        }
        if (used % RUN_INTERVAL != 0) return;

        // Onceki katmanlar zaten aciksa hizlica atla, kar olan ilk katmani yavasca erit
        for (int guard = 0; guard < 6 && reach <= RANGE; guard++) {
            LayerResult r = meltLayer(server, origin, dir, side, reach);
            if (r == LayerResult.BLOCKED) break;
            reach++;
            if (r == LayerResult.MELTED) break;
        }
        FRONT.put(entity.getUUID(), reach);
        HeatZones.cleanup(now);
    }

    private enum LayerResult { MELTED, EMPTY, BLOCKED }

    /** Bir enine kesiti (3x3) eritir. */
    private static LayerResult meltLayer(ServerLevel level, BlockPos origin, Direction dir, Direction side, int d) {
        boolean melted = false;
        for (int l = -HALF_WIDTH; l <= HALF_WIDTH; l++) {
            for (int dy = 0; dy < HEIGHT; dy++) {
                BlockPos p = origin.relative(dir, d).relative(side, l).above(dy);
                if (!level.hasChunkAt(p)) return LayerResult.BLOCKED;
                BlockState s = level.getBlockState(p);
                if (isSnow(s)) {
                    level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                    melted = true;
                    if (level.getRandom().nextInt(3) == 0) {
                        level.sendParticles(ParticleTypes.CLOUD, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 2, 0.3, 0.3, 0.3, 0.01);
                    }
                }
            }
        }
        if (melted) return LayerResult.MELTED;

        // Kar yoksa: ortadaki hucrelerde sert (kar olmayan) blok varsa gecit ilerlemez
        for (int dy = 0; dy < 2; dy++) {
            BlockPos p = origin.relative(dir, d).above(dy);
            BlockState s = level.getBlockState(p);
            if (!s.getCollisionShape(level, p).isEmpty()) return LayerResult.BLOCKED;
        }
        return LayerResult.EMPTY;
    }

    private static boolean isSnow(BlockState s) {
        return s.is(Blocks.SNOW) || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.hollowwinter.heater.tooltip"));
    }
}
