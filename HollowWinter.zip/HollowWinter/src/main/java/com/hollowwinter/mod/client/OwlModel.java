package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.OwlEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Baykus modeli: dik oturan govde, genis kafa (kulak tuyleri, yuz diski, gaga), katlanmis kanatlar. Doku 64x32. */
public class OwlModel extends EntityModel<OwlEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowWinter.MODID, "owl"), "main");

    private final ModelPart all;
    private final ModelPart head;
    private final ModelPart wingL;
    private final ModelPart wingR;

    public OwlModel(ModelPart root) {
        this.all = root.getChild("all");
        this.head = all.getChild("head");
        this.wingL = all.getChild("wingL");
        this.wingR = all.getChild("wingR");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition all = root.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));
        all.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -6.0F, -2.5F, 6.0F, 10.0F, 5.0F),
                PartPose.offset(0.0F, -5.0F, 0.0F));
        PartDefinition head = all.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 15).addBox(-3.5F, -6.0F, -3.0F, 7.0F, 6.0F, 6.0F),
                PartPose.offset(0.0F, -11.0F, 0.0F));
        head.addOrReplaceChild("tuftL", CubeListBuilder.create().texOffs(40, 0).addBox(1.5F, -8.0F, -2.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        head.addOrReplaceChild("tuftR", CubeListBuilder.create().texOffs(40, 0).addBox(-3.5F, -8.0F, -2.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        head.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(48, 0).addBox(-0.5F, -3.0F, -4.0F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
        all.addOrReplaceChild("wingL", CubeListBuilder.create().texOffs(28, 0).addBox(0.0F, 0.0F, -2.0F, 1.0F, 8.0F, 5.0F),
                PartPose.offset(3.0F, -10.0F, 0.0F));
        all.addOrReplaceChild("wingR", CubeListBuilder.create().texOffs(28, 0).addBox(-1.0F, 0.0F, -2.0F, 1.0F, 8.0F, 5.0F),
                PartPose.offset(-3.0F, -10.0F, 0.0F));
        all.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(28, 14).addBox(-2.5F, 0.0F, 0.0F, 5.0F, 1.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, -3.0F, 2.5F, 0.5F, 0.0F, 0.0F));
        all.addOrReplaceChild("footL", CubeListBuilder.create().texOffs(46, 14).addBox(-2.5F, 0.0F, -1.0F, 5.0F, 1.0F, 2.0F),
                PartPose.offset(1.5F, -1.0F, -0.5F));
        all.addOrReplaceChild("footR", CubeListBuilder.create().texOffs(46, 14).addBox(-2.5F, 0.0F, -1.0F, 5.0F, 1.0F, 2.0F),
                PartPose.offset(-1.5F, -1.0F, -0.5F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(OwlEntity entity, float limbSwing, float limbSwingAmount, float age,
                          float netHeadYaw, float headPitch) {
        // Baykus boynu cok dondurur
        head.yRot = Mth.clamp(netHeadYaw * 1.6F, -135.0F, 135.0F) * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        if (entity.isNoGravity()) {
            // ucarken kanat cirpar
            float flap = Mth.sin(age * 1.4F) * 0.7F;
            wingL.zRot = -(0.9F + flap);
            wingR.zRot = 0.9F + flap;
            all.xRot = 0.5F;
        } else {
            wingL.zRot = -0.05F;
            wingR.zRot = 0.05F;
            all.xRot = 0.0F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        all.render(poseStack, buffer, light, overlay, r, g, b, a);
    }
}
