package com.hollowwinter.mod.network;

import com.hollowwinter.mod.client.ClientFrozenData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucu -> Istemci: bu varlik donmus (buzlu gorunum). */
public class FrozenMobPacket {
    private final int entityId;

    public FrozenMobPacket(int entityId) {
        this.entityId = entityId;
    }

    public static void encode(FrozenMobPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
    }

    public static FrozenMobPacket decode(FriendlyByteBuf buf) {
        return new FrozenMobPacket(buf.readVarInt());
    }

    public static void handle(FrozenMobPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ClientFrozenData.add(msg.entityId);
    }
}
