package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, HollowWinter.MODID);

    public static final RegistryObject<SoundEvent> CHASE_MUSIC = SOUNDS.register("chase_music",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(HollowWinter.MODID, "chase_music")));

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
    }
}
