package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Cay yapragi ocakta yakit slotuna konur: tam bir bardak cay pisirecek kadar (200 tick) yanar. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class FuelEvents {
    /** Cay yapragi yanma suresi: 200 tick pisirme + 3. Bu ozel sayi, ocagin cay yapragiyla yandigini ayirt etmek icin kullanilir. */
    public static final int TEA_BURN_TIME = 203;

    @SubscribeEvent
    public static void onFuel(FurnaceFuelBurnTimeEvent event) {
        if (event.getItemStack().is(ModItems.TEA_LEAVES.get())) {
            event.setBurnTime(TEA_BURN_TIME);
        }
    }
}
