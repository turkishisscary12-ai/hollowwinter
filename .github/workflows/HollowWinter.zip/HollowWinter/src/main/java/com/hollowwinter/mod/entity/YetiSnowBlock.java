package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.cold.ColdHandler;
import com.hollowwinter.mod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Yeti'nin firlattigi kar blogu.
 *  - Oyuncuya carparsa: 0.5 can hasar (ceyrek kalp) ve +10 soguk (%10 donma).
 *  - pile = true ise bir yere carpinca onune kar blogu yigini (engel) birakir (kovalamacada kullanilir).
 */
public class YetiSnowBlock extends ThrowableItemProjectile {

    private static final float DAMAGE = 0.5F;
    private static final float COLD = 10.0F;

    private boolean pileOnImpact = false;

    public YetiSnowBlock(EntityType<? extends YetiSnowBlock> type, Level level) {
        super(type, level);
    }

    public YetiSnowBlock(Level level, LivingEntity shooter) {
        super(ModEntities.YETI_SNOW_BLOCK.get(), shooter, level);
    }

    public void setPileOnImpact(boolean pile) {
        this.pileOnImpact = pile;
    }

    @Override
    protected Item getDefaultItem() {
        return Items.SNOW_BLOCK;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!this.level().isClientSide && result.getEntity() instanceof ServerPlayer player) {
            float safe = Math.min(DAMAGE, player.getHealth() - 1.0F); // olumcul olmasin
            if (safe > 0.0F) player.hurt(this.damageSources().thrown(this, this.getOwner()), safe);
            ColdHandler.addCold(player, COLD);
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (this.level().isClientSide) return;

        if (pileOnImpact && result.getType() == HitResult.Type.BLOCK) {
            placePile((BlockHitResult) result);
        }
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY(), getZ(), 14, 0.25, 0.25, 0.25, 0.05);
            server.playSound(null, blockPosition(), SoundEvents.SNOW_BREAK, SoundSource.HOSTILE, 1.0F, 0.9F);
        }
        this.discard();
    }

    /** Carpilan yerin onune kar blogu yigini: ortada 3 blok, etrafinda 2 blok yukseklik. */
    private void placePile(BlockHitResult hit) {
        BlockPos base = hit.getBlockPos().relative(hit.getDirection());
        BlockState snow = Blocks.SNOW_BLOCK.defaultBlockState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (Math.abs(dx) + Math.abs(dz) > 1) continue; // arti sekli
                int height = (dx == 0 && dz == 0) ? 3 : 2;
                for (int dy = 0; dy < height; dy++) {
                    BlockPos p = base.offset(dx, dy, dz);
                    BlockState existing = this.level().getBlockState(p);
                    if (existing.isAir() || existing.canBeReplaced()) {
                        this.level().setBlockAndUpdate(p, snow);
                    }
                }
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("PileOnImpact", pileOnImpact);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        pileOnImpact = tag.getBoolean("PileOnImpact");
    }
}
