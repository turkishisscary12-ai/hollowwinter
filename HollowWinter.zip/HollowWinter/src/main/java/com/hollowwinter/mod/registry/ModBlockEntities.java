package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.block.WaterHeaterBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, HollowWinter.MODID);

    public static final RegistryObject<BlockEntityType<WaterHeaterBlockEntity>> WATER_HEATER =
            BLOCK_ENTITIES.register("water_heater", () ->
                    BlockEntityType.Builder.of(WaterHeaterBlockEntity::new, ModBlocks.WATER_HEATER.get()).build(null));

    public static final RegistryObject<BlockEntityType<com.hollowwinter.mod.block.MinerBlockEntity>> MINER =
            BLOCK_ENTITIES.register("miner", () ->
                    BlockEntityType.Builder.of(com.hollowwinter.mod.block.MinerBlockEntity::new, ModBlocks.MINER.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }
}
