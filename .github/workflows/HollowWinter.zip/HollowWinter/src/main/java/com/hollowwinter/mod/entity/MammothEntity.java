package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * Mamut: 9. gunden sonra karli yuzeyde suruler halinde dogar. Yavrusu vardir (bebek, 0.5 boyut).
 * Birbirlerine saldirmaz (suru). Dusman yaratiklara (Monster) saldirir; oyuncuya ancak vurulursa karsilik verir
 * ve tum suru birlikte savunur. Meyve / bugday ile beslenip ureyebilir.
 */
public class MammothEntity extends Animal {
    public static final int SPAWN_DAY = 9;
    private static final float BABY_CHANCE = 0.25F;

    public MammothEntity(EntityType<? extends MammothEntity> type, Level level) {
        super(type, level);
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createLivingAttributes()
                .add(Attributes.MAX_HEALTH, 70.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.6D) {
            @Override
            public boolean canUse() {
                return MammothEntity.this.isBaby() && super.canUse(); // sadece yavru kacar
            }
        });
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, true));
        this.goalSelector.addGoal(3, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new TemptGoal(this, 1.1D,
                Ingredient.of(Items.WHEAT, Items.SWEET_BERRIES, ModItems.STRAWBERRY.get()), false));
        this.goalSelector.addGoal(5, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, net.minecraft.world.entity.player.Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        // Vurulursa karsilik ver (suru arkadaslarina vurmak sayilmaz), suruyu cagir
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, MammothEntity.class).setAlertOthers());
        // Yetiskin mamutlar dusman yaratiklara saldirir (hayalet/kovalamaca yetilerine degil)
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, 10, true, false,
                (LivingEntity target) -> !(target instanceof YetiEntity yeti) || yeti.getMode() == YetiEntity.MODE_NORMAL) {
            @Override
            public boolean canUse() {
                return !MammothEntity.this.isBaby() && super.canUse();
            }
        });
    }

    // ---- Dogus / bebek

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable net.minecraft.nbt.CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        if (reason == MobSpawnType.NATURAL || reason == MobSpawnType.CHUNK_GENERATION) {
            if (this.getRandom().nextFloat() < BABY_CHANCE) {
                this.setAge(-24000);
            }
        }
        return result;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        return ModEntities.MAMMOTH.get().create(level);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.WHEAT) || stack.is(Items.SWEET_BERRIES) || stack.is(ModItems.STRAWBERRY.get());
    }

    /** Bebek hitbox'i yarim boyut. */
    @Override
    public EntityDimensions getDimensions(Pose pose) {
        EntityDimensions dims = this.getType().getDimensions();
        return this.isBaby() ? dims.scale(0.5F) : dims;
    }

    /** Dogal dogma kurali: 9. gunden sonra, acik havada, karli/sert zeminde. */
    public static boolean checkSpawn(EntityType<MammothEntity> type, ServerLevelAccessor level, MobSpawnType reason,
                                     BlockPos pos, RandomSource random) {
        ServerLevel sl = level.getLevel();
        if (sl.dimension() != Level.OVERWORLD) return false;
        if (WinterManager.daysSinceOrigin(sl) < SPAWN_DAY) return false;
        if (!SnowSurface.exposed(sl, pos)) return false;
        BlockState below = level.getBlockState(pos.below());
        return !below.isAir() && below.getFluidState().isEmpty();
    }

    // ---- Sesler (vanilla Ravager sesleri, alcak perde)

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.RAVAGER_STEP, 0.5F, 0.7F);
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.75F;
    }
}
