package com.hollowwinter.mod.item;

import com.hollowwinter.mod.winter.HeatZones;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * El tipi isi makinesi. Sag tik basili tutulunca oyuncunun baktigi yondeki kari yavas yavas eritir ve
 * 3 genis / 3 yuksek, oyuncunun rahatca gecebilecegi bir gecit acar (kar ne kadar yuksek olursa olsun).
 * Gecit her ~0.5 saniyede 1 blok ilerler. Isittigi sutunlarda 2 saniye boyunca kar birikmez.
 */
public class HeaterItem extends Item {
    private static final int RANGE = 12;            // en fazla gecit uzunlugu
    private static final int RUN_INTERVAL = 10;     // tick: gecit bu surede 1 blok ilerler
    private static final int HEAT_TICKS = 40;       // 2 saniye
    private static final int HALF_WIDTH = 1;        // 3 genis
    private static final int HEIGHT = 3;            // 3 yuksek

    /** Pil: 1 pil = 2 dakika surekli kullanim (2400 tick), en fazla 2 pil (4 dk). Sarj item NBT'sinde (Charge). */
    public static final int TICKS_PER_BATTERY = 2400;
    public static final int MAX_CHARGE = TICKS_PER_BATTERY * 2;
    private static final String CHARGE_KEY = "Charge";

    public static int getCharge(ItemStack stack) {
        return stack.hasTag() ? stack.getTag().getInt(CHARGE_KEY) : 0;
    }

    public static void setCharge(ItemStack stack, int value) {
        stack.getOrCreateTag().putInt(CHARGE_KEY, Math.max(0, Math.min(MAX_CHARGE, value)));
    }

    /** Envanterden en fazla 2 dolu pil alip makineye takar. Takilan pil sayisini dondurur. */
    private static int loadBatteries(Player player, ItemStack heater) {
        int loaded = 0;
        int gained = 0;
        for (int pass = 0; pass < 2; pass++) {
            ItemStack battery = ItemStack.EMPTY;
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                ItemStack s = player.getInventory().getItem(i);
                if (s.getItem() instanceof BatteryItem && !BatteryItem.isDepleted(s)) {
                    battery = s;
                    break;
                }
            }
            if (battery.isEmpty()) break;
            float fraction = (battery.getMaxDamage() - battery.getDamageValue()) / (float) battery.getMaxDamage();
            gained += Math.round(TICKS_PER_BATTERY * fraction);
            battery.shrink(1);
            loaded++;
        }
        if (loaded > 0) setCharge(heater, getCharge(heater) + gained);
        return loaded;
    }

    /** Sarj her tick degistigi icin yeniden kaldirma animasyonu oynamasin. */
    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return getCharge(stack) > 0;
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        return Math.round(13.0F * getCharge(stack) / MAX_CHARGE);
    }

    @Override
    public int getBarColor(ItemStack stack) {
        return 0xFF8A2B;
    }

    /** Her oyuncu icin gecidin ulastigi mesafe. */
    private static final Map<UUID, Integer> FRONT = new HashMap<>();

    public HeaterItem(Properties properties) {
        super(properties);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (getCharge(stack) <= 0) {
            // Pil bitti: sag tikla envanterdeki 1-2 pili tak
            if (!level.isClientSide) {
                int loaded = loadBatteries(player, stack);
                if (loaded > 0) {
                    level.playSound(null, player.blockPosition(), SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.PLAYERS, 1.0F, 1.2F);
                    player.displayClientMessage(Component.translatable("message.hollowwinter.heater_loaded", loaded), true);
                } else {
                    player.displayClientMessage(Component.translatable("message.hollowwinter.heater_no_battery"), true);
                }
            }
            return InteractionResultHolder.consume(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        FRONT.remove(entity.getUUID());
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel server)) return;
        int used = getUseDuration(stack) - remaining;

        // Pil tuketimi: her tick 1
        int charge = getCharge(stack) - 1;
        setCharge(stack, charge);
        if (charge <= 0) {
            FRONT.remove(entity.getUUID());
            entity.stopUsingItem();
            if (entity instanceof Player p) {
                p.displayClientMessage(Component.translatable("message.hollowwinter.heater_empty"), true);
            }
            return;
        }

        net.minecraft.world.phys.Vec3 look = entity.getLookAngle();
        // Yukari/asagi bakiyorsa tunel bakilan yone gider; duz bakiyorsa ayaktan 3 yuksek gecit acilir
        boolean vertical = Math.abs(look.y) > 0.5;

        // Her tick isitilan sutunlari kar birikmesine karsi isaretle
        int reach = FRONT.getOrDefault(entity.getUUID(), 1);
        long now = server.getGameTime();
        for (int d = 1; d <= Math.min(RANGE, reach + 1); d++) {
            BlockPos c = center(entity, look, d);
            for (int dx = -HALF_WIDTH; dx <= HALF_WIDTH; dx++) {
                for (int dz = -HALF_WIDTH; dz <= HALF_WIDTH; dz++) {
                    HeatZones.mark(c.getX() + dx, c.getZ() + dz, now + HEAT_TICKS);
                }
            }
        }

        if (used % 10 == 0) {
            server.playSound(null, entity.blockPosition(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 0.6F, 0.8F);
        }
        if (used % RUN_INTERVAL != 0) return;

        // Onceki katmanlar zaten aciksa hizlica atla, kar olan ilk katmani yavasca erit
        for (int guard = 0; guard < 6 && reach <= RANGE; guard++) {
            LayerResult r = meltLayer(server, center(entity, look, reach), vertical);
            if (r == LayerResult.BLOCKED) break;
            reach++;
            if (r == LayerResult.MELTED) break;
        }
        FRONT.put(entity.getUUID(), reach);
        HeatZones.cleanup(now);
    }

    private static BlockPos center(LivingEntity e, net.minecraft.world.phys.Vec3 look, int d) {
        return BlockPos.containing(e.getX() + look.x * d, e.getY() + 0.1 + look.y * d, e.getZ() + look.z * d);
    }

    /** Kizaga takili isitici: x,y,z'den dir yonunde reach blok oncesini (3 genis, 3 yuksek) eritir. */
    public static void heatAhead(ServerLevel level, double x, double y, double z, net.minecraft.world.phys.Vec3 dir, int reach) {
        long now = level.getGameTime();
        for (int d = 1; d <= reach; d++) {
            BlockPos c = BlockPos.containing(x + dir.x * d, y + 0.1, z + dir.z * d);
            for (int dx = -HALF_WIDTH; dx <= HALF_WIDTH; dx++) {
                for (int dz = -HALF_WIDTH; dz <= HALF_WIDTH; dz++) {
                    HeatZones.mark(c.getX() + dx, c.getZ() + dz, now + HEAT_TICKS);
                }
            }
            meltLayer(level, c, false);
        }
        HeatZones.cleanup(now);
    }

    private enum LayerResult { MELTED, EMPTY, BLOCKED }

    /** Bir merkez etrafinda 3x3x3 (duz bakista 3x3, 0..+2 yukseklik) kari eritir. */
    private static LayerResult meltLayer(ServerLevel level, BlockPos c, boolean vertical) {
        boolean melted = false;
        int y0 = vertical ? -1 : 0;
        int y1 = vertical ? 1 : 2;
        for (int dx = -HALF_WIDTH; dx <= HALF_WIDTH; dx++) {
            for (int dz = -HALF_WIDTH; dz <= HALF_WIDTH; dz++) {
                for (int dy = y0; dy <= y1; dy++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p)) return LayerResult.BLOCKED;
                    BlockState s = level.getBlockState(p);
                    if (isSnow(s)) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                        melted = true;
                        if (level.getRandom().nextInt(3) == 0) {
                            level.sendParticles(ParticleTypes.CLOUD, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5, 2, 0.3, 0.3, 0.3, 0.01);
                        }
                    }
                }
            }
        }
        if (melted) return LayerResult.MELTED;

        // Kar yoksa: merkezde sert (kar olmayan) blok varsa gecit ilerlemez
        for (int dy = 0; dy < 2; dy++) {
            BlockPos p = c.above(dy);
            BlockState s = level.getBlockState(p);
            if (!s.getCollisionShape(level, p).isEmpty()) return LayerResult.BLOCKED;
        }
        return LayerResult.EMPTY;
    }

    private static boolean isSnow(BlockState s) {
        return s.is(Blocks.SNOW) || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.hollowwinter.heater.tooltip"));
        int pct = Math.round(100.0F * getCharge(stack) / MAX_CHARGE);
        tooltip.add(Component.translatable("item.hollowwinter.battery.charge", pct)
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
