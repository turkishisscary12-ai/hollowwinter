package com.hollowwinter.mod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/**
 * Soguk HUD'u:
 *  - renderBar : hotbar'in ustunde, ortada soguk cubugu (kar tanesi ikonu, yuzde, isinma/soguma oku).
 *  - renderFrost: soguk yuksekken ekran kenarlarinda buzlanma.
 */
public class ColdOverlay {

    private static float shown = 0.0F; // yumusak gecis icin gosterilen deger

    private static boolean visible(Minecraft mc) {
        return mc.player != null && mc.level != null && !mc.options.hideGui
                && !mc.player.isCreative() && !mc.player.isSpectator();
    }

    // ---------------------------------------------------------------- Ekran buzlanmasi

    public static void renderFrost(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!visible(mc)) return;

        float cold = ClientColdData.cold();
        if (cold < 40.0F) return;

        float strength = Math.min(1.0F, (cold - 40.0F) / 60.0F);
        float pulse = 1.0F;
        if (cold >= 80.0F) {
            pulse = 0.85F + 0.15F * Mth.sin((mc.level.getGameTime() + partialTick) * 0.15F);
        }

        int thickness = Math.min(w, h) / 5;
        int steps = 18;
        float step = thickness / (float) steps;

        for (int i = 0; i < steps; i++) {
            float fall = 1.0F - i / (float) steps;
            int a = (int) (255.0F * 0.55F * strength * pulse * fall * fall);
            if (a <= 0) continue;
            int color = (a << 24) | 0xCFEFFF;

            int o1 = Math.round(i * step);
            int o2 = Math.round((i + 1) * step);
            if (o2 <= o1) continue;

            g.fill(o1, 0, o2, h, color);             // sol
            g.fill(w - o2, 0, w - o1, h, color);     // sag
            g.fill(0, o1, w, o2, color);             // ust
            g.fill(0, h - o2, w, h - o1, color);     // alt
        }
    }

    // ---------------------------------------------------------------- Soguk cubugu

    public static void renderBar(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!visible(mc)) return;

        shown += (ClientColdData.cold() - shown) * 0.12F;
        float cold = Mth.clamp(shown, 0.0F, 100.0F);
        float trend = ClientColdData.trend();

        int barW = 100;
        int barH = 7;
        int startX = w / 2 - 72;
        int iconCx = startX + 4;
        int bx = startX + 14;
        int y = h - 60;

        // Renkler: acik mavi -> mavi -> mor -> kirmizi
        int top = rampColor(cold, 0x7FE0FF, 0x4F8BFF, 0xB45CFF, 0xFF4A66);
        int bottom = rampColor(cold, 0x3AA8E0, 0x2A55C8, 0x7A2EC8, 0xC02040);

        // Cerceve ve arka plan
        g.fill(bx - 1, y - 1, bx + barW + 1, y + barH + 1, 0xCC000000);
        g.fill(bx, y, bx + barW, y + barH, 0xCC0E1A24);

        // Dolgu
        int fillW = Math.round(barW * cold / 100.0F);
        if (fillW > 0) {
            g.fillGradient(bx, y, bx + fillW, y + barH, top, bottom);
            g.fill(bx, y, bx + fillW, y + 1, 0x55FFFFFF); // ust parlama
        }

        // %25 araliklarla cizgiler
        for (int t = 1; t < 4; t++) {
            int tx = bx + barW * t / 4;
            g.fill(tx, y, tx + 1, y + barH, 0x66000000);
        }

        // Tehlikede kirmizi titreyen cerceve
        if (cold >= 80.0F && mc.level != null) {
            float s = 0.5F + 0.5F * Mth.sin((mc.level.getGameTime() + partialTick) * 0.3F);
            int a = (int) (80 + 120 * s);
            outline(g, bx - 2, y - 2, barW + 4, barH + 4, (a << 24) | 0xFF3050);
        }

        // Kar tanesi ikonu
        int iconColor = rampColor(cold, 0xFFFFFF, 0xCFEFFF, 0xFFB0C0, 0xFF6070);
        drawSnowflake(g, iconCx, y + barH / 2, 0xFF000000 | iconColor);

        // Yuzde yazisi
        String txt = (int) cold + "%";
        int textColor = cold < 50.0F ? 0xE8F6FF : (cold < 80.0F ? 0xFFD27F : 0xFF6B6B);
        int tx = bx + barW + 6;
        g.drawString(mc.font, txt, tx, y - 1, textColor, true);

        // Isinma / soguma oku
        int ax = tx + mc.font.width(txt) + 7;
        if (trend < -0.05F) {
            drawArrow(g, ax, y + 1, false, 0xFFFFB347); // isiniyor
        } else if (trend > 0.05F) {
            drawArrow(g, ax, y + 1, true, 0xFF7FE0FF);  // soguyor
        }
    }

    // ---------------------------------------------------------------- Yardimcilar

    private static void drawSnowflake(GuiGraphics g, int cx, int cy, int color) {
        g.fill(cx - 4, cy, cx + 5, cy + 1, color);
        g.fill(cx, cy - 4, cx + 1, cy + 5, color);
        for (int i = -3; i <= 3; i++) {
            g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
            g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, color);
        }
    }

    /** up = true: yukari ok (soguyor), false: asagi ok (isiniyor). */
    private static void drawArrow(GuiGraphics g, int x, int y, boolean up, int color) {
        for (int r = 0; r < 3; r++) {
            int half = up ? r : 2 - r;
            g.fill(x - half, y + r, x + half + 1, y + r + 1, color);
        }
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** 0, 50, 80, 100 duraklari arasinda renk gecisi. Donen deger RGB (alfa yok). */
    private static int rampColor(float cold, int c0, int c50, int c80, int c100) {
        if (cold < 50.0F) return lerpColor(c0, c50, cold / 50.0F);
        if (cold < 80.0F) return lerpColor(c50, c80, (cold - 50.0F) / 30.0F);
        return lerpColor(c80, c100, (cold - 80.0F) / 20.0F);
    }

    private static int lerpColor(int a, int b, float t) {
        int r = (int) Mth.lerp(t, (a >> 16) & 0xFF, (b >> 16) & 0xFF);
        int gr = (int) Mth.lerp(t, (a >> 8) & 0xFF, (b >> 8) & 0xFF);
        int bl = (int) Mth.lerp(t, a & 0xFF, b & 0xFF);
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }
}
