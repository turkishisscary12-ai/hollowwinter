package com.hollowwinter.mod.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Rare Yeti evidence scene for every Overworld biome: claw marks on a tree trunk
 * and several fallen logs nearby. Uses dark buttons as small bark gouges.
 */
public class YetiClawSceneFeature extends Feature<NoneFeatureConfiguration> {
    public YetiClawSceneFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        RandomSource random = context.random();

        int x = origin.getX();
        int z = origin.getZ();
        int surfaceY = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
        BlockPos ground = new BlockPos(x, surfaceY - 1, z);
        BlockState groundState = level.getBlockState(ground);

        // Avoid placing evidence in deep water, lava, or on an empty column.
        if (!groundState.isSolid()) {
            return false;
        }

        // Find a nearby standing tree trunk in any biome.
        BlockPos trunk = findNearbyTrunk(level, origin, random);
        if (trunk == null) {
            trunk = createSmallEvidenceTree(level, x, surfaceY, z, random);
        }
        if (trunk == null) {
            return false;
        }

        // Three dark gouges on the side of the trunk (not on the ground).
        Direction side = Direction.Plane.HORIZONTAL.getRandomDirection(random);
        for (int i = 0; i < 3; i++) {
            BlockPos logPos = trunk.above(i);
            if (!level.getBlockState(logPos).is(BlockTags.LOGS)) {
                continue;
            }
            BlockPos markPos = logPos.relative(side);
            if (level.isEmptyBlock(markPos)) {
                BlockState mark = Blocks.POLISHED_BLACKSTONE_BUTTON.defaultBlockState()
                        .setValue(ButtonBlock.FACE, AttachFace.WALL)
                        .setValue(ButtonBlock.FACING, side)
                        .setValue(ButtonBlock.POWERED, false);
                level.setBlock(markPos, mark, 2);
            }
        }

        // Two or three fallen trunks around the marked tree.
        int fallenTrees = 2 + random.nextInt(2);
        for (int t = 0; t < fallenTrees; t++) {
            int offsetX = (random.nextBoolean() ? 1 : -1) * (3 + random.nextInt(4));
            int offsetZ = (random.nextBoolean() ? 1 : -1) * (3 + random.nextInt(4));
            int tx = x + offsetX;
            int tz = z + offsetZ;
            int ty = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, tx, tz);
            BlockPos start = new BlockPos(tx, ty, tz);
            Direction.Axis axis = random.nextBoolean() ? Direction.Axis.X : Direction.Axis.Z;
            int length = 3 + random.nextInt(3);
            BlockState log = Blocks.OAK_LOG.defaultBlockState()
                    .setValue(RotatedPillarBlock.AXIS, axis);
            for (int i = 0; i < length; i++) {
                BlockPos logPos = start.relative(axis == Direction.Axis.X
                        ? Direction.EAST : Direction.SOUTH, i);
                if (level.isEmptyBlock(logPos) || level.getBlockState(logPos).is(Blocks.SNOW)) {
                    level.setBlock(logPos, log, 2);
                }
            }
        }
        return true;
    }

    private BlockPos findNearbyTrunk(WorldGenLevel level, BlockPos origin, RandomSource random) {
        for (int attempt = 0; attempt < 36; attempt++) {
            int dx = random.nextInt(13) - 6;
            int dz = random.nextInt(13) - 6;
            int x = origin.getX() + dx;
            int z = origin.getZ() + dz;
            int topY = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
            for (int y = topY - 1; y >= Math.max(level.getMinBuildHeight(), topY - 8); y--) {
                BlockPos pos = new BlockPos(x, y, z);
                if (level.getBlockState(pos).is(BlockTags.LOGS)
                        && level.getBlockState(pos.above()).is(BlockTags.LOGS)
                        && level.getBlockState(pos.above(2)).is(BlockTags.LOGS)) {
                    return pos;
                }
            }
        }
        return null;
    }

    private BlockPos createSmallEvidenceTree(WorldGenLevel level, int x, int surfaceY, int z,
                                              RandomSource random) {
        BlockPos base = new BlockPos(x, surfaceY, z);
        if (!level.isEmptyBlock(base) || !level.isEmptyBlock(base.above(1))
                || !level.isEmptyBlock(base.above(2)) || !level.isEmptyBlock(base.above(3))) {
            return null;
        }
        int height = 4 + random.nextInt(2);
        for (int i = 0; i < height; i++) {
            level.setBlock(base.above(i), Blocks.OAK_LOG.defaultBlockState(), 2);
        }
        BlockPos crown = base.above(height - 1);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (Math.abs(dx) + Math.abs(dz) <= 2) {
                    BlockPos leaf = crown.offset(dx, 1, dz);
                    if (level.isEmptyBlock(leaf)) {
                        level.setBlock(leaf, Blocks.OAK_LEAVES.defaultBlockState(), 2);
                    }
                }
            }
        }
        return base;
    }
}
