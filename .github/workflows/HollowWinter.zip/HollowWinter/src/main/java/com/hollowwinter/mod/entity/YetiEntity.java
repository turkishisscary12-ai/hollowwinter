package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.cold.ColdHandler;
import com.hollowwinter.mod.event.YetiEventManager;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Yeti. Dort modu vardir:
 *  NORMAL  : yumurtadan/komutla gelen sıradan dusman yeti (oyuncuya saldirir).
 *  WINDOW  : pencere olayindaki hayalet yeti (hareketsiz, olumsuz, fizigi yok).
 *  WATCHER : sabah izleyen yeti (hareketsiz, olumsuz).
 *  CHASER  : gece kovalamacasindaki yeti (kovalar, saldirir; AI'sini YetiEventManager acar).
 * NORMAL disindaki modlar YetiEventManager tarafindan izlenir; izlenmeyen yeti (orn. dunya yeniden
 * yuklenince) kendini siler.
 */
public class YetiEntity extends Monster {

    public static final int MODE_NORMAL = 0;
    public static final int MODE_WINDOW = 1;
    public static final int MODE_WATCHER = 2;
    public static final int MODE_CHASER = 3;

    private int mode = MODE_NORMAL;

    public YetiEntity(EntityType<? extends YetiEntity> type, Level level) {
        super(type, level);
        this.xpReward = 25;
        this.setPersistenceRequired();
    }

    /**
     * Hiz: kurt 0.30 kosan oyuncudan hizli, zombi 0.23 yavas; 0.25 = kosandan biraz yavas.
     * Test ederken zor/kolay gelirse buradan ayarla.
     */
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0D, true) {
            @Override
            public boolean canUse() {
                return YetiEntity.this.isActiveMelee() && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return YetiEntity.this.isActiveMelee() && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D) {
            @Override
            public boolean canUse() {
                return YetiEntity.this.mode == MODE_NORMAL && super.canUse();
            }
        });
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true) {
            @Override
            public boolean canUse() {
                return YetiEntity.this.mode == MODE_NORMAL && super.canUse();
            }
        });
    }

    private boolean isActiveMelee() {
        return mode == MODE_NORMAL || mode == MODE_CHASER;
    }

    // ---------------------------------------------------------------- Mod

    public int getMode() {
        return mode;
    }

    public void setMode(int newMode) {
        this.mode = newMode;
        boolean ghost = newMode == MODE_WINDOW;
        this.setInvulnerable(ghost || newMode == MODE_WATCHER);
        this.setNoGravity(ghost);
        this.noPhysics = ghost;
        // Kovalayici da baslangicta hareketsiz bekler; YetiEventManager kovalamaca baslayinca AI'yi acar.
        this.setNoAi(newMode != MODE_NORMAL);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && mode != MODE_NORMAL
                && !YetiEventManager.isTracked(this.getUUID())) {
            this.discard();
        }
    }

    // ---------------------------------------------------------------- Dovus

    /** Kovalamacada yeti arada sirada yetisip vurur: 1 kalp (2 can) + %5 soguk. */
    private static final float CHASE_HIT_DAMAGE = 2.0F;
    private static final float CHASE_HIT_COLD = 5.0F;
    private static final int CHASE_HIT_COOLDOWN = 100; // 5 sn
    private int chaseHitCooldown = 0;

    @Override
    public void aiStep() {
        super.aiStep();
        if (chaseHitCooldown > 0) chaseHitCooldown--;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (mode == MODE_CHASER) {
            if (chaseHitCooldown > 0) return false;
            chaseHitCooldown = CHASE_HIT_COOLDOWN;
            // Amac korkutmak: oyuncu bu vurustan olmez, en az yarim kalp kalir.
            boolean hit = true;
            if (target instanceof LivingEntity living) {
                float safe = Math.min(CHASE_HIT_DAMAGE, living.getHealth() - 1.0F);
                if (safe > 0.0F) hit = target.hurt(this.damageSources().mobAttack(this), safe);
            } else {
                hit = target.hurt(this.damageSources().mobAttack(this), CHASE_HIT_DAMAGE);
            }
            if (hit && target instanceof ServerPlayer player) {
                ColdHandler.addCold(player, CHASE_HIT_COLD);
            }
            return hit;
        }
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof ServerPlayer player) {
            ColdHandler.addCold(player, 20.0F); // her vurus soguk bari artirir
        }
        return hit;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return super.isInvulnerableTo(source) || source.is(DamageTypeTags.IS_FREEZING);
    }

    @Override
    public boolean canFreeze() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_FIRE)) {
            amount *= 1.5F; // ateşten fazla hasar yer
        }
        return super.hurt(source, amount);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (mode == MODE_NORMAL || mode == MODE_CHASER) {
            int count = 2 + this.random.nextInt(3) + looting; // 2-4 kurk parcasi
            this.spawnAtLocation(new ItemStack(ModItems.PELT.get(), count));
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ---------------------------------------------------------------- Ses

    @Override
    protected SoundEvent getAmbientSound() {
        return mode == MODE_NORMAL ? SoundEvents.POLAR_BEAR_AMBIENT : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.POLAR_BEAR_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.POLAR_BEAR_DEATH;
    }

    // ---------------------------------------------------------------- Kayit

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("YetiMode", mode);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setMode(tag.getInt("YetiMode"));
    }
}
