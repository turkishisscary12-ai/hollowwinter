package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.item.FurArmorItem;
import com.hollowwinter.mod.item.HeaterItem;
import com.hollowwinter.mod.item.IceAxeItem;
import com.hollowwinter.mod.item.IceHoeItem;
import com.hollowwinter.mod.item.IcePickaxeItem;
import com.hollowwinter.mod.item.IceShovelItem;
import com.hollowwinter.mod.item.TeaItem;
import com.hollowwinter.mod.item.WaterCupItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, HollowWinter.MODID);

    public static final java.util.List<RegistryObject<Item>> FROZEN_ITEMS = new java.util.ArrayList<>();
    private static RegistryObject<Item> frozen(String name, Item.Properties props) {
        RegistryObject<Item> obj = ITEMS.register(name, () -> new Item(props));
        FROZEN_ITEMS.add(obj);
        return obj;
    }

    public static final RegistryObject<Item> FROZEN_ROTTEN_FLESH = frozen("frozen_rotten_flesh", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(4).saturationMod(0.1F).meat().effect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.HUNGER, 600, 0), 0.8F).build()));
    public static final RegistryObject<Item> FROZEN_BONE = frozen("frozen_bone", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_ARROW = frozen("frozen_arrow", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_BOW = frozen("frozen_bow", new Item.Properties().stacksTo(1));
    public static final RegistryObject<Item> FROZEN_BEEF = frozen("frozen_beef", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationMod(0.3F).meat().build()));
    public static final RegistryObject<Item> FROZEN_PORKCHOP = frozen("frozen_porkchop", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(3).saturationMod(0.3F).meat().build()));
    public static final RegistryObject<Item> FROZEN_MUTTON = frozen("frozen_mutton", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3F).meat().build()));
    public static final RegistryObject<Item> FROZEN_CHICKEN = frozen("frozen_chicken", new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder().nutrition(2).saturationMod(0.3F).meat().effect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.HUNGER, 600, 0), 0.3F).build()));
    public static final RegistryObject<Item> FROZEN_LEATHER = frozen("frozen_leather", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_FEATHER = frozen("frozen_feather", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_STRING = frozen("frozen_string", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_SPIDER_EYE = frozen("frozen_spider_eye", new Item.Properties());
    public static final RegistryObject<Item> FROZEN_GUNPOWDER = frozen("frozen_gunpowder", new Item.Properties());

    public static final RegistryObject<Item> PELT = ITEMS.register("pelt",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> FUR_HELMET = ITEMS.register("fur_helmet",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> FUR_CHESTPLATE = ITEMS.register("fur_chestplate",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> FUR_LEGGINGS = ITEMS.register("fur_leggings",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> FUR_BOOTS = ITEMS.register("fur_boots",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.BOOTS, new Item.Properties()));

    public static final RegistryObject<Item> EMPTY_CUP = ITEMS.register("empty_cup",
            () -> new WaterCupItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> WATER_CUP = ITEMS.register("water_cup",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> TEA_LEAVES = ITEMS.register("tea_leaves",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TEA = ITEMS.register("tea",
            () -> new TeaItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> ICE_PICKAXE = ITEMS.register("ice_pickaxe",
            () -> new IcePickaxeItem(new Item.Properties()));
    public static final RegistryObject<Item> ICE_AXE = ITEMS.register("ice_axe",
            () -> new IceAxeItem(new Item.Properties()));
    public static final RegistryObject<Item> ICE_SHOVEL = ITEMS.register("ice_shovel",
            () -> new IceShovelItem(new Item.Properties()));
    public static final RegistryObject<Item> ICE_HOE = ITEMS.register("ice_hoe",
            () -> new IceHoeItem(new Item.Properties()));

    public static final RegistryObject<Item> FROZEN_DIRT = ITEMS.register("frozen_dirt",
            () -> new BlockItem(ModBlocks.FROZEN_DIRT.get(), new Item.Properties()));
    public static final RegistryObject<Item> FROZEN_GRASS_BLOCK = ITEMS.register("frozen_grass_block",
            () -> new BlockItem(ModBlocks.FROZEN_GRASS_BLOCK.get(), new Item.Properties()));

    public static final RegistryObject<Item> HEATER = ITEMS.register("heater",
            () -> new HeaterItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> BATTERY = ITEMS.register("battery",
            () -> new com.hollowwinter.mod.item.BatteryItem(
                    new Item.Properties().durability(com.hollowwinter.mod.item.BatteryItem.CAPACITY)));
    public static final RegistryObject<Item> WATER_HEATER = ITEMS.register("water_heater",
            () -> new BlockItem(ModBlocks.WATER_HEATER.get(), new Item.Properties()));

    public static final RegistryObject<Item> TEA_SEEDS = ITEMS.register("tea_seeds",
            () -> new net.minecraft.world.item.ItemNameBlockItem(ModBlocks.TEA_BUSH.get(), new Item.Properties()));
    public static final RegistryObject<Item> STRAWBERRY = ITEMS.register("strawberry",
            () -> new net.minecraft.world.item.ItemNameBlockItem(ModBlocks.STRAWBERRY_BUSH.get(),
                    new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder()
                            .nutrition(3).saturationMod(0.3F).build())));
    public static final RegistryObject<Item> FROZEN_STRAWBERRY = ITEMS.register("frozen_strawberry",
            () -> new com.hollowwinter.mod.item.FrozenStrawberryItem(new Item.Properties()
                    .food(new net.minecraft.world.food.FoodProperties.Builder()
                            .nutrition(2).saturationMod(0.2F).build())));

    public static final RegistryObject<Item> ICICLE = ITEMS.register("icicle",
            () -> new BlockItem(ModBlocks.ICICLE.get(), new Item.Properties()));

    public static final RegistryObject<Item> MAMMOTH_RIB = ITEMS.register("mammoth_rib",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> MAMMOTH_MEAT = ITEMS.register("mammoth_meat",
            () -> new Item(new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder()
                    .nutrition(4).saturationMod(0.3F).meat().build())));
    /** Pismis mamut eti: bifteginden (8) cok daha doyurucu. */
    public static final RegistryObject<Item> COOKED_MAMMOTH_MEAT = ITEMS.register("cooked_mammoth_meat",
            () -> new Item(new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder()
                    .nutrition(14).saturationMod(0.8F).meat().build())));
    public static final RegistryObject<Item> VIKING_HELMET = ITEMS.register("viking_helmet",
            () -> new ArmorItem(ModArmorMaterials.VIKING, ArmorItem.Type.HELMET, new Item.Properties()));

    public static final RegistryObject<Item> MAMMOTH_SPAWN_EGG = ITEMS.register("mammoth_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MAMMOTH, 0x6B4A30, 0xE6E0C8, new Item.Properties()));

    public static final RegistryObject<Item> YETI_SPAWN_EGG = ITEMS.register("yeti_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.YETI, 0xE8F0F8, 0x6C8CA8, new Item.Properties()));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
