package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

/** Isi makinelerinin isittigi sutunlar: bitis zamanina kadar kar birikmez / erimez. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public final class HeatZones {
    private HeatZones() {}

    private static final Map<Long, Long> HEATED = new HashMap<>(); // sutun -> bitis (oyun tick'i)

    public static void mark(int x, int z, long untilTick) {
        HEATED.put(BlockPos.asLong(x, 0, z), untilTick);
    }

    public static boolean isHeated(ServerLevel level, int x, int z) {
        if (HEATED.isEmpty()) return false;
        Long until = HEATED.get(BlockPos.asLong(x, 0, z));
        return until != null && until > level.getGameTime();
    }

    /** Suresi dolanlari temizler (isi makinesi arada cagirir). */
    public static void cleanup(long now) {
        if (HEATED.size() > 2000) HEATED.values().removeIf(t -> t <= now);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        HEATED.clear();
    }
}
