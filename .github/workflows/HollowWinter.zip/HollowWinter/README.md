# Hollow Winter

Minecraft 1.20.1 (Forge 47.3.0) icin kis kiyameti modu.

## Kurulum
1. JDK 17 kur.
2. IntelliJ IDEA ile `build.gradle` dosyasini "Open as Project" ile ac.
3. Gradle wrapper yoksa: Forge 1.20.1 MDK'sindan `gradlew`, `gradlew.bat` ve `gradle/` klasorunu bu klasore kopyala
   (https://files.minecraftforge.net/ -> 1.20.1 -> MDK).
4. `./gradlew genIntellijRuns` sonra `runClient` ile test et.
5. `./gradlew build` ile jar `build/libs/` icine cikar.

## Su an olanlar
- Soguk sistemi (`cold/ColdHandler.java`): 0-100 soguk degeri, isi kaynaklari, zirh korumasi, gece/kar etkisi. %90+ 4 sn'de 1 can, %100 her saniye 1 can kaybi.
- Soguk HUD'u (`client/ColdOverlay.java`): hotbar ustunde renkli bar, kar tanesi ikonu, yuzde, isinma/soguma oku; %40+ ekran kenarlarinda buzlanma. Deger sunucudan `ColdSyncPacket` ile gelir.
- Ayak izleri (`winter/FootprintHandler.java`): karda yururken blok boyutunda cukur + kar tozu parcaciklari, yeni kar yagdikca dolar.
- Kurk zirh seti (`registry/`, `item/`): 4 parca + Kurk Parcasi (hayvanlardan duser). Tam set soguktan korur.
- Kis dongusu (`winter/WinterManager.java`): ilk 4 gun acik hava, sonra tekrar eden dongu: 8-10 gun kar (arada 2-6 dk molalar) + 5-7 gun acik hava.
- Her biyomda kar efekti (`mixin/BiomeMixin.java`): yagmur yerine kar yagar.
- Kar birikimi ve erime (`winter/SnowAccumulator.java`): kar asamasinda yerde yukselir (her kar asamasinda 43 blok yukseklige cikar), acik havada zirvenin ~%55'ine kadar erir.

## Ayarlar
- Kisin baslama gunu: `WinterManager.GRACE_DAYS`
- Dongu sureleri ve kar kalinligi: `WinterManager` basindaki sabitler (FIRST_PEAK_LAYERS, PEAK_GROWTH_LAYERS, MAX_PEAK_LAYERS, MELT_KEEP_FRACTION)
- Kar/erime hizi: `SnowAccumulator` basindaki ATTEMPTS sabitleri
- Not: kar sadece oyuncunun 56 blok yakinindaki yuklu alanda degisir

## Bilinen eksikler
- Mixin (`mixin/BiomeMixin.java`) her biyomda yagisi kar yapar. Henuz oyunda test edilmedi; calismazsa `Biome.getPrecipitationAt` adini kontrol et.

## Siradaki fikirler
- Kar firtinasi olayi
- Yakacak sistemi (ocak/kamp atesi odunla yansin)
- Schematic'lerden yapilar (NBT)
