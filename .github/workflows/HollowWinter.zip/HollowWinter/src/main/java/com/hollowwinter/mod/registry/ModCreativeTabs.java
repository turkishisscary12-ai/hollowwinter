package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HollowWinter.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.hollowwinter"))
                    .icon(() -> new ItemStack(ModItems.FUR_CHESTPLATE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.PELT.get());
                        output.accept(ModItems.FUR_HELMET.get());
                        output.accept(ModItems.FUR_CHESTPLATE.get());
                        output.accept(ModItems.FUR_LEGGINGS.get());
                        output.accept(ModItems.FUR_BOOTS.get());
                        output.accept(ModItems.EMPTY_CUP.get());
                        output.accept(ModItems.WATER_CUP.get());
                        output.accept(ModItems.TEA_LEAVES.get());
                        output.accept(ModItems.TEA_SEEDS.get());
                        output.accept(ModItems.STRAWBERRY.get());
                        output.accept(ModItems.FROZEN_STRAWBERRY.get());
                        output.accept(ModItems.TEA.get());
                        output.accept(ModItems.HEATER.get());
                        output.accept(ModItems.BATTERY.get());
                        output.accept(ModItems.WATER_HEATER.get());
                        output.accept(ModItems.FROZEN_DIRT.get());
                        output.accept(ModItems.FROZEN_GRASS_BLOCK.get());
                        output.accept(ModItems.ICE_PICKAXE.get());
                        output.accept(ModItems.ICE_AXE.get());
                        output.accept(ModItems.ICE_SHOVEL.get());
                        output.accept(ModItems.ICE_HOE.get());
                        output.accept(ModItems.MAMMOTH_RIB.get());
                        output.accept(ModItems.MAMMOTH_MEAT.get());
                        output.accept(ModItems.COOKED_MAMMOTH_MEAT.get());
                        output.accept(ModItems.VIKING_HELMET.get());
                        output.accept(ModItems.ICICLE.get());
                        ModItems.FROZEN_ITEMS.forEach(o -> output.accept(o.get()));
                        output.accept(ModItems.YETI_SPAWN_EGG.get());
                        output.accept(ModItems.MAMMOTH_SPAWN_EGG.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}
