package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.menu.WaterHeaterMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, HollowWinter.MODID);

    public static final RegistryObject<MenuType<WaterHeaterMenu>> WATER_HEATER = MENUS.register("water_heater",
            () -> IForgeMenuType.create((id, inv, buf) -> new WaterHeaterMenu(id, inv)));

    public static final RegistryObject<MenuType<com.hollowwinter.mod.menu.MinerMenu>> MINER = MENUS.register("miner",
            () -> IForgeMenuType.create((id, inv, buf) -> new com.hollowwinter.mod.menu.MinerMenu(id, inv)));

    public static void register(IEventBus bus) {
        MENUS.register(bus);
    }
}
