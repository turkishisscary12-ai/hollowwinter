package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.PenguinEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class PenguinRenderer extends MobRenderer<PenguinEntity, PenguinModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/penguin.png");
    private static final float SCALE = 0.8F;

    public PenguinRenderer(EntityRendererProvider.Context context) {
        super(context, new PenguinModel(context.bakeLayer(PenguinModel.LAYER)), 0.35F);
    }

    @Override
    public ResourceLocation getTextureLocation(PenguinEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(PenguinEntity entity, PoseStack poseStack, float partialTick) {
        float s = entity.isBaby() ? SCALE * 0.5F : SCALE;
        poseStack.scale(s, s, s);
        this.shadowRadius = 0.35F * s;
    }
}
