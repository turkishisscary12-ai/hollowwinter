package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Su donmasi: kis basladiginda (kar yagmaya basladiginda) acik sular ustten asagi dogru yavas yavas buza doner.
 * Her dunya icin 5-10 gun (seed'den sabit) icinde tamamen donar. Sadece suyun UST 4 BLOGU donar (daha sig sular tamamen).
 * Zaman ilerledikce izin verilen buz derinligi (sutun derinliginin orani) artar; oyuncularin etrafinda (RADIUS)
 * rastgele sutunlar secilip bu orana kadar dondurulur. Buzlar kendiliginden erimez.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class WaterFreezer {

    private static final int RADIUS = 56;
    private static final int ATTEMPTS_PER_TICK = 10;
    private static final int MAX_BLOCKS_PER_HIT = 4;
    private static final int MAX_DEPTH = 64;
    /** Sadece suyun ust 4 blogu donar; altinda su kalir (buzu kirip suya erisilebilir). */
    private static final int MAX_FREEZE_DEPTH = 4;

    /** Tam donmaya kadar gecen gun sayisi (5-10), dunya seed'inden sabit. */
    public static int freezeDays(ServerLevel level) {
        return 5 + RandomSource.create(level.getSeed() * 131L + 7L).nextInt(6);
    }

    /** 0 = hic donmadi, 1 = tamamen dondu. */
    public static double progress(ServerLevel level) {
        double days = WinterManager.daysSinceOrigin(level) - WinterManager.GRACE_DAYS;
        return Mth.clamp(days / freezeDays(level), 0.0, 1.0);
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        double p = progress(level);
        if (p <= 0.0) return;

        RandomSource rand = level.getRandom();
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            BlockPos c = player.blockPosition();
            for (int i = 0; i < ATTEMPTS_PER_TICK; i++) {
                int x = c.getX() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                int z = c.getZ() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;
                freezeColumn(level, x, z, p);
            }
        }
    }

    private static boolean isWaterSource(BlockState s) {
        FluidState fs = s.getFluidState();
        return fs.is(Fluids.WATER) && fs.isSource();
    }

    private static void freezeColumn(ServerLevel level, int x, int z, double p) {
        // Kar katmanlari hareketi engellemedigi icin MOTION_BLOCKING, buzun/suyun ust yuzeyini verir.
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(x, top, z);
        BlockState first = level.getBlockState(m);
        if (!isWaterSource(first) && !first.is(Blocks.ICE)) return;

        // Sutunun su/buz derinligini ve ustten kac blogun zaten buz oldugunu say
        int depth = 0;
        int frozen = 0;
        boolean contiguousIce = true;
        for (int y = top; y >= level.getMinBuildHeight() && depth < MAX_DEPTH; y--) {
            m.setY(y);
            BlockState st = level.getBlockState(m);
            if (st.is(Blocks.ICE)) {
                if (contiguousIce) frozen++;
                depth++;
            } else if (isWaterSource(st)) {
                contiguousIce = false;
                depth++;
            } else {
                break;
            }
        }

        int target = (int) Math.ceil(p * Math.min(depth, MAX_FREEZE_DEPTH));
        for (int i = 0; i < MAX_BLOCKS_PER_HIT && frozen < target; i++) {
            m.setY(top - frozen);
            BlockState st = level.getBlockState(m);
            if (!isWaterSource(st)) return;
            // Icinde oyuncu / tekne / esya varsa dondurma (sikismasinlar)
            if (!level.getEntities((Entity) null, new AABB(m), e -> true).isEmpty()) return;
            level.setBlock(m, Blocks.ICE.defaultBlockState(), 3);
            frozen++;
        }
    }
}
