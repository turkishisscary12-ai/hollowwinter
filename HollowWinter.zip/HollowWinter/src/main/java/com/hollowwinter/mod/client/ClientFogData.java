package com.hollowwinter.mod.client;

/** Kovalamaca sisi ve kar firtinasi icin istemci durumu. Sadece sayi tutar. */
public class ClientFogData {
    private static float target = 0.0F;   // 0 = sis yok, 1 = tam sis
    private static float current = 0.0F;  // yumusak gecis icin gosterilen deger

    private static float stormTarget = 0.0F;
    private static float stormCurrent = 0.0F;

    public static void setTarget(float value) {
        target = value;
    }

    public static void setStormTarget(float value) {
        stormTarget = value;
    }

    /** Her cizimde cagrilir; sisi yavasca koyulastirir/acar. */
    public static float smoothed() {
        current += (target - current) * 0.03F;
        if (Math.abs(target - current) < 0.002F) current = target;
        return current;
    }

    public static float smoothedStorm() {
        stormCurrent += (stormTarget - stormCurrent) * 0.01F; // firtina yavas yavas coker
        if (Math.abs(stormTarget - stormCurrent) < 0.002F) stormCurrent = stormTarget;
        return stormCurrent;
    }

    public static float current() {
        return current;
    }

    public static float stormCurrent() {
        return stormCurrent;
    }
}
