package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.OwlEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class OwlRenderer extends MobRenderer<OwlEntity, OwlModel> {
    private static final ResourceLocation NORMAL = new ResourceLocation(HollowWinter.MODID, "textures/entity/owl.png");
    private static final ResourceLocation FROZEN = new ResourceLocation(HollowWinter.MODID, "textures/entity/owl_frozen.png");
    private static final ResourceLocation EYES = new ResourceLocation(HollowWinter.MODID, "textures/entity/owl_eyes.png");

    public OwlRenderer(EntityRendererProvider.Context context) {
        super(context, new OwlModel(context.bakeLayer(OwlModel.LAYER)), 0.25F);
        this.addLayer(new EyesLayer<OwlEntity, OwlModel>(this) {
            @Override
            public RenderType renderType() {
                return RenderType.eyes(EYES);
            }

            @Override
            public void render(PoseStack ps, MultiBufferSource buf, int light, OwlEntity e, float a, float b,
                               float c, float d, float f, float g) {
                if (e.isFrozenVariant()) super.render(ps, buf, light, e, a, b, c, d, f, g);
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(OwlEntity entity) {
        return entity.isFrozenVariant() ? FROZEN : NORMAL;
    }

    @Override
    protected void scale(OwlEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.85F, 0.85F, 0.85F);
    }
}
