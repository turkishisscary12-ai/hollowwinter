package com.hollowwinter.mod.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Yere yatik ayak izi. xSpeed = bakis yonu (radyan, dunya x/z duzleminde), ySpeed = boyut carpani. */
public class FootprintParticle extends TextureSheetParticle {
    private final float fx;
    private final float fz;
    private final int fadeTicks = 100;

    protected FootprintParticle(ClientLevel level, double x, double y, double z, double dir, double size, SpriteSet sprites) {
        super(level, x, y, z, 0.0, 0.0, 0.0);
        this.xd = 0.0;
        this.yd = 0.0;
        this.zd = 0.0;
        this.hasPhysics = false;
        this.gravity = 0.0F;
        this.fx = (float) Math.cos(dir);
        this.fz = (float) Math.sin(dir);
        this.quadSize = 0.25F * (float) Math.max(0.5, size);
        this.lifetime = size > 1.5 ? 2400 : 1800; // yeti izi daha uzun kalir (2 / 1.5 dk)
        this.rCol = 1.0F;
        this.gCol = 1.0F;
        this.bCol = 1.0F;
        this.pickSprite(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        int left = this.lifetime - this.age;
        this.alpha = left < fadeTicks ? left / (float) fadeTicks : 1.0F;
    }

    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        Vec3 cam = camera.getPosition();
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - cam.x());
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - cam.y());
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - cam.z());
        float s = this.quadSize;
        // ileri = (fx, fz); sag = (-fz, fx)
        float rx = -fz, rz = fx;
        float u0 = this.getU0(), u1 = this.getU1(), v0 = this.getV0(), v1 = this.getV1();
        int light = this.getLightColor(partialTicks);
        // koseler: sol-on, sag-on, sag-arka, sol-arka (uzun kenar ileri)
        vertex(buffer, px, py, pz, -1, 1, s, rx, rz, u0, v0, light);
        vertex(buffer, px, py, pz, 1, 1, s, rx, rz, u1, v0, light);
        vertex(buffer, px, py, pz, 1, -1, s, rx, rz, u1, v1, light);
        vertex(buffer, px, py, pz, -1, -1, s, rx, rz, u0, v1, light);
    }

    private void vertex(VertexConsumer b, float px, float py, float pz, float side, float fwd, float s,
                        float rx, float rz, float u, float v, int light) {
        float wx = px + (rx * side + fx * fwd) * s;
        float wz = pz + (rz * side + fz * fwd) * s;
        b.vertex(wx, py, wz).uv(u, v).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(light).endVertex();
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double dir, double size, double unused) {
            return new FootprintParticle(level, x, y, z, dir, size, sprites);
        }
    }
}
