package com.hollowwinter.mod.network;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(HollowWinter.MODID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    public static void register() {
        int id = 0;

        CHANNEL.messageBuilder(ColdSyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ColdSyncPacket::encode)
                .decoder(ColdSyncPacket::decode)
                .consumerMainThread(ColdSyncPacket::handle)
                .add();

        CHANNEL.messageBuilder(ChaseFogPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ChaseFogPacket::encode)
                .decoder(ChaseFogPacket::decode)
                .consumerMainThread(ChaseFogPacket::handle)
                .add();
    }
}
