package com.hollowwinter.mod.network;

import com.hollowwinter.mod.client.ClientFogData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucu -> Istemci: kovalamaca sisini ac / kapat. */
public class ChaseFogPacket {
    private final boolean on;

    public ChaseFogPacket(boolean on) {
        this.on = on;
    }

    public static void encode(ChaseFogPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.on);
    }

    public static ChaseFogPacket decode(FriendlyByteBuf buf) {
        return new ChaseFogPacket(buf.readBoolean());
    }

    public static void handle(ChaseFogPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ClientFogData.setTarget(msg.on ? 1.0F : 0.0F);
    }
}
