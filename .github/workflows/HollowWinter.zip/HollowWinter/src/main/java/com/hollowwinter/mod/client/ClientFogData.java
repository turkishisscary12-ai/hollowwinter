package com.hollowwinter.mod.client;

/** Kovalamaca sisinin istemci durumu. Sadece sayi tutar, istemciye ozel kod icermez. */
public class ClientFogData {
    private static float target = 0.0F;   // 0 = sis yok, 1 = tam sis
    private static float current = 0.0F;  // yumusak gecis icin gosterilen deger

    public static void setTarget(float value) {
        target = value;
    }

    /** Her cizimde cagrilir; sisi yavasca koyulastirir/acar. */
    public static float smoothed() {
        current += (target - current) * 0.03F;
        if (Math.abs(target - current) < 0.002F) current = target;
        return current;
    }

    public static float current() {
        return current;
    }
}
