package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.world.level.GameRules;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Tek kisi uyursa gece herkes icin atlanir: uyku yuzdesi kurali %1'e cekilir
 * (en az 1 uyuyan yeterli; uyumayanlar da sabaha gecer).
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class SleepEvents {
    private static final int SLEEP_PERCENT = 1;

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        event.getServer().getGameRules().getRule(GameRules.RULE_PLAYERS_SLEEPING_PERCENTAGE)
                .set(SLEEP_PERCENT, event.getServer());
    }
}
