package com.hollowwinter.mod.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.block.state.BlockState;

/** Buz kurek: ozel gucu yok, sadece normalden cok daha hizli kazar. */
public class IceShovelItem extends ShovelItem implements IceTool {
    public IceShovelItem(Properties properties) {
        super(Tiers.IRON, 1.5F, -3.0F, properties.durability(180));
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        return super.getDestroySpeed(stack, state) * 2.0F;
    }
}
