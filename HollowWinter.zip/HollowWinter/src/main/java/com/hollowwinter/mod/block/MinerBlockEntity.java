package com.hollowwinter.mod.block;

import com.hollowwinter.mod.menu.MinerMenu;
import com.hollowwinter.mod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Maden makinesi mantigi. Durumlar: BOSTA -> INIS (3x3'luk katman katman kazarak) -> CIKIS (yukari) -> BOSTA.
 * Kazma suresi katmandaki en sert bloga gore: yumusak (toprak) ~0.2 sn, tas 1 sn, sert kaya/maden 3 sn, cok sert 5 sn.
 * Cikan esyalar onundeki sandiga (envanter) gider; sandik yoksa onune firlatilir; sandik doluysa makine bekler.
 */
public class MinerBlockEntity extends BlockEntity implements MenuProvider {
    public static final int IDLE = 0;
    public static final int DESCENDING = 1;
    public static final int ASCENDING = 2;

    // ---- Ayarlar
    private static final int TICKS_SOFT = 4;     // toprak, kum, cakil, kar (hardness <= 0.6)
    private static final int TICKS_STONE = 20;   // tas (hardness <= 2.5)
    private static final int TICKS_HARD = 60;    // sert kaya / maden (hardness <= 5)
    private static final int TICKS_VERY_HARD = 100; // obsidyen vb.
    private static final int TICKS_EMPTY = 3;    // zaten bos katman
    private static final float ASCEND_SPEED = 0.2F; // blok / tick
    private static final ItemStack TOOL = new ItemStack(Items.NETHERITE_PICKAXE);

    /** Yakit: benzin kutusu (1000) makineye sag tikla bosaltilir. Her katman iner 5 birim yakar; cikis ucretsiz. */
    public static final int MAX_FUEL = 4000;
    public static final int FUEL_PER_LAYER = 5;

    private int fuel = 0;
    private int targetDepth = 16;
    private int state = IDLE;
    private float head = 0.0F;     // matkap yakasinin inis mesafesi (blok)
    private int layer = 0;         // tamamlanan katman sayisi
    private int progress = 0;
    private int layerNeed = -1;
    private int tick = 0;
    private final List<ItemStack> pending = new ArrayList<>();

    // istemci animasyonu
    public float renderHead = 0.0F;
    public float spin = 0.0F;
    public float lastSpinTime = 0.0F;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int i) {
            return switch (i) {
                case 0 -> targetDepth;
                case 1 -> state;
                case 2 -> Math.round(head);
                case 3 -> maxDepth();
                case 5 -> fuel;
                default -> 0;
            };
        }

        @Override
        public void set(int i, int value) {
            if (i == 4) applyCommand(value);
        }

        @Override
        public int getCount() {
            return 6;
        }
    };

    public MinerBlockEntity(BlockPos pos, BlockState blockState) {
        super(ModBlockEntities.MINER.get(), pos, blockState);
    }

    public int getFuel() { return fuel; }

    /** Yakit ekler; yer yoksa false. */
    public boolean addFuel(int amount) {
        if (fuel + amount > MAX_FUEL) return false;
        fuel += amount;
        setChanged();
        sync();
        return true;
    }

    public float getHead() { return head; }
    public boolean isActive() { return state != IDLE; }
    public List<ItemStack> getPending() { return pending; }

    /** Bedrock'a kadar en fazla derinlik. */
    private int maxDepth() {
        int min = level != null ? level.getMinBuildHeight() : -64;
        return Math.max(1, worldPosition.getY() - min);
    }

    // ---- Komutlar (menu dugmeleri)

    private void applyCommand(int id) {
        switch (id) {
            case MinerMenu.BTN_MINUS10 -> targetDepth -= 10;
            case MinerMenu.BTN_MINUS1 -> targetDepth -= 1;
            case MinerMenu.BTN_PLUS1 -> targetDepth += 1;
            case MinerMenu.BTN_PLUS10 -> targetDepth += 10;
            case MinerMenu.BTN_MAX -> targetDepth = maxDepth();
            case MinerMenu.BTN_START -> {
                if (state == IDLE && fuel >= FUEL_PER_LAYER) {
                    state = DESCENDING;
                    layer = 0;
                    head = 0.0F;
                    progress = 0;
                    layerNeed = -1;
                    setRunning(true);
                }
            }
            case MinerMenu.BTN_RECALL -> {
                if (state == DESCENDING) beginAscent();
            }
            default -> { }
        }
        targetDepth = Mth.clamp(targetDepth, 1, maxDepth());
        setChanged();
        sync();
    }

    private void beginAscent() {
        state = ASCENDING;
        layerNeed = -1;
        progress = 0;
        sync();
    }

    private void setRunning(boolean running) {
        if (level == null) return;
        BlockState s = getBlockState();
        if (s.hasProperty(MinerBlock.RUNNING) && s.getValue(MinerBlock.RUNNING) != running) {
            level.setBlock(worldPosition, s.setValue(MinerBlock.RUNNING, running), 3);
        }
    }

    private void sync() {
        if (level != null && !level.isClientSide) {
            BlockState s = getBlockState();
            level.sendBlockUpdated(worldPosition, s, s, 3);
        }
    }

    // ---- Sunucu tick

    public static void serverTick(Level level, BlockPos pos, BlockState state, MinerBlockEntity be) {
        if (!(level instanceof ServerLevel sl)) return;
        be.tick++;
        if (!be.pending.isEmpty() && be.tick % 4 == 0) be.flush(sl, state);
        switch (be.state) {
            case DESCENDING -> be.descend(sl, pos);
            case ASCENDING -> be.ascend();
            default -> { }
        }
        if (be.state != IDLE && be.tick % 2 == 0) be.sync();
    }

    private void descend(ServerLevel sl, BlockPos pos) {
        if (!pending.isEmpty()) return; // sandik dolu / bosalmayi bekle
        if (layer >= targetDepth) {
            beginAscent();
            return;
        }
        int y = pos.getY() - (layer + 1);
        if (y <= sl.getMinBuildHeight()) {
            beginAscent();
            return;
        }
        if (layerNeed < 0 && fuel < FUEL_PER_LAYER) { // yakit bitti: yukari don
            beginAscent();
            return;
        }
        if (layerNeed < 0) {
            int need = analyze(sl, pos, y);
            if (need < 0) {      // bedrock / kirilamaz blok: dur ve yukari don
                beginAscent();
                return;
            }
            layerNeed = need;
            progress = 0;
        }
        progress++;
        head = layer + (float) progress / layerNeed;
        if (tick % 8 == 0) {
            sl.playSound(null, pos, SoundEvents.GRINDSTONE_USE, SoundSource.BLOCKS, 0.35F, 0.7F);
        }
        if (progress >= layerNeed) {
            breakLayer(sl, pos, y);
            fuel = Math.max(0, fuel - FUEL_PER_LAYER);
            layer++;
            head = layer;
            layerNeed = -1;
            progress = 0;
            setChanged();
            flush(sl, getBlockState());
        }
    }

    private void ascend() {
        head -= ASCEND_SPEED;
        if (head <= 0.0F) {
            head = 0.0F;
            layer = 0;
            state = IDLE;
            setRunning(false);
            setChanged();
            sync();
        }
    }

    /** Katmandaki (3x3) en sert bloga gore sure; kirilamaz blok varsa -1. */
    private int analyze(ServerLevel sl, BlockPos pos, int y) {
        int need = TICKS_EMPTY;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                m.set(pos.getX() + dx, y, pos.getZ() + dz);
                if (!sl.hasChunkAt(m)) return -1;
                BlockState s = sl.getBlockState(m);
                if (s.isAir() || isFluidOnly(sl, m, s)) continue;
                float h = s.getDestroySpeed(sl, m);
                if (h < 0.0F) return -1;
                int t = h <= 0.6F ? TICKS_SOFT : h <= 2.5F ? TICKS_STONE : h <= 5.0F ? TICKS_HARD : TICKS_VERY_HARD;
                need = Math.max(need, t);
            }
        }
        return need;
    }

    private static boolean isFluidOnly(ServerLevel sl, BlockPos p, BlockState s) {
        return !s.getFluidState().isEmpty() && s.getCollisionShape(sl, p).isEmpty();
    }

    private void breakLayer(ServerLevel sl, BlockPos pos, int y) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                m.set(pos.getX() + dx, y, pos.getZ() + dz);
                BlockState s = sl.getBlockState(m);
                if (s.isAir() || isFluidOnly(sl, m, s)) continue;
                if (s.getDestroySpeed(sl, m) < 0.0F) continue;
                for (ItemStack drop : Block.getDrops(s, sl, m.immutable(), sl.getBlockEntity(m), null, TOOL)) {
                    addPending(drop);
                }
                sl.destroyBlock(m, false);
            }
        }
    }

    private void addPending(ItemStack stack) {
        if (stack.isEmpty()) return;
        for (ItemStack p : pending) {
            if (ItemHandlerHelper.canItemStacksStack(p, stack) && p.getCount() < p.getMaxStackSize()) {
                int move = Math.min(stack.getCount(), p.getMaxStackSize() - p.getCount());
                p.grow(move);
                stack.shrink(move);
                if (stack.isEmpty()) return;
            }
        }
        pending.add(stack.copy());
    }

    /** Esyalari onundeki envantere (sandik) koyar; envanter yoksa onune atar. */
    private void flush(ServerLevel sl, BlockState blockState) {
        if (pending.isEmpty()) return;
        Direction f = blockState.getValue(MinerBlock.FACING);
        BlockPos out = worldPosition.relative(f);
        BlockEntity target = sl.getBlockEntity(out);
        IItemHandler handler = target == null ? null
                : target.getCapability(ForgeCapabilities.ITEM_HANDLER, f.getOpposite()).orElse(null);

        int thrown = 0;
        int before = pending.size();
        int beforeCount = 0;
        for (ItemStack s : pending) beforeCount += s.getCount();
        Iterator<ItemStack> it = pending.iterator();
        while (it.hasNext()) {
            ItemStack st = it.next();
            if (handler != null) {
                ItemStack rest = ItemHandlerHelper.insertItem(handler, st, false);
                if (rest.isEmpty()) it.remove();
                else st.setCount(rest.getCount());
            } else {
                if (thrown++ >= 8) break;
                double x = worldPosition.getX() + 0.5 + f.getStepX() * 0.8;
                double y = worldPosition.getY() + 0.25;
                double z = worldPosition.getZ() + 0.5 + f.getStepZ() * 0.8;
                ItemEntity ie = new ItemEntity(sl, x, y, z, st.copy());
                ie.setDeltaMovement(f.getStepX() * 0.15, 0.05, f.getStepZ() * 0.15);
                sl.addFreshEntity(ie);
                it.remove();
            }
        }
        int afterCount = 0;
        for (ItemStack s : pending) afterCount += s.getCount();
        if (afterCount < beforeCount) {
            // Esyalar boruyla yukari cikip cikis agzindan gidiyor: boru uzerinde parcacik + ses
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.POOF,
                    worldPosition.getX() + 0.5, worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5, 4, 0.1, 0.1, 0.1, 0.01);
            sl.sendParticles(net.minecraft.core.particles.ParticleTypes.POOF,
                    worldPosition.getX() + 0.5 + f.getStepX() * 0.6, worldPosition.getY() + 0.3,
                    worldPosition.getZ() + 0.5 + f.getStepZ() * 0.6, 3, 0.1, 0.1, 0.1, 0.01);
            sl.playSound(null, worldPosition, SoundEvents.ITEM_PICKUP, SoundSource.BLOCKS, 0.3F, 0.8F);
        }
        setChanged();
    }

    // ---- Menu

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.hollowwinter.miner");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new MinerMenu(id, inv, data, ContainerLevelAccess.create(level, worldPosition));
    }

    // ---- Kayit / istemci esitleme

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Target", targetDepth);
        tag.putInt("Fuel", fuel);
        tag.putInt("State", state);
        tag.putInt("Layer", layer);
        tag.putFloat("Head", head);
        ListTag list = new ListTag();
        for (ItemStack s : pending) list.add(s.save(new CompoundTag()));
        tag.put("Pending", list);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        targetDepth = Math.max(1, tag.getInt("Target"));
        fuel = tag.getInt("Fuel");
        state = tag.getInt("State");
        layer = tag.getInt("Layer");
        head = tag.getFloat("Head");
        layerNeed = -1;
        progress = 0;
        pending.clear();
        for (Tag t : tag.getList("Pending", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) t);
            if (!s.isEmpty()) pending.add(s);
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public AABB getRenderBoundingBox() {
        BlockPos p = worldPosition;
        double depth = Math.max(head, renderHead) + 3.0;
        return new AABB(p.getX() - 2, p.getY() - depth, p.getZ() - 2, p.getX() + 3, p.getY() + 3, p.getZ() + 3);
    }
}
