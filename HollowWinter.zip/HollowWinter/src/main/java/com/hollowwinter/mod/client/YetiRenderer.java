package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Yeti gorseli: zombi ile ayni insansi model (64x64 skin duzeni), 1.3 kat buyuk.
 * Skin: assets/hollowwinter/textures/entity/yeti.png
 */
public class YetiRenderer extends HumanoidMobRenderer<YetiEntity, HumanoidModel<YetiEntity>> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/yeti.png");
    private static final float SCALE = 1.3F;

    public YetiRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.9F);
    }

    @Override
    public ResourceLocation getTextureLocation(YetiEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(YetiEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }
}
