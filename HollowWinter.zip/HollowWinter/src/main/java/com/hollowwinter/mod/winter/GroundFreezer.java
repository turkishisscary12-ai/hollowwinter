package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Donmus zemin: kar yagmadan bir gun once (hazirlik doneminin son gunu) oyuncularin etrafindaki acik hava
 * yuzeyindeki cim ve topraklar "Donmus Cim" / "Donmus Toprak" bloklarina donusur. Bunlar daha yavas kirilir
 * ve kirilinca kendi isimleriyle (Donmus Cim / Donmus Toprak) duser. Donusum hizli yapilir; oyuncu
 * sabah uyandiginda etraf coktan donmus olur.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class GroundFreezer {

    /** Kar baslamadan bu kadar gun once donma baslar. */
    private static final double DAYS_BEFORE_WINTER = 1.0;
    private static final int RADIUS = 56;
    private static final int ATTEMPTS_PER_TICK = 150;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (WinterManager.daysSinceOrigin(level) < WinterManager.GRACE_DAYS - DAYS_BEFORE_WINTER) return;

        RandomSource rand = level.getRandom();
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            BlockPos c = player.blockPosition();
            for (int i = 0; i < ATTEMPTS_PER_TICK; i++) {
                int x = c.getX() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                int z = c.getZ() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;
                freezeSurface(level, x, z);
            }
        }
    }

    private static void freezeSurface(ServerLevel level, int x, int z) {
        // Kar katmanlari hareketi engellemedigi icin heightmap yuzeydeki sert blogun hemen ustunu verir.
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z)).below();
        BlockState s = level.getBlockState(top);

        BlockState result = null;
        if (s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.PODZOL) || s.is(Blocks.MYCELIUM)) {
            result = ModBlocks.FROZEN_GRASS_BLOCK.get().defaultBlockState();
        } else if (s.is(Blocks.DIRT) || s.is(Blocks.COARSE_DIRT) || s.is(Blocks.ROOTED_DIRT)) {
            result = ModBlocks.FROZEN_DIRT.get().defaultBlockState();
        }
        if (result != null) {
            level.setBlock(top, result, 3);
        }
    }
}
