package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

/**
 * Kis dongusu (oyun zamanina gore, uyumak sayaci atlatmaz):
 *  - Hazirlik: ilk GRACE_DAYS gun acik hava.
 *  - Sonra tekrar eden dongu:
 *      KAR ASAMASI  (8-10 gun): neredeyse surekli kar, kar yerde yukselir. Arada 2-6 dk molalar.
 *      ACIK ASAMA   (5-7 gun) : hava acik, birikmis kar kismen erir.
 *    Her donguden sonra ulasilan maksimum kar kalinligi artar.
 * Donguler dunya seed'inden turetildigi icin kayit tutmaya gerek yoktur.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class WinterManager {

    /** Kisin baslamasina kadar taninan gun sayisi. */
    public static final int GRACE_DAYS = 4;

    private static final long DAY_TICKS = 24000L;
    private static final long WINTER_START_TICKS = GRACE_DAYS * DAY_TICKS;

    /** Kar asamasi suresi (gun). */
    private static final int MIN_SNOW_DAYS = 8;
    private static final int MAX_SNOW_DAYS = 10;
    /** Acik hava asamasi suresi (gun). */
    private static final int MIN_CLEAR_DAYS = 5;
    private static final int MAX_CLEAR_DAYS = 7;

    /** Ilk donguden sonra ulasilan kar yuksekligi (katman; 8 katman = 1 blok): 344 = 43 blok. */
    private static final int FIRST_PEAK_LAYERS = 344;
    /** Her yeni dongude eklenen yukseklik (katman): 0 = hep ayni zirve. Ornek: 80 = her dongude +10 blok. */
    private static final int PEAK_GROWTH_LAYERS = 0;
    /** En fazla yukseklik (katman): 344 = 43 blok. Daha yuksek istersen once bunu, sonra FIRST_PEAK_LAYERS'i artir. */
    private static final int MAX_PEAK_LAYERS = 344;
    /** Acik havada kar zirvenin bu oranina kadar erir (0.55 = %45 erir). */
    private static final double MELT_KEEP_FRACTION = 0.55;
    /** Kar asamasinin yuzde kacinda hedef kalinliga ulasilir. */
    private static final double SNOW_RAMP_FRACTION = 0.85;

    /** Kar asamasindaki kisa acik hava molalari (tick): 2-6 dakika. */
    private static final int MIN_BREAK_TICKS = 2400;
    private static final int MAX_BREAK_TICKS = 7200;
    /** Tek bir kar yagisi suresi (tick): 15-50 dakika. */
    private static final int MIN_SNOW_TICKS = 18000;
    private static final int MAX_SNOW_TICKS = 60000;

    /** Mevcut kisa molanin biteceği oyun zamani. -1 = mola yok. */
    private static long breakUntil = -1L;

    /**
     * Su anki donguyu ve asamayi anlatir.
     * snowing: true = kar asamasi, false = acik hava (erime) asamasi.
     */
    public record Cycle(boolean snowing, int index, double daysIntoPhase, int phaseDays,
                        int startLayers, int peakLayers) {

        /** Erime sirasinda inilecek en dusuk kalinlik (katman). */
        public int floorLayers() {
            return (int) Math.round(peakLayers * MELT_KEEP_FRACTION);
        }

        /** Kar asamasinin su anki hedef kalinligi (katman). */
        public int targetLayers() {
            double ramp = Math.min(1.0, daysIntoPhase / (phaseDays * SNOW_RAMP_FRACTION));
            return (int) Math.round(startLayers + (peakLayers - startLayers) * ramp);
        }
    }

    private static int peakFor(int cycleIndex) {
        return Math.min(MAX_PEAK_LAYERS, FIRST_PEAK_LAYERS + PEAK_GROWTH_LAYERS * cycleIndex);
    }

    private static int startFor(int cycleIndex) {
        if (cycleIndex == 0) return 0;
        return (int) Math.round(peakFor(cycleIndex - 1) * MELT_KEEP_FRACTION);
    }

    public static boolean hasWinterStarted(ServerLevel level) {
        return level.getGameTime() >= WINTER_START_TICKS;
    }

    /** Kis baslamadiysa null doner. */
    @Nullable
    public static Cycle getCycle(ServerLevel level) {
        long t = level.getGameTime() - WINTER_START_TICKS;
        if (t < 0L) return null;

        double days = t / (double) DAY_TICKS;
        double cursor = 0.0;
        for (int i = 0; ; i++) {
            RandomSource r = RandomSource.create(level.getSeed() * 31L + i);
            int snowDays = MIN_SNOW_DAYS + r.nextInt(MAX_SNOW_DAYS - MIN_SNOW_DAYS + 1);
            int clearDays = MIN_CLEAR_DAYS + r.nextInt(MAX_CLEAR_DAYS - MIN_CLEAR_DAYS + 1);

            if (days < cursor + snowDays) {
                return new Cycle(true, i, days - cursor, snowDays, startFor(i), peakFor(i));
            }
            cursor += snowDays;
            if (days < cursor + clearDays) {
                return new Cycle(false, i, days - cursor, clearDays, startFor(i), peakFor(i));
            }
            cursor += clearDays;
        }
    }

    /** Kar asamasindayiz ve su an kar yagiyor mu? */
    public static boolean isSnowing(ServerLevel level) {
        Cycle c = getCycle(level);
        return c != null && c.snowing() && level.isRaining();
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % 100L != 0L) return;

        RandomSource rand = level.getRandom();
        long now = level.getGameTime();
        Cycle cycle = getCycle(level);

        // Hazirlik donemi ya da acik hava asamasi: hava hep acik
        if (cycle == null || !cycle.snowing()) {
            level.setWeatherParameters(6000, 0, false, false);
            breakUntil = -1L;
            return;
        }

        // Kar asamasi
        if (level.isRaining()) {
            breakUntil = -1L;
            return;
        }

        // Asamanin ilk saniyelerinde kar hemen baslasin
        if (cycle.daysIntoPhase() * DAY_TICKS < 200.0) {
            startSnow(level, rand);
            return;
        }

        if (breakUntil < 0L) {
            breakUntil = now + MIN_BREAK_TICKS + rand.nextInt(MAX_BREAK_TICKS - MIN_BREAK_TICKS);
        } else if (now >= breakUntil) {
            startSnow(level, rand);
        }
    }

    private static void startSnow(ServerLevel level, RandomSource rand) {
        int duration = MIN_SNOW_TICKS + rand.nextInt(MAX_SNOW_TICKS - MIN_SNOW_TICKS);
        level.setWeatherParameters(0, duration, true, false);
        breakUntil = -1L;
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        breakUntil = -1L; // ayni oyun oturumunda baska dunya acilinca eski mola kalmasin
    }
}
