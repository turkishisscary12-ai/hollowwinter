package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Karda yururken ayak izi birakir: oyuncunun bastigi kar blogunun bir katmani azalir (cukur olusur)
 * ve ayaklarin altindan kar tozu ucusur. Yeni kar yagdikca izler yavasca dolar.
 * Izler blok boyutundadir (ayakkabi seklinde degil); en az 1 katman kar her zaman kalir.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class FootprintHandler {

    /** Iki iz arasindaki en az yatay mesafe (blok). */
    private static final double STEP_DISTANCE = 0.9;
    private static final double STEP_DISTANCE_SQR = STEP_DISTANCE * STEP_DISTANCE;

    private static final Map<UUID, Vec3> LAST_PRINT = new HashMap<>();

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.isSpectator() || player.isPassenger() || player.isInWater()) return;
        if (!player.onGround()) return;

        Vec3 pos = player.position();
        Vec3 last = LAST_PRINT.get(player.getUUID());
        if (last == null) {
            LAST_PRINT.put(player.getUUID(), pos);
            return;
        }

        double dx = pos.x - last.x;
        double dz = pos.z - last.z;
        if (dx * dx + dz * dz < STEP_DISTANCE_SQR) return;

        ServerLevel level = player.serverLevel();
        BlockPos feet = player.blockPosition();
        BlockState state = level.getBlockState(feet);
        if (!state.is(Blocks.SNOW)) return; // sadece karli zeminde iz birakir

        LAST_PRINT.put(player.getUUID(), pos);

        int layers = state.getValue(SnowLayerBlock.LAYERS);
        if (layers >= 2) {
            level.setBlockAndUpdate(feet, state.setValue(SnowLayerBlock.LAYERS, layers - 1));
        }
        level.sendParticles(ParticleTypes.SNOWFLAKE,
                pos.x, feet.getY() + (layers * 0.125), pos.z,
                5, 0.2, 0.02, 0.2, 0.02);
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        LAST_PRINT.remove(event.getEntity().getUUID());
    }
}
