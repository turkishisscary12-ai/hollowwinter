package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.cold.ColdHandler;
import com.hollowwinter.mod.entity.YetiEntity;
import com.hollowwinter.mod.entity.YetiSnowBlock;
import com.hollowwinter.mod.network.ChaseFogPacket;
import com.hollowwinter.mod.network.ModNetwork;
import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.registry.ModSounds;
import com.hollowwinter.mod.winter.ChaseSnow;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.WinterData;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractGlassBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StainedGlassPaneBlock;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Yeti korku olaylari (hepsi sadece kis basladiktan EVENT_START_DAY gun sonra baslar):
 *  1) PENCERE : gece, dunyada en fazla 3 kez; ic mekandaki oyuncunun camini tiklatir. Oyuncu disari cikinca yeti yoktur.
 *  2) KOVALAMACA : gece, disaridaki oyuncuya kucuk ihtimalle. "Kaç." yazisi -> oyuncu arkasina bakinca 1-5 sayaci ->
 *     90 saniye kovalamaca (kar engelleri, kar topu, sis).
 *  3) SABAH IZLEME : sabah, uzaktan izler; bazen kar blogu atar (0.5 can + %10 soguk).
 * Test icin: /hollowwinter event chase|window|watch|stop
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class YetiEventManager {

    // ------------------------------------------------------------------ Ayarlar

    /** Olaylar kisin baslamasindan (4. gun) sonra bu gunden itibaren acilir. */
    private static final double EVENT_START_DAY = 6.0;

    private static final float WINDOW_CHANCE = 0.30F;          // gece basina %30
    private static final int WINDOW_MAX_PER_WORLD = 3;
    private static final int WINDOW_TICKS = 900;               // 45 sn

    private static final float CHASE_NIGHT_CHANCE = 0.4F;      // oyuncu basina gece basina
    /** Bu mesafedeki oyuncular "ayni grup" sayilir; kovalamaca gruptan sadece birine baslar. */
    private static final double GROUP_RADIUS = 64.0;
    private static final int WARN_TIMEOUT_TICKS = 400;         // 20 sn bakmazsa kovalamaca yine baslar
    private static final int CHASE_TICKS = 1800;               // 90 sn
    private static final double RUBBER_DISTANCE = 28.0;        // cok gerideyse yeti sisin icinde yaklasir
    private static final int OBSTACLE_INTERVAL = 120;          // 6 sn'de bir onune kar yigini
    private static final int DIRECT_THROW_INTERVAL = 200;      // 10 sn'de bir kar topu

    // Yere vurma: yeti yumrugunu yere indirir, oyuncuya dogru duz giden bir sok dalgasi cikar
    private static final int SLAM_INTERVAL = 160;              // 8 sn
    private static final int SLAM_WINDUP = 14;                 // vurmadan once ~0.7 sn hazirlik (kacmak icin isaret)
    private static final double SLAM_RANGE = 24.0;             // dalga uzunlugu
    private static final double SLAM_SPEED = 0.9;              // blok / tick
    private static final double SLAM_WIDTH = 1.7;              // dalganin yaricapi
    private static final float SLAM_DAMAGE = 4.0F;             // 2 kalp (en az yarim kalp birakir)
    private static final float SLAM_COLD = 5.0F;

    private static final float WATCH_MORNING_CHANCE = 0.5F;    // oyuncu basina sabah basina
    private static final int WATCH_TICKS = 1200;               // 60 sn
    private static final int WATCH_LOOK_TICKS = 100;           // 5 sn bakilirsa kaybolur
    private static final int WATCH_THROW_INTERVAL = 100;
    private static final float WATCH_THROW_CHANCE = 0.4F;

    // ------------------------------------------------------------------ Durumlar

    private enum Phase { WARN, COUNTDOWN, CHASE }

    private static final class ChaseState {
        final UUID yeti;
        Phase phase = Phase.WARN;
        int ticks = 0;
        int count = 0;
        int sinceObstacle = 0;
        int sinceThrow = 0;
        /** Kovalamaca uzak bir yerde geciyorsa: oyuncunun evi (geri donecegi yer). */
        Vec3 home;
        float homeYRot;
        float homeXRot;
        ChaseSnow.Area snow;
        // Sikisma tespiti
        Vec3 lastPos;
        int stuckChecks = 0;
        // Yere vurma (ileri giden sok dalgasi)
        int sinceSlam = 40;
        int slamWindup = 0;
        boolean slamActive = false;
        Vec3 slamOrigin = Vec3.ZERO;
        Vec3 slamDir = Vec3.ZERO;
        double slamTravel = 0.0;
        boolean slamHit = false;

        ChaseState(UUID yeti) {
            this.yeti = yeti;
        }
    }

    private static final class WindowState {
        final UUID yeti;
        final BlockPos pane;
        int ticks = 0;

        WindowState(UUID yeti, BlockPos pane) {
            this.yeti = yeti;
            this.pane = pane;
        }
    }

    private static final class WatchState {
        final UUID yeti;
        int ticks = 0;
        int lookTicks = 0;
        int sinceThrow = 0;

        WatchState(UUID yeti) {
            this.yeti = yeti;
        }
    }

    private static final class Plan {
        long day;
        boolean chase;
        int chaseAt;
        boolean chaseDone;
        boolean watch;
        int watchAt;
        boolean watchDone;
    }

    private static final Map<UUID, ChaseState> CHASES = new HashMap<>();
    private static final Map<UUID, WindowState> WINDOWS = new HashMap<>();
    private static final Map<UUID, WatchState> WATCHES = new HashMap<>();
    private static final Map<UUID, Plan> PLANS = new HashMap<>();
    private static final Set<UUID> TRACKED = new HashSet<>();

    private static long windowPlanDay = -1L;
    private static int windowPlanAt = 0;

    /** Yeti varligi (NORMAL disindaki modlarda) kendini silmeden once bu yoneticide kayitli olmali. */
    public static boolean isTracked(UUID yetiId) {
        return TRACKED.contains(yetiId);
    }

    /** Oyuncu su an bir yeti kovalamacasinin icinde mi (uzak yere alinmis olabilir). */
    public static boolean isChased(UUID playerId) {
        return CHASES.containsKey(playerId);
    }

    public static boolean isBusy(UUID playerId) {
        return busy(playerId);
    }

    private static boolean busy(UUID playerId) {
        return CHASES.containsKey(playerId) || WINDOWS.containsKey(playerId) || WATCHES.containsKey(playerId);
    }

    private static boolean eligible(ServerLevel level, ServerPlayer p) {
        return p.isAlive() && !p.isCreative() && !p.isSpectator() && p.level() == level;
    }

    // ------------------------------------------------------------------ Komut girisleri

    public static boolean forceChase(ServerPlayer p) {
        return startChase(p.serverLevel(), p);
    }

    public static boolean forceWindow(ServerPlayer p) {
        return startWindow(p.serverLevel(), p);
    }

    public static boolean forceWatch(ServerPlayer p) {
        return startWatch(p.serverLevel(), p);
    }

    public static void stopAll(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        UUID id = p.getUUID();
        ChaseState chase = CHASES.remove(id);
        if (chase != null) endChase(level, p, chase);
        WindowState window = WINDOWS.remove(id);
        if (window != null) discardYeti(level, window.yeti, false);
        WatchState watch = WATCHES.remove(id);
        if (watch != null) discardYeti(level, watch.yeti, false);
    }

    // ------------------------------------------------------------------ Yardimcilar

    @Nullable
    private static YetiEntity spawnYeti(ServerLevel level, Vec3 pos, int mode, ServerPlayer facing) {
        YetiEntity yeti = ModEntities.YETI.get().create(level);
        if (yeti == null) return null;
        yeti.moveTo(pos.x, pos.y, pos.z, 0.0F, 0.0F);
        yeti.setMode(mode);
        TRACKED.add(yeti.getUUID());
        level.addFreshEntity(yeti);
        face(yeti, facing);
        return yeti;
    }

    private static void face(YetiEntity yeti, ServerPlayer p) {
        yeti.lookAt(EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        yeti.yBodyRot = yeti.getYRot();
        yeti.setYHeadRot(yeti.getYRot());
    }

    private static void discardYeti(ServerLevel level, UUID yetiId, boolean poof) {
        TRACKED.remove(yetiId);
        Entity e = level.getEntity(yetiId);
        if (e == null) return;
        if (poof) {
            level.sendParticles(ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + 1.2, e.getZ(), 40, 0.5, 0.9, 0.5, 0.05);
            level.sendParticles(ParticleTypes.CLOUD, e.getX(), e.getY() + 1.2, e.getZ(), 15, 0.5, 0.9, 0.5, 0.02);
        }
        e.discard();
    }

    private static void sendFog(ServerPlayer p, boolean on) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new ChaseFogPacket(on));
    }

    private static void title(ServerPlayer p, Component text, int fadeIn, int stay, int fadeOut) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut));
        p.connection.send(new ClientboundSetTitleTextPacket(text));
    }

    /** Oyuncu yetiye (goruş acisi ~30 derece icinde ve engelsiz) bakiyor mu? */
    private static boolean isLookingAt(ServerPlayer p, Entity e) {
        Vec3 look = p.getViewVector(1.0F).normalize();
        Vec3 to = e.position().add(0.0, e.getBbHeight() * 0.6, 0.0).subtract(p.getEyePosition());
        if (to.lengthSqr() < 1.0E-6) return true;
        return look.dot(to.normalize()) > 0.85 && p.hasLineOfSight(e);
    }

    /** Oyuncunun baktigi yonun tersinde, kar yuzeyinde bir nokta bulur. */
    @Nullable
    private static Vec3 findBehind(ServerLevel level, ServerPlayer p, double dist) {
        return findBehind(level, p, dist, false);
    }

    /** ground=true: kar yigininin altindaki zemini kullanir (kar silinecekse). */
    @Nullable
    private static Vec3 findBehind(ServerLevel level, ServerPlayer p, double dist, boolean ground) {
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        if (flat.lengthSqr() < 1.0E-4) flat = new Vec3(0.0, 0.0, 1.0);
        flat = flat.normalize().scale(-1.0);

        for (int i = 0; i < 8; i++) {
            double angle = Math.toRadians((p.getRandom().nextDouble() - 0.5) * 50.0);
            Vec3 d = flat.yRot((float) angle);
            double bx = p.getX() + d.x * dist;
            double bz = p.getZ() + d.z * dist;
            Vec3 pos = ground ? SnowSurface.groundPos(level, bx, bz) : SnowSurface.standPos(level, bx, bz);
            if (pos != null && Math.abs(pos.y - p.getY()) < 8.0) return pos;
        }
        return null;
    }

    private static void shootAt(ServerLevel level, YetiEntity yeti, Vec3 target, boolean pile) {
        YetiSnowBlock projectile = new YetiSnowBlock(level, yeti);
        projectile.setPos(yeti.getX(), yeti.getEyeY() - 0.3, yeti.getZ());
        double dx = target.x - projectile.getX();
        double dy = target.y - projectile.getY();
        double dz = target.z - projectile.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        projectile.shoot(dx, dy + horizontal * 0.2, dz, 1.5F, pile ? 1.0F : 0.5F);
        projectile.setPileOnImpact(pile);
        level.addFreshEntity(projectile);
        level.playSound(null, yeti.blockPosition(), SoundEvents.SNOWBALL_THROW, SoundSource.HOSTILE, 1.2F, 0.7F);
    }

    // ------------------------------------------------------------------ 2) KOVALAMACA

    private static boolean startChase(ServerLevel level, ServerPlayer p) {
        if (busy(p.getUUID())) return false;
        Vec3 pos = findBehind(level, p, 16.0);
        if (pos == null) pos = findBehind(level, p, 12.0);
        if (pos == null) return false;

        YetiEntity yeti = spawnYeti(level, pos, YetiEntity.MODE_CHASER, p);
        if (yeti == null) return false;

        CHASES.put(p.getUUID(), new ChaseState(yeti.getUUID()));
        title(p, Component.translatable("message.hollowwinter.run").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), 5, 50, 20);
        p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.0F, 1.0F);
        return true;
    }

    private static void tickChases(ServerLevel level) {
        if (CHASES.isEmpty()) return;
        Iterator<Map.Entry<UUID, ChaseState>> it = CHASES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, ChaseState> entry = it.next();
            ChaseState st = entry.getValue();
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(entry.getKey());
            Entity e = level.getEntity(st.yeti);

            boolean valid = p != null && p.isAlive() && p.level() == level && e instanceof YetiEntity && e.isAlive();
            if (!valid) {
                endChase(level, p, st);
                it.remove();
                continue;
            }

            YetiEntity yeti = (YetiEntity) e;
            st.ticks++;
            boolean done = false;

            switch (st.phase) {
                case WARN -> {
                    face(yeti, p);
                    if (isLookingAt(p, yeti)) {
                        st.phase = Phase.COUNTDOWN;
                        st.ticks = 0;
                        st.count = 0;
                    } else if (st.ticks >= WARN_TIMEOUT_TICKS) {
                        beginRun(level, p, yeti, st);
                    }
                }
                case COUNTDOWN -> {
                    face(yeti, p);
                    if (st.ticks % 20 == 0) {
                        st.count++;
                        title(p, Component.literal(String.valueOf(st.count))
                                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), 0, 18, 2);
                        p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.0F, 1.0F);
                        if (st.count >= 5) beginRun(level, p, yeti, st);
                    }
                }
                case CHASE -> done = tickRun(level, p, yeti, st);
            }

            if (done) {
                endChase(level, p, st);
                it.remove();
            }
        }
    }

    private static final String HOME_KEY = "hollowwinter_chase_home";

    private static void beginRun(ServerLevel level, ServerPlayer p, YetiEntity yeti, ChaseState st) {
        st.phase = Phase.CHASE;
        st.ticks = 0;
        st.sinceObstacle = 60; // ilk engel ~3 sn sonra
        st.sinceThrow = 0;

        // Kovalamaca uzak bir yerde gecer: oyuncu arkadasinin gozu onunde kaybolur, bitince geri gelir.
        Vec3 remote = findRemote(level, p);
        if (remote != null) {
            st.home = p.position();
            st.homeYRot = p.getYRot();
            st.homeXRot = p.getXRot();
            CompoundTag home = new CompoundTag();
            home.putDouble("x", st.home.x);
            home.putDouble("y", st.home.y);
            home.putDouble("z", st.home.z);
            home.putFloat("yRot", st.homeYRot);
            home.putFloat("xRot", st.homeXRot);
            p.getPersistentData().put(HOME_KEY, home);

            p.teleportTo(level, remote.x, remote.y, remote.z, p.getYRot(), 0.0F);
            p.resetFallDistance();

            st.snow = new ChaseSnow.Area();
            st.snow.follow(p.getX(), p.getZ());
            st.snow.process(level);

            Vec3 behind = findBehind(level, p, 14.0, true);
            if (behind == null) behind = findBehind(level, p, 10.0, true);
            if (behind != null) {
                yeti.moveTo(behind.x, behind.y, behind.z, yeti.getYRot(), 0.0F);
                yeti.getNavigation().stop();
            } else {
                yeti.moveTo(remote.x + 12.0, remote.y, remote.z, yeti.getYRot(), 0.0F);
            }
            level.sendParticles(ParticleTypes.SNOWFLAKE, st.home.x, st.home.y + 1.0, st.home.z, 40, 0.5, 0.9, 0.5, 0.05);
        }

        yeti.setNoAi(false);
        yeti.setTarget(p);
        sendFog(p, true);
        p.playNotifySound(ModSounds.CHASE_MUSIC.get(), SoundSource.MUSIC, 1.0F, 1.0F);
        level.playSound(null, yeti.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 2.0F, 0.6F);
    }

    /** Oyuncunun uzaginda (350-550 blok), kar / su / yaprak olmayan bir zemin bulur. */
    @Nullable
    private static Vec3 findRemote(ServerLevel level, ServerPlayer p) {
        RandomSource r = level.getRandom();
        for (int i = 0; i < 6; i++) {
            double angle = r.nextDouble() * Math.PI * 2.0;
            double dist = 350.0 + r.nextDouble() * 200.0;
            double x = Math.floor(p.getX() + Math.cos(angle) * dist) + 0.5;
            double z = Math.floor(p.getZ() + Math.sin(angle) * dist) + 0.5;
            BlockPos col = BlockPos.containing(x, 0, z);
            if (!level.getWorldBorder().isWithinBounds(col)) continue;

            level.getChunk(col.getX() >> 4, col.getZ() >> 4); // gerekirse uretir
            Vec3 ground = SnowSurface.groundPos(level, x, z);
            if (ground == null) continue;

            BlockPos feet = BlockPos.containing(ground);
            if (level.getBlockState(feet).is(Blocks.SNOW)) continue;
            if (!level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()) continue;
            if (!level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty()) continue;
            return ground;
        }
        return null;
    }

    /** Kovalamaca tick'i. Bittiyse true doner. */
    private static boolean tickRun(ServerLevel level, ServerPlayer p, YetiEntity yeti, ChaseState st) {
        if (st.ticks >= CHASE_TICKS) return true;

        p.resetFallDistance(); // kovalamacada dusme hasari olmasin
        if (st.snow != null) {
            if (st.ticks % 10 == 0) st.snow.follow(p.getX(), p.getZ());
            st.snow.process(level);
        }

        if (st.ticks % 20 == 0) yeti.setTarget(p);
        // Muzik ~62 sn; kovalamaca 90 sn oldugu icin bitmeden basa sarilir
        if (st.ticks > 0 && st.ticks % 1240 == 0) {
            p.playNotifySound(ModSounds.CHASE_MUSIC.get(), SoundSource.MUSIC, 1.0F, 1.0F);
        }
        if (st.ticks % 14 == 0) {
            p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.2F, 1.1F);
        }

        double dist = yeti.distanceTo(p);

        // Yeti cok geride kaldiysa, sisin icinde oyuncunun arkasina isinlanir (baski surer).
        if (dist > RUBBER_DISTANCE && st.ticks % 20 == 0) {
            Vec3 pos = findBehind(level, p, 20.0);
            if (pos != null) {
                yeti.moveTo(pos.x, pos.y, pos.z, yeti.getYRot(), 0.0F);
                yeti.getNavigation().stop();
                yeti.setDeltaMovement(Vec3.ZERO);
            }
            return false;
        }

        // Yeti ASLA sikismasin: duvarin icindeyse ya da ilerleyemiyorsa etrafindaki bloklari kirar
        checkStuck(level, p, yeti, st, dist);
        if (tickSlam(level, p, yeti, st, dist)) return false; // hazirlik sirasinda baska saldiri yok

        st.sinceObstacle++;
        st.sinceThrow++;

        if (st.sinceObstacle >= OBSTACLE_INTERVAL && dist > 6.0 && dist < 30.0) {
            st.sinceObstacle = 0;
            Vec3 dir = p.getDeltaMovement().multiply(1.0, 0.0, 1.0);
            if (dir.lengthSqr() < 0.0004) dir = p.getLookAngle().multiply(1.0, 0.0, 1.0);
            if (dir.lengthSqr() > 1.0E-6) {
                Vec3 target = p.position().add(dir.normalize().scale(7.0));
                shootAt(level, yeti, target, true); // oyuncunun onune kar yigini
            }
        } else if (st.sinceThrow >= DIRECT_THROW_INTERVAL && dist > 5.0 && dist < 28.0) {
            st.sinceThrow = 0;
            shootAt(level, yeti, p.getEyePosition(), false); // dogrudan kar topu
        }
        return false;
    }

    // ---- Sikisma onleme

    private static void checkStuck(ServerLevel level, ServerPlayer p, YetiEntity yeti, ChaseState st, double dist) {
        // Duvarin / karin icindeyse hemen kir
        if (!level.noCollision(yeti)) {
            breakAround(level, yeti, p, 0);
            return;
        }
        if (st.ticks % 10 != 0) return;
        Vec3 now = yeti.position();
        if (st.lastPos != null && st.slamWindup == 0 && dist > 3.0
                && now.distanceToSqr(st.lastPos) < 0.16) {
            st.stuckChecks++;
            if (st.stuckChecks >= 2) {
                breakAround(level, yeti, p, 2);
                Vec3 to = p.position().subtract(now).multiply(1.0, 0.0, 1.0);
                if (to.lengthSqr() > 1.0E-6) {
                    Vec3 push = to.normalize().scale(0.45);
                    yeti.setDeltaMovement(push.x, 0.35, push.z);
                }
            }
            if (st.stuckChecks >= 5) { // hala sikismissa: oyuncunun arkasina isinla
                Vec3 pos = findBehind(level, p, 16.0, st.snow != null);
                if (pos != null) {
                    yeti.moveTo(pos.x, pos.y, pos.z, yeti.getYRot(), 0.0F);
                    yeti.getNavigation().stop();
                    yeti.setDeltaMovement(Vec3.ZERO);
                }
                st.stuckChecks = 0;
            }
        } else {
            st.stuckChecks = 0;
        }
        st.lastPos = now;
    }

    /** Yetinin etrafindaki (ve oyuncuya dogru 'reach' blok ilerisindeki) 3x4x3 bolgeyi kirar (esya dusmez). */
    private static void breakAround(ServerLevel level, YetiEntity yeti, ServerPlayer p, int reach) {
        BlockPos base = yeti.blockPosition();
        Vec3 to = p.position().subtract(yeti.position()).multiply(1.0, 0.0, 1.0);
        int sx = 0, sz = 0;
        if (to.lengthSqr() > 1.0E-6) {
            Vec3 n = to.normalize();
            sx = (int) Math.round(n.x);
            sz = (int) Math.round(n.z);
        }
        for (int k = 0; k <= reach; k++) {
            BlockPos c = base.offset(sx * k, 0, sz * k);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = 0; dy <= 3; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos bp = c.offset(dx, dy, dz);
                        BlockState bs = level.getBlockState(bp);
                        if (!bs.isAir() && bs.getFluidState().isEmpty() && bs.getDestroySpeed(level, bp) >= 0.0F) {
                            level.destroyBlock(bp, false);
                        }
                    }
                }
            }
        }
    }

    // ---- Yere vurma (ileri giden sok dalgasi)

    /** Slam durumunu isler. Hazirlik surerken true doner (baska saldiri yapilmaz). */
    private static boolean tickSlam(ServerLevel level, ServerPlayer p, YetiEntity yeti, ChaseState st, double dist) {
        st.sinceSlam++;

        if (st.slamWindup > 0) {
            yeti.getNavigation().stop();
            st.slamWindup--;
            level.sendParticles(ParticleTypes.CLOUD, yeti.getX(), yeti.getY() + 0.1, yeti.getZ(), 3, 0.6, 0.1, 0.6, 0.02);
            if (st.slamWindup == 0) {
                // Yumruk yere iner: dalga baslar
                st.slamActive = true;
                st.slamTravel = 0.0;
                st.slamHit = false;
                st.slamOrigin = yeti.position();
                level.playSound(null, yeti.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0F, 0.6F);
                level.sendParticles(ParticleTypes.EXPLOSION, yeti.getX() + st.slamDir.x * 1.2, yeti.getY() + 0.3,
                        yeti.getZ() + st.slamDir.z * 1.2, 2, 0.3, 0.1, 0.3, 0.0);
            }
            return true;
        }

        if (st.slamActive) {
            advanceWave(level, p, yeti, st);
            return false;
        }

        if (st.sinceSlam >= SLAM_INTERVAL && dist > 4.0 && dist < SLAM_RANGE - 2.0 && yeti.hasLineOfSight(p)) {
            Vec3 d = p.position().subtract(yeti.position()).multiply(1.0, 0.0, 1.0);
            if (d.lengthSqr() < 1.0E-6) return false;
            st.slamDir = d.normalize(); // yon hazirlik basinda kilitlenir; oyuncu yana kacarak kurtulabilir
            st.slamWindup = SLAM_WINDUP;
            st.sinceSlam = 0;
            yeti.getNavigation().stop();
            face(yeti, p);
            level.playSound(null, yeti.blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 1.5F, 0.7F);
            return true;
        }
        return false;
    }

    private static void advanceWave(ServerLevel level, ServerPlayer p, YetiEntity yeti, ChaseState st) {
        st.slamTravel += SLAM_SPEED;
        if (st.slamTravel >= SLAM_RANGE) {
            st.slamActive = false;
            return;
        }
        double wx = st.slamOrigin.x + st.slamDir.x * st.slamTravel;
        double wz = st.slamOrigin.z + st.slamDir.z * st.slamTravel;
        Vec3 ground = SnowSurface.groundPos(level, wx, wz);
        double wy = ground != null ? ground.y : yeti.getY();

        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SNOW_BLOCK.defaultBlockState()),
                wx, wy + 0.3, wz, 12, 0.7, 0.25, 0.7, 0.12);
        level.sendParticles(ParticleTypes.CLOUD, wx, wy + 0.2, wz, 2, 0.5, 0.1, 0.5, 0.02);
        if ((int) (st.slamTravel / SLAM_SPEED) % 3 == 0) {
            level.playSound(null, BlockPos.containing(wx, wy, wz), SoundEvents.SNOW_BREAK, SoundSource.HOSTILE, 2.0F, 0.7F);
        }

        // Oyuncu dalganin uzerinde ve yerdeyse (ziplayarak kurtulabilir) hasar alir
        if (!st.slamHit) {
            double dx = p.getX() - wx;
            double dz = p.getZ() - wz;
            boolean onLine = dx * dx + dz * dz <= SLAM_WIDTH * SLAM_WIDTH;
            boolean grounded = p.onGround() || p.getY() <= wy + 0.7;
            if (onLine && grounded && p.getY() >= wy - 2.0) {
                st.slamHit = true;
                float safe = Math.min(SLAM_DAMAGE, p.getHealth() - 1.0F); // olumcul olmasin
                if (safe > 0.0F) p.hurt(level.damageSources().mobAttack(yeti), safe);
                ColdHandler.addCold(p, SLAM_COLD);
                p.setDeltaMovement(st.slamDir.x * 0.6, 0.55, st.slamDir.z * 0.6);
                p.hurtMarked = true;
            }
        }
    }

    private static void endChase(ServerLevel level, @Nullable ServerPlayer p, ChaseState st) {
        discardYeti(level, st.yeti, true);
        if (p != null) {
            sendFog(p, false);
            p.connection.send(new ClientboundStopSoundPacket(ModSounds.CHASE_MUSIC.getId(), SoundSource.MUSIC));
            p.getPersistentData().remove(HOME_KEY);
            if (st.home != null && p.isAlive() && p.level() == level) {
                Vec3 back = SnowSurface.standPos(level, st.home.x, st.home.z);
                double y = (back != null && Math.abs(back.y - st.home.y) < 60.0) ? Math.max(back.y, st.home.y) : st.home.y;
                p.teleportTo(level, st.home.x, y, st.home.z, st.homeYRot, st.homeXRot);
                p.resetFallDistance();
            }
        }
        if (st.snow != null) ChaseSnow.beginRestore(st.snow); // silinen kar geri gelir
    }

    // ------------------------------------------------------------------ 1) PENCERE

    private record Window(BlockPos pane, Direction out) {}

    private static boolean isGlass(BlockState s) {
        return s.getBlock() instanceof AbstractGlassBlock
                || s.getBlock() instanceof StainedGlassPaneBlock
                || s.is(Blocks.GLASS_PANE);
    }

    private static boolean passable(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    /** Oyuncunun yakinindaki, bir tarafi ic mekan (gokyuzu yok), diger tarafi acik hava olan cam. */
    @Nullable
    private static Window findWindow(ServerLevel level, ServerPlayer p) {
        BlockPos center = p.blockPosition();
        if (SnowSurface.exposed(level, center)) return null; // oyuncu ic mekanda olmali

        List<Window> found = new ArrayList<>();
        for (BlockPos scan : BlockPos.betweenClosed(center.offset(-7, -2, -7), center.offset(7, 3, 7))) {
            if (!isGlass(level.getBlockState(scan))) continue;
            BlockPos pane = scan.immutable();
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos out = pane.relative(d);
                BlockPos in = pane.relative(d.getOpposite());
                if (passable(level, in) && !SnowSurface.exposed(level, in)
                        && passable(level, out) && passable(level, out.above()) && SnowSurface.exposed(level, out)) {
                    found.add(new Window(pane, d));
                }
            }
        }
        if (found.isEmpty()) return null;
        return found.get(level.getRandom().nextInt(found.size()));
    }

    private static boolean startWindow(ServerLevel level, ServerPlayer p) {
        if (busy(p.getUUID())) return false;
        Window w = findWindow(level, p);
        if (w == null) return false;

        Vec3 pos = Vec3.atBottomCenterOf(w.pane().relative(w.out()))
                .add(w.out().getStepX() * 0.35, -1.4, w.out().getStepZ() * 0.35);
        YetiEntity yeti = spawnYeti(level, pos, YetiEntity.MODE_WINDOW, p);
        if (yeti == null) return false;

        WINDOWS.put(p.getUUID(), new WindowState(yeti.getUUID(), w.pane()));
        return true;
    }

    private static void tickWindows(ServerLevel level) {
        if (WINDOWS.isEmpty()) return;
        Iterator<Map.Entry<UUID, WindowState>> it = WINDOWS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, WindowState> entry = it.next();
            WindowState st = entry.getValue();
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(entry.getKey());
            Entity e = level.getEntity(st.yeti);

            if (p == null || !p.isAlive() || p.level() != level || !(e instanceof YetiEntity)) {
                discardYeti(level, st.yeti, false);
                it.remove();
                continue;
            }
            YetiEntity yeti = (YetiEntity) e;
            st.ticks++;
            face(yeti, p);

            // Uc kisa tikirti, kisa aralikla tekrar eder
            int beat = st.ticks % 60;
            if (beat == 10 || beat == 18 || beat == 26) {
                level.playSound(null, st.pane.getX() + 0.5, st.pane.getY() + 0.5, st.pane.getZ() + 0.5,
                        SoundEvents.GLASS_HIT, SoundSource.HOSTILE, 2.0F, 0.85F + level.getRandom().nextFloat() * 0.25F);
            }

            // Oyuncu disari cikarsa yeti yoktur
            if (SnowSurface.exposed(level, p.blockPosition())) {
                discardYeti(level, st.yeti, true);
                it.remove();
                continue;
            }
            if (st.ticks >= WINDOW_TICKS) {
                discardYeti(level, st.yeti, false);
                it.remove();
            }
        }
    }

    // ------------------------------------------------------------------ 3) SABAH IZLEME

    private static boolean startWatch(ServerLevel level, ServerPlayer p) {
        if (busy(p.getUUID())) return false;
        RandomSource r = level.getRandom();

        for (int i = 0; i < 14; i++) {
            double angle = r.nextDouble() * Math.PI * 2.0;
            double dist = 26.0 + r.nextDouble() * 8.0;
            Vec3 pos = SnowSurface.standPos(level, p.getX() + Math.cos(angle) * dist, p.getZ() + Math.sin(angle) * dist);
            if (pos == null || Math.abs(pos.y - p.getY()) > 12.0) continue;

            // Oyuncu yetiyi gorebilmeli: aradaki engele bak
            BlockHitResult hit = level.clip(new ClipContext(p.getEyePosition(), pos.add(0.0, 2.0, 0.0),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (hit.getType() != HitResult.Type.MISS) continue;

            YetiEntity yeti = spawnYeti(level, pos, YetiEntity.MODE_WATCHER, p);
            if (yeti == null) return false;
            WATCHES.put(p.getUUID(), new WatchState(yeti.getUUID()));
            return true;
        }
        return false;
    }

    private static void tickWatches(ServerLevel level) {
        if (WATCHES.isEmpty()) return;
        Iterator<Map.Entry<UUID, WatchState>> it = WATCHES.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, WatchState> entry = it.next();
            WatchState st = entry.getValue();
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(entry.getKey());
            Entity e = level.getEntity(st.yeti);

            if (p == null || !p.isAlive() || p.level() != level || !(e instanceof YetiEntity)) {
                discardYeti(level, st.yeti, false);
                it.remove();
                continue;
            }
            YetiEntity yeti = (YetiEntity) e;
            st.ticks++;
            face(yeti, p);

            double dist = yeti.distanceTo(p);
            if (isLookingAt(p, yeti)) st.lookTicks++;
            else st.lookTicks = Math.max(0, st.lookTicks - 1);

            // Yaklasilirsa, uzun sure bakilirsa ya da sure dolarsa kaybolur
            if (dist < 14.0 || st.lookTicks >= WATCH_LOOK_TICKS || st.ticks >= WATCH_TICKS) {
                discardYeti(level, st.yeti, true);
                it.remove();
                continue;
            }

            st.sinceThrow++;
            if (st.sinceThrow >= WATCH_THROW_INTERVAL) {
                st.sinceThrow = 0;
                if (level.getRandom().nextFloat() < WATCH_THROW_CHANCE && dist < 36.0) {
                    shootAt(level, yeti, p.getEyePosition(), false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ Tetikleyiciler

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        tickChases(level);
        ChaseSnow.tickRestores(level);
        tickWindows(level);
        tickWatches(level);

        if (level.getGameTime() % 20L == 0L) {
            evaluateTriggers(level);
        }
    }

    private static void evaluateTriggers(ServerLevel level) {
        if (WinterManager.daysSinceOrigin(level) < EVENT_START_DAY) return;

        long dayTime = level.getDayTime();
        long day = dayTime / 24000L;
        int t = (int) (dayTime % 24000L);
        boolean night = t >= 13000 && t <= 23000;
        boolean morning = t >= 100 && t <= 3500;
        RandomSource rand = level.getRandom();
        WinterData data = WinterData.get(level);

        // --- Pencere olayi: dunya capinda, gece basina bir kez zar atilir
        if (night && data.lastWindowRollDay() != day) {
            data.setLastWindowRollDay(day);
            if (data.windowEvents() < WINDOW_MAX_PER_WORLD && rand.nextFloat() < WINDOW_CHANCE) {
                windowPlanDay = day;
                windowPlanAt = 14000 + rand.nextInt(7000);
            }
        }
        if (night && windowPlanDay == day && t >= windowPlanAt) {
            for (ServerPlayer p : level.players()) {
                if (!eligible(level, p)) continue;
                if (startWindow(level, p)) {
                    data.addWindowEvent();
                    windowPlanDay = -1L;
                    break;
                }
            }
        }

        // --- Kovalamaca (gece) ve sabah izleme: oyuncu basina gunluk plan
        for (ServerPlayer p : level.players()) {
            if (!eligible(level, p)) continue;

            Plan plan = PLANS.get(p.getUUID());
            if (plan == null || plan.day != day) {
                plan = new Plan();
                plan.day = day;
                plan.chase = rand.nextFloat() < CHASE_NIGHT_CHANCE;
                plan.chaseAt = 13500 + rand.nextInt(8500);
                plan.watch = rand.nextFloat() < WATCH_MORNING_CHANCE;
                plan.watchAt = 300 + rand.nextInt(2700);
                PLANS.put(p.getUUID(), plan);
            }

            boolean outdoors = SnowSurface.exposed(level, p.blockPosition());
            if (night && plan.chase && !plan.chaseDone && t >= plan.chaseAt && outdoors && !busy(p.getUUID())) {
                // Yakinda baska oyuncular varsa (ormanda iki kisi gibi) sadece biri rastgele secilir.
                List<ServerPlayer> group = new ArrayList<>();
                for (ServerPlayer o : level.players()) {
                    if (eligible(level, o) && !busy(o.getUUID()) && o.distanceToSqr(p) <= GROUP_RADIUS * GROUP_RADIUS
                            && SnowSurface.exposed(level, o.blockPosition())) {
                        group.add(o);
                    }
                }
                if (group.isEmpty()) group.add(p);
                ServerPlayer chosen = group.get(rand.nextInt(group.size()));
                boolean started = startChase(level, chosen) || (chosen != p && startChase(level, p));
                if (started) {
                    plan.chaseDone = true;
                    for (ServerPlayer o : group) { // gruptaki herkesin bu geceki kovalamaca hakki kullanilmis olur
                        Plan op = PLANS.get(o.getUUID());
                        if (op != null && op.day == day) op.chaseDone = true;
                    }
                }
            } else if (morning && plan.watch && !plan.watchDone && t >= plan.watchAt && outdoors && !busy(p.getUUID())) {
                if (startWatch(level, p)) plan.watchDone = true;
            }
        }
    }

    // ------------------------------------------------------------------ Oyuncu / sunucu olaylari

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            sendFog(p, false); // onceki oturumdan kalan sis olmasin
            // Kovalamaca sirasinda cikis yapildiysa / sunucu coktuyse oyuncuyu evine geri gonder
            CompoundTag home = p.getPersistentData().getCompound(HOME_KEY);
            if (!home.isEmpty() && !CHASES.containsKey(p.getUUID())) {
                p.teleportTo(p.serverLevel(), home.getDouble("x"), home.getDouble("y"), home.getDouble("z"),
                        home.getFloat("yRot"), home.getFloat("xRot"));
                p.getPersistentData().remove(HOME_KEY);
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            stopAll(p);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        CHASES.clear();
        WINDOWS.clear();
        WATCHES.clear();
        PLANS.clear();
        TRACKED.clear();
        windowPlanDay = -1L;
        ChaseSnow.clearAll();
    }
}
