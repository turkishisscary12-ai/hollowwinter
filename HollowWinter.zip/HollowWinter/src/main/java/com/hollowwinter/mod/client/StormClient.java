package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Kar firtinasinda oyuncunun etrafinda yatay savrulan kar tanecikleri (sadece istemci). */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, value = Dist.CLIENT)
public class StormClient {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        float k = ClientFogData.stormCurrent();
        if (k < 0.2F) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null || mc.isPaused()) return;

        RandomSource r = level.getRandom();
        int count = (int) (18 * k);
        for (int i = 0; i < count; i++) {
            double x = player.getX() + (r.nextDouble() - 0.5) * 24.0;
            double y = player.getY() + (r.nextDouble() - 0.3) * 10.0;
            double z = player.getZ() + (r.nextDouble() - 0.5) * 24.0;
            level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 1.1 + r.nextDouble() * 0.6, -0.1, 0.25);
        }
    }
}
