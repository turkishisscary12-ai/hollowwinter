package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.event.FrozenMobEvents;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraft.client.gui.screens.MenuScreens;
import com.hollowwinter.mod.registry.ModMenus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Sadece istemcide: HUD katmanlarini ve varlik gorsellerini kaydeder. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll("cold_frost", ColdOverlay::renderFrost);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "cold_bar", ColdOverlay::renderBar);
    }

    @SubscribeEvent
    public static void onRegisterParticles(net.minecraftforge.client.event.RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(com.hollowwinter.mod.registry.ModParticles.FOOTPRINT.get(), FootprintParticle.Provider::new);
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ModMenus.WATER_HEATER.get(), WaterHeaterScreen::new);
            MenuScreens.register(ModMenus.MINER.get(), MinerScreen::new);
            net.minecraft.client.renderer.ItemBlockRenderTypes.setRenderLayer(
                    com.hollowwinter.mod.registry.ModFluids.GASOLINE.get(), net.minecraft.client.renderer.RenderType.translucent());
            net.minecraft.client.renderer.ItemBlockRenderTypes.setRenderLayer(
                    com.hollowwinter.mod.registry.ModFluids.GASOLINE_FLOWING.get(), net.minecraft.client.renderer.RenderType.translucent());
        });
    }

    /** Donmus yaratiklar icin buz katmani (sadece ClientFrozenData'da isaretli olanlara cizilir). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @SubscribeEvent
    public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
        for (EntityType<?> type : FrozenMobEvents.TYPES) {
            LivingEntityRenderer renderer = event.getRenderer((EntityType) type);
            if (renderer != null) renderer.addLayer(new FrostLayer(renderer));
        }
    }

    /** Donmus esyalar: ana katman mavimsi tonlanir, ustune buz dokusu biner. */
    @SubscribeEvent
    public static void onItemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> tintIndex == 0 ? 0xDCEBFF : 0xFFFFFF,
                ModItems.FROZEN_ITEMS.stream().map(o -> (net.minecraft.world.level.ItemLike) o.get())
                        .toArray(net.minecraft.world.level.ItemLike[]::new));
    }

    @SubscribeEvent
    public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MammothModel.LAYER, MammothModel::createBodyLayer);
        event.registerLayerDefinition(PenguinModel.LAYER, PenguinModel::createBodyLayer);
        event.registerLayerDefinition(OwlModel.LAYER, OwlModel::createBodyLayer);
        event.registerLayerDefinition(SledModel.LAYER, SledModel::createLayer);
        event.registerLayerDefinition(DrillModel.LAYER, DrillModel::createLayer);
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.YETI.get(), YetiRenderer::new);
        event.registerEntityRenderer(ModEntities.MAMMOTH.get(), MammothRenderer::new);
        event.registerEntityRenderer(ModEntities.PENGUIN.get(), PenguinRenderer::new);
        event.registerEntityRenderer(ModEntities.SHADOW_FIGURE.get(), ShadowFigureRenderer::new);
        event.registerEntityRenderer(ModEntities.OWL.get(), OwlRenderer::new);
        event.registerEntityRenderer(ModEntities.SLED.get(), SledRenderer::new);
        event.registerBlockEntityRenderer(com.hollowwinter.mod.registry.ModBlockEntities.MINER.get(), MinerRenderer::new);
        event.registerEntityRenderer(ModEntities.YETI_SNOW_BLOCK.get(), ThrownItemRenderer::new);
    }
}
