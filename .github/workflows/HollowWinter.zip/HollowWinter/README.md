# Hollow Winter

Minecraft 1.20.1 (Forge 47.3.0) icin kis kiyameti modu.

## Kurulum
1. JDK 17 kur.
2. IntelliJ IDEA ile `build.gradle` dosyasini "Open as Project" ile ac.
3. Gradle wrapper yoksa: Forge 1.20.1 MDK'sindan `gradlew`, `gradlew.bat` ve `gradle/` klasorunu bu klasore kopyala
   (https://files.minecraftforge.net/ -> 1.20.1 -> MDK).
4. `./gradlew genIntellijRuns` sonra `runClient` ile test et.
5. `./gradlew build` ile jar `build/libs/` icine cikar.

## Su an olanlar
- Soguk sistemi (`cold/ColdHandler.java`): 0-100 soguk degeri, isi kaynaklari, zirh korumasi, gece/kar etkisi. %90+ 4 sn'de 1 can, %100 her saniye 1 can kaybi.
- Soguk HUD'u (`client/ColdOverlay.java`): hotbar ustunde renkli bar, kar tanesi ikonu, yuzde, isinma/soguma oku; %40+ ekran kenarlarinda buzlanma. Deger sunucudan `ColdSyncPacket` ile gelir.
- Ayak izleri (`winter/FootprintHandler.java`): karda yururken blok boyutunda cukur + kar tozu parcaciklari, yeni kar yagdikca dolar.
- Kurk zirh seti (`registry/`, `item/`): 4 parca + Kurk Parcasi (hayvanlardan duser). Tam set soguktan korur.
- Kis takvimi (`winter/WinterManager.java`, `WinterData.java`): sureler MINECRAFT GUNU. Mod dunyada ilk calistigindan 4 gun sonra kar baslar; 7-9 gun kar, sonra 5-6 gun acik hava; 20-30. gunlerde acik hava ~1 gune kisalir. `/hollowwinter status` ile takvim gorulur.
- Her biyomda kar efekti (`mixin/BiomeMixin.java`): yagmur yerine kar yagar.
- Kar birikimi ve erime (`winter/SnowAccumulator.java`): kar gunde ~1 blok yavasca yukselir, acik havada gunde ~3/8 blok erir, en fazla 43 blok. Cicek/fidan/ekin kirilip yerine kar gelir; patika ve tarla topraga donusup kar tutar.

## Ayarlar
- Kisin baslama gunu: `WinterManager.GRACE_DAYS`
- Takvim, hizlar ve yukseklik: `WinterManager` basindaki sabitler (GRACE_DAYS, MIN/MAX_SNOW_DAYS, EARLY_UNTIL_DAY, LATE_FROM_DAY, ACCUM/MELT_LAYERS_PER_DAY, MAX_LAYERS)
- Kar/erime hizi: `SnowAccumulator` basindaki ATTEMPTS sabitleri
- Not: kar sadece oyuncunun 56 blok yakinindaki yuklu alanda degisir

## Bilinen eksikler
- Mixin (`mixin/BiomeMixin.java`) her biyomda yagisi kar yapar. Henuz oyunda test edilmedi; calismazsa `Biome.getPrecipitationAt` adini kontrol et.

## Siradaki fikirler
- Kar firtinasi olayi
- Yakacak sistemi (ocak/kamp atesi odunla yansin)
- Schematic'lerden yapilar (NBT)

## Yeti
- Kis basladiktan 6 gun sonra olaylar acilir: pencere tikirtisi (dunyada max 3, gece %30), gece "Kac." kovalamacasi (90 sn, sis), sabah izleme + kar blogu (0.5 can, +10 soguk).
- Test: `/hollowwinter event chase|window|watch|stop` (op).
- Skin: `assets/hollowwinter/textures/entity/yeti.png` (64x64) dosyasini kendi skininle degistir.
- Spawn yumurtasi: Hollow Winter sekmesinde.
