package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.network.ModNetwork;
import com.hollowwinter.mod.network.StormPacket;
import com.hollowwinter.mod.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Kar firtinasi. Kar asamasinda, kar yagarken, gunun rastgele (dunya seed'inden turetilen) bir saatinde
 * 3-6 dakikalik siddetli firtina cikar. Etkileri:
 *  - Cok yogun beyaz sis, savrulan kar, ruzgar sesi (istemci).
 *  - Disarida soguk hizla artar (zirhla bile yavasca); ic mekanda soguk artmaz (ColdHandler).
 *  - Kar normalden hizli ve zamanlamanin 3 blok ustune kadar yukselir (SnowAccumulator).
 *  - Belli bir sansla ahsap/yun cati bloklari kopup ucar.
 * Test: /hollowwinter storm start|stop
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class StormManager {

    // ------------------------------------------------------------------ Ayarlar

    /** Her gun firtina olma sansi. */
    private static final float DAILY_STORM_CHANCE = 0.25F;
    private static final int MIN_STORM_TICKS = 3600;   // 3 dk
    private static final int MAX_STORM_TICKS = 7200;   // 6 dk

    /** Firtinada kar ekleme hizi carpani (firtina bitene kadar kar bu hizla birikir). */
    /** Firtinada kar ekleme hizi carpani. */
    public static final int STORM_SNOW_SPEEDUP = 3;

    /** Cati kopma: her oyuncu icin her 10 sn'de bu sansla. */
    private static final float ROOF_RIP_CHANCE = 0.30F;
    private static final int ROOF_RIP_INTERVAL = 200;   // 10 sn'de bir zar
    private static final int ROOF_MAX_BLOCKS = 12;
    private static final int ROOF_SEARCH_ATTEMPTS = 80;

    private static final int WIND_LOOP_TICKS = 600; // storm_wind.ogg 30 sn

    // ------------------------------------------------------------------ Durum

    /** Komutla zorlanan firtina bitis zamani / bastirma bitis zamani (oyun tick'i). */
    private static long forcedUntil = -1L;
    private static long suppressedUntil = -1L;

    private static final Set<UUID> NOTIFIED = new HashSet<>();
    private static final Map<UUID, Long> NEXT_WIND = new HashMap<>();

    // ------------------------------------------------------------------ Sorgular

    public static boolean isStorm(ServerLevel level) {
        long now = level.getGameTime();
        if (now < forcedUntil) return true;
        if (now < suppressedUntil) return false;

        WinterManager.Cycle cycle = WinterManager.getCycle(level);
        if (cycle == null || !cycle.snowing() || !level.isRaining()) return false;

        long dayTime = level.getDayTime();
        long day = dayTime / 24000L;
        RandomSource r = RandomSource.create(level.getSeed() * 7919L + day * 104729L);
        if (r.nextFloat() >= DAILY_STORM_CHANCE) return false;
        int duration = MIN_STORM_TICKS + r.nextInt(MAX_STORM_TICKS - MIN_STORM_TICKS);
        int start = r.nextInt(24000 - duration);
        int t = (int) (dayTime % 24000L);
        return t >= start && t < start + duration;
    }

    /** Firtinanin esme yonu (gun basina sabit). */
    private static Vec3 windDirection(ServerLevel level) {
        long day = level.getDayTime() / 24000L;
        RandomSource r = RandomSource.create(level.getSeed() + day * 31L);
        double a = r.nextDouble() * Math.PI * 2.0;
        return new Vec3(Math.cos(a), 0.0, Math.sin(a));
    }

    // ------------------------------------------------------------------ Komutlar

    public static void forceStart(ServerLevel level) {
        forcedUntil = level.getGameTime() + 4800L;
        suppressedUntil = -1L;
        level.setWeatherParameters(0, 6000, true, false); // kar yagsin
    }

    public static void forceStop(ServerLevel level) {
        forcedUntil = -1L;
        suppressedUntil = level.getGameTime() + 24000L;
    }

    // ------------------------------------------------------------------ Tick

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        long now = level.getGameTime();
        if (now % 20L != 0L) return;

        boolean storm = isStorm(level);
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            UUID id = p.getUUID();
            boolean here = storm && p.level() == level;
            boolean known = NOTIFIED.contains(id);

            if (here && !known) {
                NOTIFIED.add(id);
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new StormPacket(true));
                p.displayClientMessage(Component.literal("Kar fırtınası başladı!"), true);
                NEXT_WIND.put(id, now);
            } else if (!here && known) {
                endFor(p);
            }

            if (here) {
                if (now >= NEXT_WIND.getOrDefault(id, now)) {
                    float vol = SnowSurface.exposed(level, p.blockPosition()) ? 0.9F : 0.4F;
                    p.playNotifySound(ModSounds.STORM_WIND.get(), SoundSource.WEATHER, vol, 1.0F);
                    NEXT_WIND.put(id, now + WIND_LOOP_TICKS - 10);
                }
                // Disaridaki oyuncu firtinada zor yurur (agir yavaslik)
                if (!p.isSpectator() && !p.isCreative() && SnowSurface.exposed(level, p.blockPosition())) {
                    p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, true, false));
                }
                if (now % ROOF_RIP_INTERVAL == 0L && level.getRandom().nextFloat() < ROOF_RIP_CHANCE
                        && !p.isSpectator()) {
                    tryRipRoof(level, p);
                }
            }
        }
    }

    private static void endFor(ServerPlayer p) {
        NOTIFIED.remove(p.getUUID());
        NEXT_WIND.remove(p.getUUID());
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new StormPacket(false));
        p.connection.send(new ClientboundStopSoundPacket(ModSounds.STORM_WIND.getId(), SoundSource.WEATHER));
    }

    // ------------------------------------------------------------------ Cati kopmasi

    /** Ev catisi sayilan insan yapimi bloklar (ahsap, tas, tugla, yun, kiremit, saman, tik...). */
    private static boolean isRoofBlock(BlockState s) {
        return s.is(BlockTags.PLANKS) || s.is(BlockTags.SLABS) || s.is(BlockTags.STAIRS)
                || s.is(BlockTags.WOOL) || s.is(BlockTags.TERRACOTTA)
                || s.is(Blocks.HAY_BLOCK) || s.is(Blocks.COBBLESTONE) || s.is(Blocks.STONE_BRICKS)
                || s.is(Blocks.BRICKS) || s.is(Blocks.MOSSY_COBBLESTONE) || s.is(Blocks.MOSSY_STONE_BRICKS)
                || s.is(Blocks.DEEPSLATE_BRICKS) || s.is(Blocks.DEEPSLATE_TILES) || s.is(Blocks.COBBLED_DEEPSLATE);
    }

    /** Ev: ustte insan yapimi cati blogu, altinda en az 2 blok yuksekliginde ic mekan boslugu olan yapi. */
    private static boolean isHouseRoof(ServerLevel level, BlockPos top) {
        if (!isRoofBlock(level.getBlockState(top))) return false;
        BlockPos in1 = top.below();
        BlockPos in2 = top.below(2);
        return level.getBlockState(in1).getCollisionShape(level, in1).isEmpty()
                && level.getBlockState(in2).getCollisionShape(level, in2).isEmpty()
                && level.getFluidState(in1).isEmpty();
    }

    /** Oyuncunun yakinindaki (kendi evi dahil) bir evin catisini bulup bir kismini soker ve ucurur. */
    private static void tryRipRoof(ServerLevel level, ServerPlayer p) {
        RandomSource r = level.getRandom();
        Vec3 wind = windDirection(level);

        for (int attempt = 0; attempt < ROOF_SEARCH_ATTEMPTS; attempt++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            double dist = 2.0 + r.nextDouble() * 46.0;
            BlockPos column = BlockPos.containing(p.getX() + Math.cos(ang) * dist, 0, p.getZ() + Math.sin(ang) * dist);
            if (!level.hasChunkAt(column)) continue;

            BlockPos top = topSolid(level, column);
            if (!isHouseRoof(level, top)) continue;

            List<BlockPos> cluster = new ArrayList<>();
            for (int dx = -3; dx <= 3 && cluster.size() < ROOF_MAX_BLOCKS; dx++) {
                for (int dz = -3; dz <= 3 && cluster.size() < ROOF_MAX_BLOCKS; dz++) {
                    BlockPos t = topSolid(level, top.offset(dx, 0, dz));
                    if (Math.abs(t.getY() - top.getY()) <= 1 && isHouseRoof(level, t)) {
                        cluster.add(t);
                    }
                }
            }
            if (cluster.isEmpty()) continue;

            for (BlockPos pos : cluster) {
                BlockState bs = level.getBlockState(pos);
                // ustundeki kari temizle
                BlockPos up = pos.above();
                while (level.getBlockState(up).is(Blocks.SNOW)) {
                    level.removeBlock(up, false);
                    up = up.above();
                }
                FallingBlockEntity fb = FallingBlockEntity.fall(level, pos, bs);
                fb.dropItem = false;
                fb.setDeltaMovement(
                        wind.x * (0.8 + r.nextDouble() * 0.8) + (r.nextDouble() - 0.5) * 0.3,
                        0.6 + r.nextDouble() * 0.6,
                        wind.z * (0.8 + r.nextDouble() * 0.8) + (r.nextDouble() - 0.5) * 0.3);
                level.addFreshEntity(fb); // fall() eklediyse yinelenen UUID reddedilir
                level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5,
                        4, 0.3, 0.2, 0.3, 0.02);
            }
            BlockPos c = cluster.get(0);
            level.playSound(null, c, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 4.0F, 0.6F);
            p.displayClientMessage(Component.literal("Rüzgâr bir çatıyı söküp savurdu!"), true);
            return;
        }
    }

    /** Sutundaki en ustteki hareket-engelleyen blok (kar katmanlari sayilmaz). */
    private static BlockPos topSolid(ServerLevel level, BlockPos anyInColumn) {
        return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, anyInColumn).below();
    }

    // ------------------------------------------------------------------ Oyuncu / sunucu

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            NOTIFIED.remove(p.getUUID());
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new StormPacket(false));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        NOTIFIED.remove(event.getEntity().getUUID());
        NEXT_WIND.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        forcedUntil = -1L;
        suppressedUntil = -1L;
        NOTIFIED.clear();
        NEXT_WIND.clear();
    }
}
