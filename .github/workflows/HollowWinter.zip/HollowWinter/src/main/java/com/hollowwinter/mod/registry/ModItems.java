package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.item.FurArmorItem;
import com.hollowwinter.mod.item.TeaItem;
import com.hollowwinter.mod.item.WaterCupItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, HollowWinter.MODID);

    public static final RegistryObject<Item> PELT = ITEMS.register("pelt",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> FUR_HELMET = ITEMS.register("fur_helmet",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> FUR_CHESTPLATE = ITEMS.register("fur_chestplate",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> FUR_LEGGINGS = ITEMS.register("fur_leggings",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> FUR_BOOTS = ITEMS.register("fur_boots",
            () -> new FurArmorItem(ModArmorMaterials.FUR, ArmorItem.Type.BOOTS, new Item.Properties()));

    public static final RegistryObject<Item> EMPTY_CUP = ITEMS.register("empty_cup",
            () -> new WaterCupItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> WATER_CUP = ITEMS.register("water_cup",
            () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> TEA_LEAVES = ITEMS.register("tea_leaves",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> TEA = ITEMS.register("tea",
            () -> new TeaItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> YETI_SPAWN_EGG = ITEMS.register("yeti_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.YETI, 0xE8F0F8, 0x6C8CA8, new Item.Properties()));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
