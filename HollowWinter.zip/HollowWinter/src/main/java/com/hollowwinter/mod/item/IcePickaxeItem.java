package com.hollowwinter.mod.item;

import com.hollowwinter.mod.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Buz kazma: kazdigi blogun etrafindaki 3 blogu (tek yumrukla kirilan) donmus bloga cevirir. */
public class IcePickaxeItem extends PickaxeItem implements IceTool {
    private static final int FREEZE_COUNT = 3;

    public IcePickaxeItem(Properties properties) {
        super(Tiers.IRON, 1, -2.8F, properties.durability(180));
    }

    @Override
    public boolean mineBlock(ItemStack stack, Level level, BlockState state, BlockPos pos, LivingEntity miner) {
        boolean result = super.mineBlock(stack, level, state, pos, miner);
        if (level.isClientSide || state.is(ModBlocks.FROZEN_BLOCK.get())) return result;

        List<Direction> dirs = new ArrayList<>(List.of(Direction.values()));
        Collections.shuffle(dirs, new Random(level.getRandom().nextLong()));
        int frozen = 0;
        for (Direction d : dirs) {
            if (frozen >= FREEZE_COUNT) break;
            BlockPos p = pos.relative(d);
            if (canFreeze(level, p)) {
                level.setBlock(p, ModBlocks.FROZEN_BLOCK.get().defaultBlockState(), 3);
                frozen++;
            }
        }
        if (frozen > 0) {
            level.playSound(null, pos, SoundEvents.POWDER_SNOW_PLACE, SoundSource.BLOCKS, 1.0F, 1.2F);
        }
        return result;
    }

    private static boolean canFreeze(Level level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        return !s.isAir()
                && s.getFluidState().isEmpty()
                && !s.hasBlockEntity()
                && !s.is(BlockTags.WITHER_IMMUNE)
                && s.getDestroySpeed((BlockGetter) level, pos) >= 0.0F
                && !s.is(ModBlocks.FROZEN_BLOCK.get());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.hollowwinter.ice_pickaxe.tooltip"));
    }
}
