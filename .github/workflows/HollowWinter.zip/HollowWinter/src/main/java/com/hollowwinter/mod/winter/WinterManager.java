package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;

/**
 * Kis takvimi. Sureler MINECRAFT GUNU olarak sayilir (F3'teki "Day"; uyuyunca gece atlanir, gun ilerler).
 * Sayim, modun o dunyada ilk calistigi andan baslar (WinterData).
 *
 *  - Gun 0-4          : hazirlik, hava acik, kar yok.
 *  - Sonra dongu      : KAR ASAMASI (7-9 gun) -> ACIK HAVA ASAMASI -> tekrar kar ...
 *  - Acik hava suresi : ilk 20 gunde 5-6 gun; 20-30. gunlerde yavas yavas ~1 gune duser; 30'dan sonra ~1 gun.
 *  - Kar yuksekligi   : kar asamasinda yavasca artar (gunde 1 blok), acik havada yavasca erir (gunde ~3/8 blok).
 *    En fazla 43 blok. Takvim dunya seed'inden turetilir, ayri bir kayda gerek yoktur.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class WinterManager {

    /** Kisin baslamasina kadar taninan Minecraft gunu. */
    public static final int GRACE_DAYS = 4;

    private static final long DAY_TICKS = 24000L;

    /** Kar asamasi suresi (gun). */
    private static final int MIN_SNOW_DAYS = 7;
    private static final int MAX_SNOW_DAYS = 9;

    /** Acik hava suresi: bu gune kadar 5-6 gun. */
    private static final double EARLY_UNTIL_DAY = 20.0;
    /** Bu gunden sonra acik hava ~1 gun. 20 ile 30 arasi yavas yavas kisalir. */
    private static final double LATE_FROM_DAY = 30.0;

    /** Kar yuksekligi hizlari (katman/gun; 8 katman = 1 blok). */
    private static final double ACCUM_LAYERS_PER_DAY = 8.0;
    private static final double MELT_LAYERS_PER_DAY = 3.0;
    /** En fazla kar yuksekligi (katman): 344 = 43 blok. */
    private static final double MAX_LAYERS = 344.0;

    /** Kar asamasindaki kisa acik hava molalari (tick): 2-6 dakika. */
    private static final int MIN_BREAK_TICKS = 2400;
    private static final int MAX_BREAK_TICKS = 7200;
    /** Tek bir kar yagisi suresi (tick): 15-50 dakika. */
    private static final int MIN_SNOW_TICKS = 18000;
    private static final int MAX_SNOW_TICKS = 60000;

    /** Mevcut kisa molanin biteceği oyun zamani. -1 = mola yok. */
    private static long breakUntil = -1L;

    /**
     * Su anki asama.
     * snowing: true = kar asamasi, false = acik hava (erime) asamasi.
     * targetLayers: bu andaki hedef kar yuksekligi (katman).
     */
    public record Cycle(boolean snowing, double daysIntoPhase, double phaseDays, int targetLayers) {}

    /** Modun bu dunyada ilk calistigindan beri gecen Minecraft gunu (kesirli). */
    public static double daysSinceOrigin(ServerLevel level) {
        long now = level.getDayTime();
        long origin = WinterData.get(level).originTick(now);
        return (now - origin) / (double) DAY_TICKS;
    }

    public static boolean hasWinterStarted(ServerLevel level) {
        return daysSinceOrigin(level) >= GRACE_DAYS;
    }

    private static double clearDaysFor(double startDay, int coin, double jitter) {
        if (startDay < EARLY_UNTIL_DAY) {
            return 5 + coin; // 5 veya 6 gun
        }
        if (startDay < LATE_FROM_DAY) {
            double t = (startDay - EARLY_UNTIL_DAY) / (LATE_FROM_DAY - EARLY_UNTIL_DAY);
            double base = Mth.lerp(t, 5.5, 1.0);
            return Math.max(1.0, base + (jitter - 0.5));
        }
        return 1.0 + jitter * 0.5; // 1 - 1.5 gun
    }

    /** Kis baslamadiysa null doner. */
    @Nullable
    public static Cycle getCycle(ServerLevel level) {
        double days = daysSinceOrigin(level);
        if (days < GRACE_DAYS) return null;

        double cursor = GRACE_DAYS;
        double depth = 0.0; // katman

        for (int i = 0; i < 100000; i++) {
            RandomSource r = RandomSource.create(level.getSeed() * 31L + i);
            int snowDays = MIN_SNOW_DAYS + r.nextInt(MAX_SNOW_DAYS - MIN_SNOW_DAYS + 1);
            int coin = r.nextInt(2);
            double jitter = r.nextDouble();

            double snowEnd = cursor + snowDays;
            if (days < snowEnd) {
                double into = days - cursor;
                double target = Math.min(MAX_LAYERS, depth + ACCUM_LAYERS_PER_DAY * into);
                return new Cycle(true, into, snowDays, (int) Math.round(target));
            }
            depth = Math.min(MAX_LAYERS, depth + ACCUM_LAYERS_PER_DAY * snowDays);

            double clearDays = clearDaysFor(snowEnd, coin, jitter);
            double clearEnd = snowEnd + clearDays;
            if (days < clearEnd) {
                double into = days - snowEnd;
                double target = Math.max(0.0, depth - MELT_LAYERS_PER_DAY * into);
                return new Cycle(false, into, clearDays, (int) Math.round(target));
            }
            depth = Math.max(0.0, depth - MELT_LAYERS_PER_DAY * clearDays);
            cursor = clearEnd;
        }
        return new Cycle(true, 0.0, 1.0, (int) Math.round(depth));
    }

    /** Kar asamasindayiz ve su an kar yagiyor mu? */
    public static boolean isSnowing(ServerLevel level) {
        Cycle c = getCycle(level);
        return c != null && c.snowing() && level.isRaining();
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % 100L != 0L) return;

        RandomSource rand = level.getRandom();
        long now = level.getGameTime();
        Cycle cycle = getCycle(level);

        // Hazirlik donemi ya da acik hava asamasi: hava hep acik
        if (cycle == null || !cycle.snowing()) {
            level.setWeatherParameters(6000, 0, false, false);
            breakUntil = -1L;
            return;
        }

        // Kar asamasi
        if (level.isRaining()) {
            breakUntil = -1L;
            return;
        }

        // Asamanin ilk saniyelerinde kar hemen baslasin
        if (cycle.daysIntoPhase() * DAY_TICKS < 200.0) {
            startSnow(level, rand);
            return;
        }

        if (breakUntil < 0L) {
            breakUntil = now + MIN_BREAK_TICKS + rand.nextInt(MAX_BREAK_TICKS - MIN_BREAK_TICKS);
        } else if (now >= breakUntil) {
            startSnow(level, rand);
        }
    }

    private static void startSnow(ServerLevel level, RandomSource rand) {
        int duration = MIN_SNOW_TICKS + rand.nextInt(MAX_SNOW_TICKS - MIN_SNOW_TICKS);
        level.setWeatherParameters(0, duration, true, false);
        breakUntil = -1L;
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        breakUntil = -1L; // ayni oyun oturumunda baska dunya acilinca eski mola kalmasin
    }
}
