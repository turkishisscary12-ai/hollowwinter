package com.hollowwinter.mod.block;

import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Meyveli calı (cay calisi / cilek calisi). AGE 0 = bos, AGE 1 = meyveli.
 * Sag tikla toplanir, 10 dakika sonra tekrar buyur. Cilek calisinda 5. gunden sonra meyveler donar (FROZEN).
 * Kar altinda ezilmez (BushBlock degil).
 */
public class FruitBushBlock extends Block {
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 1);
    public static final BooleanProperty FROZEN = BooleanProperty.create("frozen");
    /** Toplandiktan sonra yeniden buyume suresi: 10 dakika. */
    public static final int REGROW_TICKS = 12000;
    /** Cilekler bu gunden sonra donar. */
    public static final int FREEZE_DAY = 5;
    private static final VoxelShape SHAPE = Block.box(1.0D, 0.0D, 1.0D, 15.0D, 13.0D, 15.0D);

    private final boolean strawberry;

    public FruitBushBlock(Properties properties, boolean strawberry) {
        super(properties);
        this.strawberry = strawberry;
        this.registerDefaultState(this.stateDefinition.any().setValue(AGE, 0).setValue(FROZEN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AGE, FROZEN);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    private static boolean isFreezeTime(Level level) {
        return level instanceof ServerLevel sl && sl.dimension() == Level.OVERWORLD
                && WinterManager.daysSinceOrigin(sl) >= FREEZE_DAY;
    }

    // ---- Zemin

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockState below = level.getBlockState(pos.below());
        return below.is(BlockTags.DIRT) || below.is(Blocks.FARMLAND);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        return !state.canSurvive(level, pos) ? Blocks.AIR.defaultBlockState()
                : super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    // ---- Buyume

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        if (!level.isClientSide && state.getValue(AGE) == 0 && !level.getBlockTicks().hasScheduledTick(pos, this)) {
            level.scheduleTick(pos, this, REGROW_TICKS);
        }
    }

    /** Bos calilar (dunya uretiminden gelenler) ve donmasi gereken cilekler icin. */
    @Override
    public boolean isRandomlyTicking(BlockState state) {
        return state.getValue(AGE) == 0 || (strawberry && !state.getValue(FROZEN));
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        if (state.getValue(AGE) == 0) {
            // Zamanlayicisi olmayan bos cali: zamanlayici baslat (toplananlarda zaten vardir)
            if (!level.getBlockTicks().hasScheduledTick(pos, this)) {
                level.scheduleTick(pos, this, REGROW_TICKS);
            }
        } else if (strawberry && !state.getValue(FROZEN) && isFreezeTime(level)) {
            level.setBlock(pos, state.setValue(FROZEN, true), 2);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        if (state.getValue(AGE) == 0) {
            level.setBlock(pos, state.setValue(AGE, 1).setValue(FROZEN, strawberry && isFreezeTime(level)), 2);
        }
    }

    // ---- Toplama

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (state.getValue(AGE) != 1) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        RandomSource r = level.getRandom();
        if (strawberry) {
            boolean frozen = state.getValue(FROZEN) || isFreezeTime(level);
            ItemStack berries = new ItemStack(frozen ? ModItems.FROZEN_STRAWBERRY.get() : ModItems.STRAWBERRY.get(),
                    1 + r.nextInt(2));
            Block.popResource(level, pos, berries);
        } else {
            Block.popResource(level, pos, new ItemStack(ModItems.TEA_LEAVES.get(), 1 + r.nextInt(2)));
            Block.popResource(level, pos, new ItemStack(ModItems.TEA_SEEDS.get()));
        }
        level.playSound(null, pos, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.BLOCKS, 1.0F,
                0.8F + r.nextFloat() * 0.4F);
        level.setBlock(pos, state.setValue(AGE, 0).setValue(FROZEN, false), 2);
        level.scheduleTick(pos, this, REGROW_TICKS);
        return InteractionResult.CONSUME;
    }
}
