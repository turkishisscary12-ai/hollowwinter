package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.registry.ModSounds;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.StormManager;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * YETI AVI: yeti artik sadece nadir olaylarda degil, duzenli olarak oyuncuyu avlar.
 *  - Gece ya da firtinada, acik havadaki oyuncu icin her 4-8 dakikada bir (firtinada 2-4 dk) av baslar.
 *  - %50 PUSU: yeti oyuncunun 7-10 blok yakininda kardan firlar. %50 TAKIP: 34-42 blok uzaktan yuruyerek gelir.
 *  - Yeti gercek bir dusman gibi dovusur (6 hasar, kokulu soguk). Cani yarinin altina inerse kacar (kaybolur).
 *  - 3 dakika sonra, sabah olunca ya da oyuncu iyice kacarsa kaybolur.
 *  - Yeti yakindayken: kalp atisi sesi + ekran kararmasi (Karanlik efekti). Yakindaki mesale/kamp atesi soner (YetiEntity).
 * Test: /hollowwinter hunt  |  /hollowwinter hunt ambush
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class YetiHunt {

    private static final double START_DAY = 6.0;
    private static final int MIN_GAP = 4800;          // 4 dk
    private static final int MAX_GAP = 9600;          // 8 dk
    private static final int HUNT_TICKS = 3600;       // 3 dk
    private static final int RETREAT_GAP = 7200;      // kacarsa 6 dk sonra tekrar
    private static final float RETREAT_FRACTION = 0.5F;
    private static final double GIVE_UP_DISTANCE = 90.0;
    private static final float HUNTER_DAMAGE = 6.0F;  // 3 kalp
    private static final double HUNTER_SPEED = 0.28D;

    private static final double PRESENCE_RANGE = 30.0;
    private static final double DARK_RANGE = 18.0;

    private static final class Hunt {
        final UUID yeti;
        int ticks = 0;
        Hunt(UUID yeti) { this.yeti = yeti; }
    }

    private static final Map<UUID, Hunt> HUNTS = new HashMap<>();
    private static final Map<UUID, Long> NEXT = new HashMap<>();
    private static final Map<UUID, Long> NEXT_BEAT = new HashMap<>();
    private static final Set<UUID> MANAGED = new HashSet<>();

    public static boolean isManaged(UUID yetiId) {
        return MANAGED.contains(yetiId);
    }

    public static boolean isHunted(UUID playerId) {
        return HUNTS.containsKey(playerId);
    }

    private static boolean isDark(ServerLevel level) {
        int t = (int) (level.getDayTime() % 24000L);
        return (t >= 13000 && t <= 23000) || StormManager.isStorm(level);
    }

    // ------------------------------------------------------------------ Baslatma

    public static boolean forceHunt(ServerPlayer p, boolean ambush) {
        return startHunt(p.serverLevel(), p, ambush);
    }

    public static void stopFor(ServerPlayer p) {
        Hunt h = HUNTS.get(p.getUUID());
        if (h != null) endHunt(p.serverLevel(), p.getUUID(), h, false);
    }

    private static boolean startHunt(ServerLevel level, ServerPlayer p, boolean ambush) {
        if (HUNTS.containsKey(p.getUUID()) || YetiEventManager.isBusy(p.getUUID())) return false;
        RandomSource r = level.getRandom();
        Vec3 pos = null;
        for (int i = 0; i < 12 && pos == null; i++) {
            double dist = ambush ? 7.0 + r.nextDouble() * 3.0 : 34.0 + r.nextDouble() * 8.0;
            double ang = r.nextDouble() * Math.PI * 2.0;
            Vec3 c = SnowSurface.standPos(level, p.getX() + Math.cos(ang) * dist, p.getZ() + Math.sin(ang) * dist);
            if (c != null && Math.abs(c.y - p.getY()) < 8.0) pos = c;
        }
        if (pos == null) return false;

        YetiEntity yeti = ModEntities.YETI.get().create(level);
        if (yeti == null) return false;
        yeti.moveTo(pos.x, pos.y, pos.z, 0.0F, 0.0F);
        yeti.setHunter(true);
        var dmg = yeti.getAttribute(Attributes.ATTACK_DAMAGE);
        if (dmg != null) dmg.setBaseValue(HUNTER_DAMAGE);
        var spd = yeti.getAttribute(Attributes.MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(HUNTER_SPEED);
        MANAGED.add(yeti.getUUID());
        level.addFreshEntity(yeti);
        yeti.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, p.getEyePosition());
        yeti.setTarget(p);
        HUNTS.put(p.getUUID(), new Hunt(yeti.getUUID()));

        if (ambush) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SNOW_BLOCK.defaultBlockState()),
                    pos.x, pos.y + 0.3, pos.z, 90, 0.7, 0.6, 0.7, 0.15);
            level.sendParticles(ParticleTypes.SNOWFLAKE, pos.x, pos.y + 1.0, pos.z, 40, 0.6, 1.0, 0.6, 0.08);
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.SNOW_BREAK, SoundSource.HOSTILE, 2.0F, 0.6F);
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.POLAR_BEAR_WARNING, SoundSource.HOSTILE, 2.5F, 0.55F);
        } else {
            YetiAmbience.playFor(level, p);
        }
        return true;
    }

    // ------------------------------------------------------------------ Bitirme

    private static void endHunt(ServerLevel level, UUID playerId, Hunt h, boolean retreat) {
        HUNTS.remove(playerId);
        MANAGED.remove(h.yeti);
        Entity e = level.getEntity(h.yeti);
        if (e != null) {
            level.sendParticles(ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + 1.2, e.getZ(), 50, 0.5, 0.9, 0.5, 0.06);
            level.sendParticles(ParticleTypes.CLOUD, e.getX(), e.getY() + 1.2, e.getZ(), 20, 0.5, 0.9, 0.5, 0.03);
            if (retreat) {
                level.playSound(null, e.getX(), e.getY(), e.getZ(), ModSounds.YETI_LAUGH.get(), SoundSource.HOSTILE, 3.0F, 0.8F);
            }
            e.discard();
        }
        if (retreat) {
            NEXT.put(playerId, level.getGameTime() + RETREAT_GAP);
        }
    }

    private static void tickHunts(ServerLevel level) {
        if (HUNTS.isEmpty()) return;
        boolean dark = isDark(level);
        Iterator<Map.Entry<UUID, Hunt>> it = new HashMap<>(HUNTS).entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Hunt> en = it.next();
            Hunt h = en.getValue();
            h.ticks += 10;
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(en.getKey());
            Entity e = level.getEntity(h.yeti);
            if (p == null || !p.isAlive() || p.level() != level || p.isCreative() || p.isSpectator()) {
                endHunt(level, en.getKey(), h, false);
                continue;
            }
            if (!(e instanceof YetiEntity yeti) || !yeti.isAlive()) {
                // oldurulduyse: bir sure rahat
                HUNTS.remove(en.getKey());
                MANAGED.remove(h.yeti);
                NEXT.put(en.getKey(), level.getGameTime() + MAX_GAP);
                continue;
            }
            if (YetiEventManager.isBusy(en.getKey()) || h.ticks > HUNT_TICKS || !dark
                    || yeti.distanceTo(p) > GIVE_UP_DISTANCE) {
                endHunt(level, en.getKey(), h, false);
                continue;
            }
            if (yeti.getHealth() < yeti.getMaxHealth() * RETREAT_FRACTION) {
                endHunt(level, en.getKey(), h, true);
                continue;
            }
            if (yeti.getTarget() == null || !yeti.getTarget().isAlive()) yeti.setTarget(p);
        }
    }

    // ------------------------------------------------------------------ Tetikleyici

    private static void evaluate(ServerLevel level) {
        if (WinterManager.daysSinceOrigin(level) < START_DAY) return;
        if (AtmosphereEvents.isSilentDay(level)) return;
        if (!isDark(level)) return;
        long now = level.getGameTime();
        RandomSource r = level.getRandom();
        boolean storm = StormManager.isStorm(level);

        for (ServerPlayer p : level.players()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;
            UUID id = p.getUUID();
            Long next = NEXT.get(id);
            if (next == null) {
                NEXT.put(id, now + 1200 + r.nextInt(2400)); // ilk av 1-3 dk sonra
                continue;
            }
            if (now < next) continue;
            if (HUNTS.containsKey(id) || YetiEventManager.isBusy(id) || !SnowSurface.exposed(level, p.blockPosition())) {
                NEXT.put(id, now + 400L);
                continue;
            }
            if (startHunt(level, p, r.nextBoolean())) {
                int gap = MIN_GAP + r.nextInt(MAX_GAP - MIN_GAP);
                NEXT.put(id, now + (storm ? gap / 2 : gap));
            } else {
                NEXT.put(id, now + 400L);
            }
        }
    }

    // ------------------------------------------------------------------ Yakinlik: kalp atisi + kararma

    private static void tickPresence(ServerLevel level) {
        long now = level.getGameTime();
        for (ServerPlayer p : level.players()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;
            double best = Double.MAX_VALUE;
            for (YetiEntity y : level.getEntitiesOfClass(YetiEntity.class, p.getBoundingBox().inflate(PRESENCE_RANGE),
                    y -> y.isAlive() && (y.getMode() == YetiEntity.MODE_NORMAL || y.getMode() == YetiEntity.MODE_CHASER))) {
                best = Math.min(best, y.distanceTo(p));
            }
            if (best > PRESENCE_RANGE) continue;

            Long beat = NEXT_BEAT.get(p.getUUID());
            if (beat == null || now >= beat) {
                float vol = (float) Math.max(0.25, 1.1 - best / 35.0);
                p.playNotifySound(SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, vol, 1.0F);
                NEXT_BEAT.put(p.getUUID(), now + (long) (12 + best * 1.4));
            }
            if (best < DARK_RANGE) {
                p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false, false));
            }
        }
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        long t = level.getGameTime();
        if (t % 10L == 0L) {
            tickHunts(level);
            tickPresence(level);
        }
        if (t % 40L == 0L) evaluate(level);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            stopFor(p);
            NEXT.remove(p.getUUID());
            NEXT_BEAT.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        HUNTS.clear();
        NEXT.clear();
        NEXT_BEAT.clear();
        MANAGED.clear();
    }
}
