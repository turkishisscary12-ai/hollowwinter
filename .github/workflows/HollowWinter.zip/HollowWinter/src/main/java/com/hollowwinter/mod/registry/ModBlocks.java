package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.block.FrozenBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, HollowWinter.MODID);

    public static final RegistryObject<Block> FROZEN_BLOCK = BLOCKS.register("frozen_block",
            () -> new FrozenBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.ICE)
                    .strength(0.0F)
                    .sound(SoundType.GLASS)));

    /** Yumusak kar oncesi donan zemin: normal topraktan ~3 kat yavas kirilir. */
    public static final RegistryObject<Block> FROZEN_DIRT = BLOCKS.register("frozen_dirt",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT)
                    .strength(1.5F)
                    .sound(SoundType.GRAVEL)));
    public static final RegistryObject<Block> FROZEN_GRASS_BLOCK = BLOCKS.register("frozen_grass_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.ICE)
                    .strength(1.6F)
                    .sound(SoundType.GRAVEL)));

    /** Su isiticisi: pilli, buzu eritir, disarida donup bozulabilir. */
    public static final RegistryObject<Block> WATER_HEATER = BLOCKS.register("water_heater",
            () -> new com.hollowwinter.mod.block.WaterHeaterBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(2.0F)
                    .noOcclusion()
                    .sound(SoundType.METAL)));

    private static BlockBehaviour.Properties bushProps() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.PLANT)
                .strength(0.2F)
                .noCollission()
                .noOcclusion()
                .sound(SoundType.SWEET_BERRY_BUSH)
                .pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY);
    }

    /** Cay calisi: sag tikla cay yapragi + tohum, 10 dk'da yeniden buyur. */
    public static final RegistryObject<Block> TEA_BUSH = BLOCKS.register("tea_bush",
            () -> new com.hollowwinter.mod.block.FruitBushBlock(bushProps(), false));
    /** Cilek calisi: 5. gunden sonra meyveleri donar. */
    public static final RegistryObject<Block> STRAWBERRY_BUSH = BLOCKS.register("strawberry_bush",
            () -> new com.hollowwinter.mod.block.FruitBushBlock(bushProps(), true));

    /** Buz sarkiti: tavandan / yapraktan sarkar, dusunce vanilla sarkit kadar hasar verir. */
    public static final RegistryObject<Block> ICICLE = BLOCKS.register("icicle",
            () -> new com.hollowwinter.mod.block.IcicleBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.ICE)
                    .strength(0.5F)
                    .sound(SoundType.GLASS)
                    .noOcclusion()
                    .dynamicShape()
                    .offsetType(BlockBehaviour.OffsetType.XZ)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY)));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
