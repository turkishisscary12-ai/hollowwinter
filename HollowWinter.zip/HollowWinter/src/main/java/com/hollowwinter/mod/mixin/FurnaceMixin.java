package com.hollowwinter.mod.mixin;

import com.hollowwinter.mod.event.FuelEvents;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Su dolu bardak (cay) sadece cay yapragi yakitiyla pisirilir. Baska yakitla yanma baslamaz;
 * baska yakitla zaten yanan bir ocakta da pisirme ilerlemez.
 */
@Mixin(AbstractFurnaceBlockEntity.class)
public class FurnaceMixin {

    @Inject(method = "serverTick", at = @At("HEAD"), cancellable = true)
    private static void hollowwinter$teaOnlyWithTeaLeaves(Level level, BlockPos pos, BlockState state,
                                                         AbstractFurnaceBlockEntity furnace, CallbackInfo ci) {
        ItemStack input = furnace.getItem(0);
        if (!input.is(ModItems.WATER_CUP.get())) return;

        FurnaceAccessor acc = (FurnaceAccessor) furnace;
        boolean lit = acc.hollowwinter$getLitTime() > 0;

        // Cay yapragiyla yanmakta (ozel yanma suresi ile taninir)
        if (lit && acc.hollowwinter$getLitDuration() == FuelEvents.TEA_BURN_TIME) return;
        // Yanma henuz baslamadi ve yakit slotunda cay yapragi var: yanmaya izin ver
        if (!lit && furnace.getItem(1).is(ModItems.TEA_LEAVES.get())) return;

        // Aksi halde pisirme ilerlemesin; yanmiyorsa ocak hic baslamasin
        acc.hollowwinter$setCookingProgress(0);
        if (!lit) ci.cancel();
    }
}
