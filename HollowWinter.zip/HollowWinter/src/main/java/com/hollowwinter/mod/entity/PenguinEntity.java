package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/**
 * Penguen: 5. gunden sonra buzlu bolgelerde dogar. Buzun uzerinde yuz ustu (karnı ustunde) kayar.
 * Oldurulunce hicbir sey dusurmez. Baliklarla (morina/somon) beslenip ureyebilir.
 */
public class PenguinEntity extends net.minecraft.world.entity.TamableAnimal {
    public static final int SPAWN_DAY = 5;
    private static final EntityDataAccessor<Boolean> SLIDING =
            SynchedEntityData.defineId(PenguinEntity.class, EntityDataSerializers.BOOLEAN);

    public PenguinEntity(EntityType<? extends PenguinEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createLivingAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SLIDING, false);
    }

    public boolean isSliding() {
        return this.entityData.get(SLIDING);
    }

    public void setSliding(boolean sliding) {
        this.entityData.set(SLIDING, sliding);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (SLIDING.equals(key)) this.refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        EntityDimensions dims = isSliding() ? EntityDimensions.fixed(0.6F, 0.45F) : this.getType().getDimensions();
        return this.isBaby() ? dims.scale(0.5F) : dims;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5D));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new SlideGoal(this));
        this.goalSelector.addGoal(5, new FollowOwnerGoal(this, 1.2D, 10.0F, 2.0F, false));
        this.goalSelector.addGoal(3, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(4, new TemptGoal(this, 1.1D, Ingredient.of(Items.COD, Items.SALMON), false));
        this.goalSelector.addGoal(5, new FollowParentGoal(this, 1.1D));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, net.minecraft.world.entity.player.Player.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.COD) || stack.is(Items.SALMON);
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        PenguinEntity baby = ModEntities.PENGUIN.get().create(level);
        if (baby != null && this.isTame() && this.getOwnerUUID() != null) {
            baby.setOwnerUUID(this.getOwnerUUID());
            baby.setTame(true);
        }
        return baby;
    }

    /** Balikla evcillestir (1/3 sans). Evcil penguene bos elle sag tik: otur / kalk. Balik: can doldurur / ureme. */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!this.isTame()) {
            if (isFood(stack)) {
                if (!this.level().isClientSide) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    if (this.random.nextInt(3) == 0) {
                        this.tame(player);
                        this.navigation.stop();
                        this.setTarget(null);
                        this.setOrderedToSit(false);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            return super.mobInteract(player, hand);
        }
        if (this.isOwnedBy(player)) {
            if (isFood(stack)) {
                if (this.getHealth() < this.getMaxHealth()) {
                    if (!this.level().isClientSide) {
                        this.heal(4.0F);
                        if (!player.getAbilities().instabuild) stack.shrink(1);
                    }
                    return InteractionResult.sidedSuccess(this.level().isClientSide);
                }
                return super.mobInteract(player, hand); // ureme
            }
            if (!this.level().isClientSide) {
                this.setOrderedToSit(!this.isOrderedToSit());
                this.navigation.stop();
                this.setTarget(null);
                setSliding(false);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    /** Buz (ya da ustunde kar tabakasi olan buz) uzerinde mi? */
    public boolean onIce() {
        BlockPos pos = this.blockPosition();
        if (isIce(this.level().getBlockState(pos.below()))) return true;
        return this.level().getBlockState(pos).is(Blocks.SNOW) && isIce(this.level().getBlockState(pos.below()));
    }

    private static boolean isIce(BlockState s) {
        return s.is(Blocks.ICE) || s.is(Blocks.PACKED_ICE) || s.is(Blocks.BLUE_ICE) || s.is(Blocks.FROSTED_ICE);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide && isSliding()) {
            double yaw = Math.toRadians(this.getYRot());
            this.level().addParticle(ParticleTypes.SNOWFLAKE,
                    this.getX() + Math.sin(yaw) * 0.5, this.getY() + 0.1, this.getZ() - Math.cos(yaw) * 0.5,
                    0.0, 0.02, 0.0);
        }
    }

    /** Dogal dogma: 5. gunden sonra, buz/kar zemin. */
    public static boolean checkSpawn(EntityType<PenguinEntity> type, ServerLevelAccessor level, MobSpawnType reason,
                                     BlockPos pos, RandomSource random) {
        ServerLevel sl = level.getLevel();
        if (sl.dimension() != Level.OVERWORLD) return false;
        if (WinterManager.daysSinceOrigin(sl) < SPAWN_DAY) return false;
        BlockState below = level.getBlockState(pos.below());
        return isIce(below) || below.is(Blocks.SNOW_BLOCK) || below.is(Blocks.SNOW)
                || below.is(Blocks.GRASS_BLOCK) && level.getBlockState(pos).is(Blocks.SNOW);
    }

    // Sesler (tavuk sesleri, alcak perde)
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.CHICKEN_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource s) { return SoundEvents.CHICKEN_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.CHICKEN_DEATH; }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        if (!isSliding()) this.playSound(SoundEvents.SNOW_STEP, 0.15F, 1.2F);
    }

    @Override
    public float getVoicePitch() { return super.getVoicePitch() * 0.7F; }

    /** Buzun uzerinde rastgele bir yone yuz ustu kayar. */
    private static class SlideGoal extends Goal {
        private final PenguinEntity penguin;
        private int ticks;
        private float yaw;

        SlideGoal(PenguinEntity penguin) {
            this.penguin = penguin;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            return !penguin.isOrderedToSit() && penguin.onGround() && !penguin.isInWater() && penguin.onIce()
                    && penguin.getRandom().nextInt(50) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return ticks > 0 && penguin.onGround() && penguin.onIce() && !penguin.horizontalCollision;
        }

        @Override
        public void start() {
            ticks = 30 + penguin.getRandom().nextInt(50);
            yaw = penguin.getYRot() + (penguin.getRandom().nextFloat() - 0.5F) * 120.0F;
            penguin.getNavigation().stop();
            penguin.setSliding(true);
        }

        @Override
        public void tick() {
            ticks--;
            penguin.setYRot(yaw);
            penguin.yBodyRot = yaw;
            penguin.yHeadRot = yaw;
            double rad = Math.toRadians(yaw);
            double speed = 0.32D;
            penguin.setDeltaMovement(-Math.sin(rad) * speed, penguin.getDeltaMovement().y, Math.cos(rad) * speed);
        }

        @Override
        public void stop() {
            penguin.setSliding(false);
            penguin.setDeltaMovement(penguin.getDeltaMovement().multiply(0.3, 1, 0.3));
        }
    }
}
