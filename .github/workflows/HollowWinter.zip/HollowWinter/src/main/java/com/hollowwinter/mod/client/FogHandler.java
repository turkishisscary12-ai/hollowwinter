package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Kovalamaca sirasinda yogun sis cokertir (sadece istemci). */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, value = Dist.CLIENT)
public class FogHandler {

    /** Tam sisteki gorus mesafesi (blok). */
    private static final float FOG_FAR = 16.0F;

    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        float k = ClientFogData.smoothed();
        if (k < 0.01F) return;
        if (event.getType() != FogType.NONE) return; // su/lav icindeysek dokunma

        event.setNearPlaneDistance(Mth.lerp(k, event.getNearPlaneDistance(), 0.0F));
        event.setFarPlaneDistance(Mth.lerp(k, event.getFarPlaneDistance(), FOG_FAR));
        event.setCanceled(true); // degisikliklerin uygulanmasi icin gerekli
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        float k = ClientFogData.current();
        if (k < 0.01F) return;
        event.setRed(Mth.lerp(k, event.getRed(), 0.30F));
        event.setGreen(Mth.lerp(k, event.getGreen(), 0.34F));
        event.setBlue(Mth.lerp(k, event.getBlue(), 0.40F));
    }
}
