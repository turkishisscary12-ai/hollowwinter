package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.network.FrozenMobPacket;
import com.hollowwinter.mod.network.ModNetwork;
import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;
import java.util.Map;

/**
 * 12. gunden sonra ACIK HAVADA dogan yaratiklar donmus dogar (etiket: hollowwinter_frozen).
 * Madende / kapali yerde doganlar normal kalir. Donmus yaratiklarin dusurdukleri esyalar donmus surumuyle degisir
 * (sans/miktar ayni).
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class FrozenMobEvents {
    public static final String TAG = "hollowwinter_frozen";
    public static final int FREEZE_DAY = 12;

    public static final List<EntityType<?>> TYPES = List.of(
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.CREEPER,
            EntityType.SHEEP, EntityType.COW, EntityType.PIG, EntityType.CHICKEN);

    private static Map<Item, RegistryObject<Item>> dropMap;

    private static Map<Item, RegistryObject<Item>> dropMap() {
        if (dropMap == null) {
            dropMap = Map.ofEntries(
                    Map.entry(Items.ROTTEN_FLESH, ModItems.FROZEN_ROTTEN_FLESH),
                    Map.entry(Items.BONE, ModItems.FROZEN_BONE),
                    Map.entry(Items.ARROW, ModItems.FROZEN_ARROW),
                    Map.entry(Items.BOW, ModItems.FROZEN_BOW),
                    Map.entry(Items.BEEF, ModItems.FROZEN_BEEF),
                    Map.entry(Items.PORKCHOP, ModItems.FROZEN_PORKCHOP),
                    Map.entry(Items.MUTTON, ModItems.FROZEN_MUTTON),
                    Map.entry(Items.CHICKEN, ModItems.FROZEN_CHICKEN),
                    Map.entry(Items.LEATHER, ModItems.FROZEN_LEATHER),
                    Map.entry(Items.FEATHER, ModItems.FROZEN_FEATHER),
                    Map.entry(Items.STRING, ModItems.FROZEN_STRING),
                    Map.entry(Items.SPIDER_EYE, ModItems.FROZEN_SPIDER_EYE),
                    Map.entry(Items.GUNPOWDER, ModItems.FROZEN_GUNPOWDER));
        }
        return dropMap;
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.loadedFromDisk()) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        Entity entity = event.getEntity();
        if (!(entity instanceof Mob) || !TYPES.contains(entity.getType())) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (WinterManager.daysSinceOrigin(level) < FREEZE_DAY) return;
        // Kapali yerde / madende dogan normal kalir
        if (!SnowSurface.exposed(level, entity.blockPosition())) return;
        entity.addTag(TAG);
    }

    /** Oyuncu bir donmus yaratigi gormeye basladiginda ona bildir (yukleme / yaklasma). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getEntity() instanceof ServerPlayer player && event.getTarget().getTags().contains(TAG)) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new FrozenMobPacket(event.getTarget().getId()));
        }
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (!event.getEntity().getTags().contains(TAG)) return;
        for (ItemEntity drop : event.getDrops()) {
            ItemStack stack = drop.getItem();
            RegistryObject<Item> frozen = dropMap().get(stack.getItem());
            if (frozen != null) {
                drop.setItem(new ItemStack(frozen.get(), stack.getCount()));
            }
        }
    }
}
