package com.hollowwinter.mod.menu;

import com.hollowwinter.mod.block.WaterHeaterBlockEntity;
import com.hollowwinter.mod.item.BatteryItem;
import com.hollowwinter.mod.registry.ModMenus;
import net.minecraft.util.Mth;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class WaterHeaterMenu extends AbstractContainerMenu {
    public static final int BTN_DOWN = 0;
    public static final int BTN_UP = 1;

    private final Container container;
    private final ContainerData data;

    /** Istemci tarafi. */
    public WaterHeaterMenu(int id, Inventory inv) {
        this(id, inv, new SimpleContainer(WaterHeaterBlockEntity.SLOTS), new SimpleContainerData(2));
    }

    public WaterHeaterMenu(int id, Inventory inv, Container container, ContainerData data) {
        super(ModMenus.WATER_HEATER.get(), id);
        checkContainerSize(container, WaterHeaterBlockEntity.SLOTS);
        checkContainerDataCount(data, 2);
        this.container = container;
        this.data = data;
        container.startOpen(inv.player);

        for (int i = 0; i < WaterHeaterBlockEntity.SLOTS; i++) {
            this.addSlot(new Slot(container, i, 98 + i * 22, 36) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return stack.getItem() instanceof BatteryItem;
                }
            });
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(inv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inv, col, 8 + col * 18, 142));
        }
        this.addDataSlots(data);
    }

    public int getHeat() {
        return data.get(0);
    }

    public boolean isFrozen() {
        return data.get(1) != 0;
    }

    /** Sol paneldeki - / + dugmeleri (sunucuda calisir). */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (isFrozen()) return false;
        int delta = id == BTN_UP ? 1 : id == BTN_DOWN ? -1 : 0;
        if (delta == 0) return false;
        data.set(0, Mth.clamp(data.get(0) + delta, 0, WaterHeaterBlockEntity.MAX_HEAT));
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < WaterHeaterBlockEntity.SLOTS) {
                if (!this.moveItemStackTo(stack, WaterHeaterBlockEntity.SLOTS, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (!(stack.getItem() instanceof BatteryItem)
                    || !this.moveItemStackTo(stack, 0, WaterHeaterBlockEntity.SLOTS, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return container.stillValid(player);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        container.stopOpen(player);
    }
}
