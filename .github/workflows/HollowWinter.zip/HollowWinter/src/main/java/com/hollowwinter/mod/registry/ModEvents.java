package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod olay yolunda (MOD bus) calisan kayitlar. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.YETI.get(), YetiEntity.createAttributes().build());
    }
}
