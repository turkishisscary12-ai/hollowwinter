package com.hollowwinter.mod.item;

import com.hollowwinter.mod.cold.ColdHandler;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Buz balta: 60 dayaniklilik (kolay kirilir), toplam 5 hasar. Vurulan oyuncuya +20 soguk ve 2 sn yavaslik,
 * diger canlilara (hayvanlar) sadece yavaslik verir.
 */
public class IceAxeItem extends AxeItem implements IceTool {
    public static final float PLAYER_COLD = 20.0F;
    public static final int SLOW_TICKS = 40; // 2 saniye

    // Taban 1 + demir seviyesi 2 + 2 = 5 hasar
    public IceAxeItem(Properties properties) {
        super(Tiers.IRON, 2.0F, -3.0F, properties.durability(60));
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, SLOW_TICKS, 1));
        if (target instanceof ServerPlayer player) {
            ColdHandler.addCold(player, PLAYER_COLD);
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.hollowwinter.ice_axe.tooltip"));
    }
}
