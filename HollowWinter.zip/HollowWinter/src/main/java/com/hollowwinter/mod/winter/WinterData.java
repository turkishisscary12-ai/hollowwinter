package com.hollowwinter.mod.winter;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Dunyaya kaydedilen kis verileri:
 *  - Kis baslangic zamani: mod bir dunyada ilk calistiginda o anin gun zamani (dayTime) kaydedilir;
 *    "4 gun hazirlik" bu andan itibaren sayilir. Boylece eski dunyalarda kis aninda baslamaz.
 *  - Yeti pencere olaylari: bu dunyada kac kez yasandi (en fazla 3) ve en son hangi gece zar atildi.
 */
public class WinterData extends SavedData {
    private static final String NAME = "hollowwinter_winter";
    private static final String KEY_ORIGIN = "originTick";
    private static final String KEY_WINDOW_EVENTS = "windowEvents";
    private static final String KEY_WINDOW_ROLL_DAY = "windowRollDay";
    private static final long UNSET = Long.MIN_VALUE;

    private long originTick = UNSET;
    private int windowEvents = 0;
    private long lastWindowRollDay = UNSET;

    public static WinterData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage()
                .computeIfAbsent(WinterData::load, WinterData::new, NAME);
    }

    public static WinterData load(CompoundTag tag) {
        WinterData data = new WinterData();
        if (tag.contains(KEY_ORIGIN)) data.originTick = tag.getLong(KEY_ORIGIN);
        data.windowEvents = tag.getInt(KEY_WINDOW_EVENTS);
        if (tag.contains(KEY_WINDOW_ROLL_DAY)) data.lastWindowRollDay = tag.getLong(KEY_WINDOW_ROLL_DAY);
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        if (originTick != UNSET) tag.putLong(KEY_ORIGIN, originTick);
        tag.putInt(KEY_WINDOW_EVENTS, windowEvents);
        if (lastWindowRollDay != UNSET) tag.putLong(KEY_WINDOW_ROLL_DAY, lastWindowRollDay);
        return tag;
    }

    /** Baslangic zamanini doner; ilk cagrida simdiki zamani kaydeder. */
    public long originTick(long nowDayTime) {
        if (originTick == UNSET) {
            originTick = nowDayTime;
            setDirty();
        }
        return originTick;
    }

    public int windowEvents() {
        return windowEvents;
    }

    public void addWindowEvent() {
        windowEvents++;
        setDirty();
    }

    public long lastWindowRollDay() {
        return lastWindowRollDay;
    }

    public void setLastWindowRollDay(long day) {
        lastWindowRollDay = day;
        setDirty();
    }
}
