package com.hollowwinter.mod.block;

import com.hollowwinter.mod.item.BatteryItem;
import com.hollowwinter.mod.menu.WaterHeaterMenu;
import com.hollowwinter.mod.registry.ModBlockEntities;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.WaterFreezer;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class WaterHeaterBlockEntity extends RandomizableContainerBlockEntity {
    public static final int SLOTS = 3;
    public static final int MAX_HEAT = 15;
    /** Disarida (acik hava, kis basladiktan sonra) bu kadar tick durursa donar: 1 dakika. */
    public static final int FREEZE_TICKS = 1200;

    private NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private int heat = 0;
    private int outdoorTicks = 0;
    private int tickCounter = 0;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            if (index == 0) return heat;
            return getBlockState().getValue(WaterHeaterBlock.FROZEN) ? 1 : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index == 0) {
                heat = Mth.clamp(value, 0, MAX_HEAT);
                setChanged();
            }
        }

        @Override
        public int getCount() {
            return 2;
        }
    };

    public WaterHeaterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WATER_HEATER.get(), pos, state);
    }

    /** Saniyede tuketilen sarj: 1-5 dusuk, 6-10 orta, 11-15 cok yuksek. */
    public static int drainPerSecond(int heat) {
        if (heat <= 0) return 0;
        if (heat <= 5) return 1;
        if (heat <= 10) return 3;
        return 9;
    }

    /** Eritme yaricapi: isi arttikca genisler (3..8). Buyuk denizleri kurtaramaz. */
    public static int radius(int heat) {
        return 3 + heat / 3;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, WaterHeaterBlockEntity be) {
        if (!(level instanceof ServerLevel sl)) return;
        if (state.getValue(WaterHeaterBlock.FROZEN)) return;

        // Disarida kalirsa donar (kapali alanda donmaz)
        if (sl.dimension() == Level.OVERWORLD && WinterManager.hasWinterStarted(sl) && SnowSurface.exposed(sl, pos)) {
            if (++be.outdoorTicks >= FREEZE_TICKS) {
                be.freeze(sl, pos, state);
                return;
            }
        } else {
            be.outdoorTicks = 0;
        }

        if (++be.tickCounter < 20) return;
        be.tickCounter = 0;
        be.work(sl, pos, state);
    }

    private void freeze(ServerLevel level, BlockPos pos, BlockState state) {
        level.setBlock(pos, state.setValue(WaterHeaterBlock.FROZEN, true).setValue(WaterHeaterBlock.RUNNING, false), 3);
        level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F, 0.6F);
        level.sendParticles(ParticleTypes.SNOWFLAKE, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5,
                25, 0.4, 0.4, 0.4, 0.03);
        setChanged();
    }

    private void work(ServerLevel level, BlockPos pos, BlockState state) {
        boolean running = false;
        int h = heat;
        if (h > 0) {
            Direction d = state.getValue(WaterHeaterBlock.FACING);
            Direction side = d.getClockWise();
            int range = radius(h);
            int width = 1 + range / 2;
            // Suyun icine gomuluyse buz yuzeyi yukaridadir: yukari dogru tara
            boolean sub = state.getValue(WaterHeaterBlock.WATERLOGGED);
            int yMin = sub ? -1 : -4;
            int yMax = sub ? 7 : 1;

            List<BlockPos> ice = new ArrayList<>();
            boolean water = false;
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
            for (int f = 1; f <= range; f++) {
                for (int s = -width; s <= width; s++) {
                    int x = pos.getX() + d.getStepX() * f + side.getStepX() * s;
                    int z = pos.getZ() + d.getStepZ() * f + side.getStepZ() * s;
                    for (int y = yMin; y <= yMax; y++) {
                        m.set(x, pos.getY() + y, z);
                        if (!level.hasChunkAt(m)) continue;
                        BlockState bs = level.getBlockState(m);
                        if (bs.is(Blocks.ICE)) ice.add(m.immutable());
                        else if (bs.getFluidState().is(Fluids.WATER)) water = true;
                    }
                }
            }

            if (!ice.isEmpty() || water) {
                ItemStack battery = findBattery();
                if (battery != null) {
                    running = true;
                    battery.setDamageValue(Math.min(battery.getMaxDamage(),
                            battery.getDamageValue() + drainPerSecond(h)));
                    setChanged();

                    // En yakindaki buzlardan basla: saniyede 'isi' kadar blok erir
                    ice.sort(Comparator.comparingDouble(p -> p.distSqr(pos)));
                    int melted = 0;
                    for (BlockPos p : ice) {
                        if (melted >= h) break;
                        level.setBlock(p, Blocks.WATER.defaultBlockState(), 3);
                        level.sendParticles(ParticleTypes.CLOUD, p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5,
                                3, 0.25, 0.1, 0.25, 0.01);
                        melted++;
                    }
                    if (melted > 0) {
                        level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.4F, 1.4F);
                    }

                    // Bolgede yeniden donmayi 3 sn engelle
                    long until = level.getGameTime() + 60;
                    for (int f = 1; f <= range; f++) {
                        for (int s = -width; s <= width; s++) {
                            WaterFreezer.protect(pos.getX() + d.getStepX() * f + side.getStepX() * s,
                                    pos.getZ() + d.getStepZ() * f + side.getStepZ() * s, until);
                        }
                    }
                }
            }
        }
        if (state.getValue(WaterHeaterBlock.RUNNING) != running) {
            level.setBlock(pos, state.setValue(WaterHeaterBlock.RUNNING, running), 3);
        }
    }

    private ItemStack findBattery() {
        for (ItemStack s : items) {
            if (s.getItem() instanceof BatteryItem && !BatteryItem.isDepleted(s)) return s;
        }
        return null;
    }

    /** Eldeki pili bos bir yuvaya koyar (1 adet). */
    public boolean insertBattery(ItemStack held) {
        for (int i = 0; i < SLOTS; i++) {
            if (items.get(i).isEmpty()) {
                items.set(i, held.split(1));
                setChanged();
                return true;
            }
        }
        return false;
    }

    /** Bitmis (bos) pilleri oyuncuya verir. */
    public boolean takeDepleted(Player player) {
        boolean any = false;
        for (int i = 0; i < SLOTS; i++) {
            ItemStack s = items.get(i);
            if (s.getItem() instanceof BatteryItem && BatteryItem.isDepleted(s)) {
                items.set(i, ItemStack.EMPTY);
                if (!player.getInventory().add(s)) player.drop(s, false);
                any = true;
            }
        }
        if (any) setChanged();
        return any;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.hollowwinter.water_heater");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
        return new WaterHeaterMenu(id, inventory, this, data);
    }

    @Override
    public int getContainerSize() {
        return SLOTS;
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return items;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> newItems) {
        this.items = newItems;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return stack.getItem() instanceof BatteryItem;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (!this.trySaveLootTable(tag)) {
            ContainerHelper.saveAllItems(tag, this.items);
        }
        tag.putInt("Heat", heat);
        tag.putInt("OutdoorTicks", outdoorTicks);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
        if (!this.tryLoadLootTable(tag)) {
            ContainerHelper.loadAllItems(tag, this.items);
        }
        heat = Mth.clamp(tag.getInt("Heat"), 0, MAX_HEAT);
        outdoorTicks = tag.getInt("OutdoorTicks");
    }
}
