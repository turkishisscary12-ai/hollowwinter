package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.MammothEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Mamut modeli (ozel): kambur omuz, kubbeli alin, 3 parcali hortum, kivrik azi disleri, kulaklar, tuylu etek.
 * Doku 256x128: assets/hollowwinter/textures/entity/mammoth.png
 */
public class MammothModel extends EntityModel<MammothEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowWinter.MODID, "mammoth"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart trunk1;
    private final ModelPart trunk2;
    private final ModelPart trunk3;
    private final ModelPart tail;
    private final ModelPart legFL;
    private final ModelPart legFR;
    private final ModelPart legBL;
    private final ModelPart legBR;

    public MammothModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.trunk1 = head.getChild("trunk1");
        this.trunk2 = trunk1.getChild("trunk2");
        this.trunk3 = trunk2.getChild("trunk3");
        this.tail = root.getChild("tail");
        this.legFL = root.getChild("legFL");
        this.legFR = root.getChild("legFR");
        this.legBL = root.getChild("legBL");
        this.legBR = root.getChild("legBR");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-12.0F, -22.0F, -16.0F, 24.0F, 22.0F, 32.0F).texOffs(112, 0).addBox(-10.0F, -28.0F, -16.0F, 20.0F, 6.0F, 16.0F).texOffs(0, 54).addBox(-13.0F, -6.0F, -17.0F, 26.0F, 10.0F, 34.0F),
                PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition legFL = root.addOrReplaceChild("legFL",
                CubeListBuilder.create().texOffs(120, 54).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 18.0F, 8.0F).texOffs(152, 54).addBox(-5.0F, 15.0F, -5.0F, 10.0F, 3.0F, 10.0F),
                PartPose.offset(-7.0F, 6.0F, -11.0F));
        PartDefinition legFR = root.addOrReplaceChild("legFR",
                CubeListBuilder.create().texOffs(120, 54).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 18.0F, 8.0F).texOffs(152, 54).addBox(-5.0F, 15.0F, -5.0F, 10.0F, 3.0F, 10.0F),
                PartPose.offset(7.0F, 6.0F, -11.0F));
        PartDefinition legBL = root.addOrReplaceChild("legBL",
                CubeListBuilder.create().texOffs(120, 54).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 18.0F, 8.0F).texOffs(152, 54).addBox(-5.0F, 15.0F, -5.0F, 10.0F, 3.0F, 10.0F),
                PartPose.offset(-7.0F, 6.0F, 11.0F));
        PartDefinition legBR = root.addOrReplaceChild("legBR",
                CubeListBuilder.create().texOffs(120, 54).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 18.0F, 8.0F).texOffs(152, 54).addBox(-5.0F, 15.0F, -5.0F, 10.0F, 3.0F, 10.0F),
                PartPose.offset(7.0F, 6.0F, 11.0F));
        PartDefinition tail = root.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(192, 54).addBox(-2.0F, 0.0F, -1.0F, 3.0F, 14.0F, 3.0F).texOffs(204, 54).addBox(-3.0F, 12.0F, -2.0F, 5.0F, 5.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, -12.0F, 16.0F, 0.3F, 0.0F, 0.0F));
        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 98).addBox(-7.0F, -8.0F, -14.0F, 14.0F, 16.0F, 14.0F).texOffs(56, 98).addBox(-6.0F, -15.0F, -12.0F, 12.0F, 7.0F, 10.0F),
                PartPose.offset(0.0F, -8.0F, -16.0F));
        PartDefinition trunk1 = head.addOrReplaceChild("trunk1",
                CubeListBuilder.create().texOffs(100, 98).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 10.0F, 6.0F),
                PartPose.offset(0.0F, -1.0F, -15.0F));
        PartDefinition trunk2 = trunk1.addOrReplaceChild("trunk2",
                CubeListBuilder.create().texOffs(124, 98).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 10.0F, 5.0F),
                PartPose.offset(0.0F, 10.0F, 0.0F));
        PartDefinition trunk3 = trunk2.addOrReplaceChild("trunk3",
                CubeListBuilder.create().texOffs(144, 98).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 10.0F, 0.0F, -0.3F, 0.0F, 0.0F));
        PartDefinition tuskL = head.addOrReplaceChild("tuskL",
                CubeListBuilder.create().texOffs(160, 98).addBox(-1.5F, -1.5F, -9.0F, 3.0F, 3.0F, 9.0F),
                PartPose.offsetAndRotation(-6.0F, 3.0F, -14.0F, 0.35F, 0.25F, 0.0F));
        PartDefinition tuskL2 = tuskL.addOrReplaceChild("tuskL2",
                CubeListBuilder.create().texOffs(184, 98).addBox(-1.0F, -1.0F, -8.0F, 2.0F, 2.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, -9.0F, -0.9F, 0.0F, 0.0F));
        PartDefinition tuskR = head.addOrReplaceChild("tuskR",
                CubeListBuilder.create().texOffs(160, 98).addBox(-1.5F, -1.5F, -9.0F, 3.0F, 3.0F, 9.0F),
                PartPose.offsetAndRotation(6.0F, 3.0F, -14.0F, 0.35F, -0.25F, 0.0F));
        PartDefinition tuskR2 = tuskR.addOrReplaceChild("tuskR2",
                CubeListBuilder.create().texOffs(184, 98).addBox(-1.0F, -1.0F, -8.0F, 2.0F, 2.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, -9.0F, -0.9F, 0.0F, 0.0F));
        PartDefinition earL = head.addOrReplaceChild("earL",
                CubeListBuilder.create().texOffs(204, 98).addBox(-10.0F, -6.0F, -1.0F, 10.0F, 12.0F, 2.0F),
                PartPose.offsetAndRotation(-7.0F, -5.0F, -4.0F, 0.0F, 0.35F, 0.0F));
        PartDefinition earR = head.addOrReplaceChild("earR",
                CubeListBuilder.create().texOffs(204, 98).addBox(0.0F, -6.0F, -1.0F, 10.0F, 12.0F, 2.0F),
                PartPose.offsetAndRotation(7.0F, -5.0F, -4.0F, 0.0F, -0.35F, 0.0F));
        return LayerDefinition.create(mesh, 256, 128);
    }

    @Override
    public void setupAnim(MammothEntity entity, float limbSwing, float limbSwingAmount, float age,
                          float netHeadYaw, float headPitch) {
        float baseXRot = 0.0F;
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F) * 0.8F + baseXRot;
        // Saldirirken basi kaldirir
        if (this.attackTime > 0.0F) {
            this.head.xRot -= Mth.sin(this.attackTime * (float) Math.PI) * 0.7F;
        }
        // Bebek: kafa orantili buyuk
        float headScale = entity.isBaby() ? 1.4F : 1.0F;
        this.head.xScale = headScale;
        this.head.yScale = headScale;
        this.head.zScale = headScale;

        float swing = 0.5F;
        this.legFR.xRot = Mth.cos(limbSwing * swing) * 1.1F * limbSwingAmount;
        this.legBL.xRot = Mth.cos(limbSwing * swing) * 1.1F * limbSwingAmount;
        this.legFL.xRot = Mth.cos(limbSwing * swing + (float) Math.PI) * 1.1F * limbSwingAmount;
        this.legBR.xRot = Mth.cos(limbSwing * swing + (float) Math.PI) * 1.1F * limbSwingAmount;

        // Hortum hafifce sallanir
        this.trunk1.xRot = 0.1F + Mth.sin(age * 0.07F) * 0.06F + limbSwingAmount * 0.15F;
        this.trunk2.xRot = -0.05F + Mth.sin(age * 0.07F + 0.8F) * 0.1F;
        this.trunk3.xRot = -0.3F + Mth.sin(age * 0.07F + 1.6F) * 0.12F;
        this.tail.xRot = 0.3F + Mth.sin(age * 0.1F) * 0.1F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        this.root.render(poseStack, buffer, light, overlay, r, g, b, a);
    }
}
