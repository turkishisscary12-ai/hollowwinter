package com.hollowwinter.mod.item;

import com.hollowwinter.mod.cold.ColdHandler;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Donmus cilek: acligi doldurur ama +%5 soguk ekler. */
public class FrozenStrawberryItem extends Item {
    public static final float COLD_ADDED = 5.0F;

    public FrozenStrawberryItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide && entity instanceof ServerPlayer player) {
            ColdHandler.addCold(player, COLD_ADDED);
        }
        return result;
    }
}
