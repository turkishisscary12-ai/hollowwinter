package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod olay yolunda (MOD bus) calisan kayitlar. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.YETI.get(), YetiEntity.createAttributes().build());
        event.put(ModEntities.PENGUIN.get(), com.hollowwinter.mod.entity.PenguinEntity.createAttributes().build());
        event.put(ModEntities.OWL.get(), com.hollowwinter.mod.entity.OwlEntity.createAttributes().build());
        event.put(ModEntities.MAMMOTH.get(), com.hollowwinter.mod.entity.MammothEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void onSpawnPlacements(net.minecraftforge.event.entity.SpawnPlacementRegisterEvent event) {
        event.register(ModEntities.PENGUIN.get(), net.minecraft.world.entity.SpawnPlacements.Type.ON_GROUND,
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                com.hollowwinter.mod.entity.PenguinEntity::checkSpawn,
                net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.OR);
        event.register(ModEntities.OWL.get(), net.minecraft.world.entity.SpawnPlacements.Type.NO_RESTRICTIONS,
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                com.hollowwinter.mod.entity.OwlEntity::checkSpawn,
                net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.OR);
        event.register(ModEntities.MAMMOTH.get(), net.minecraft.world.entity.SpawnPlacements.Type.ON_GROUND,
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                com.hollowwinter.mod.entity.MammothEntity::checkSpawn,
                net.minecraftforge.event.entity.SpawnPlacementRegisterEvent.Operation.OR);
    }
}
