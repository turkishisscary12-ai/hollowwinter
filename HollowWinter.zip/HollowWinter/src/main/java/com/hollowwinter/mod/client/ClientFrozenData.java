package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;

/** Istemcide buzlu gorunecek varlik kimlikleri. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, value = Dist.CLIENT)
public class ClientFrozenData {
    private static final Set<Integer> FROZEN = new HashSet<>();
    private static int timer = 0;

    public static void add(int id) {
        FROZEN.add(id);
    }

    public static boolean isFrozen(int id) {
        return !FROZEN.isEmpty() && FROZEN.contains(id);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || FROZEN.isEmpty()) return;
        if (++timer < 200) return;
        timer = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            FROZEN.clear();
            return;
        }
        FROZEN.removeIf(id -> mc.level.getEntity(id) == null);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        FROZEN.clear();
    }
}
