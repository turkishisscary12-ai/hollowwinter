package com.hollowwinter.mod.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Pil: dayaniklilik cubugu = sarj. Hasar == max ise bos. Hicbir zaman kirilmaz (bos pil makineden geri alinir). */
public class BatteryItem extends Item {
    public static final int CAPACITY = 1200;

    public BatteryItem(Properties properties) {
        super(properties);
    }

    public static boolean isDepleted(ItemStack stack) {
        return stack.getDamageValue() >= stack.getMaxDamage();
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return false;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (isDepleted(stack)) {
            tooltip.add(Component.translatable("item.hollowwinter.battery.empty").withStyle(ChatFormatting.RED));
        } else {
            int pct = Math.round(100.0F * (stack.getMaxDamage() - stack.getDamageValue()) / stack.getMaxDamage());
            tooltip.add(Component.translatable("item.hollowwinter.battery.charge", pct).withStyle(ChatFormatting.GRAY));
        }
    }
}
