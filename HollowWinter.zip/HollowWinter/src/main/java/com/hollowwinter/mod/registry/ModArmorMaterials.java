package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.LazyLoadedValue;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

/** Kurk zirh malzemesi. Isim "hollowwinter:fur" -> doku: textures/models/armor/fur_layer_1/2.png */
public enum ModArmorMaterials implements ArmorMaterial {
    FUR(HollowWinter.MODID + ":fur", 18,
            new int[]{2, 5, 4, 2},      // sira: kask, gogusluk, pantolon, bot (ArmorItem.Type sirasi)
            14, SoundEvents.ARMOR_EQUIP_LEATHER, 0.0F, 0.0F,
            () -> Ingredient.of(ModItems.PELT.get())),
    /** Viking kaski: mamut kaburga kemigi + kirik tas. Doku: textures/models/armor/viking_layer_1.png */
    VIKING(HollowWinter.MODID + ":viking", 15,
            new int[]{3, 6, 5, 2},
            9, SoundEvents.ARMOR_EQUIP_IRON, 0.0F, 0.05F,
            () -> Ingredient.of(ModItems.MAMMOTH_RIB.get()));

    private static final int[] BASE_DURABILITY = {11, 16, 15, 13}; // kask, gogusluk, pantolon, bot

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final LazyLoadedValue<Ingredient> repairIngredient;

    ModArmorMaterials(String name, int durabilityMultiplier, int[] defense, int enchantability,
                      SoundEvent equipSound, float toughness, float knockbackResistance,
                      Supplier<Ingredient> repairIngredient) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.equipSound = equipSound;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = new LazyLoadedValue<>(repairIngredient);
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return defense[type.ordinal()];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return equipSound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return repairIngredient.get();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
