package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModSounds;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Yeti ortam sesleri: oyuncu ormandayken ya da madendeyken (yer altinda) ara sira uzaktan derin bir yeti sesi gelir:
 * yurume, nefes ya da gulme (ucunden biri rastgele). Ses dunyada oynatilir, yani yanindaki oyuncular da duyar.
 * Test: /hollowwinter sound
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class YetiAmbience {

    /** Bu gunden sonra baslar (yeti olaylariyla ayni). */
    private static final double START_DAY = 6.0;
    /** Iki ses arasi: 5-12 dakika (tick). */
    private static final int MIN_GAP = 6000;
    private static final int MAX_GAP = 14400;
    /** Madende sayilmak icin yuzeyin en az bu kadar altinda olmak gerekir. */
    private static final int MINE_DEPTH = 8;
    private static final double MIN_DIST = 20.0;
    private static final double MAX_DIST = 32.0;
    private static final float VOLUME = 3.0F; // 16 * 3 = ~48 blok duyulma mesafesi

    private static final Map<UUID, Long> NEXT = new HashMap<>();

    private static boolean inForest(ServerLevel level, BlockPos pos) {
        var biome = level.getBiome(pos);
        return biome.is(BiomeTags.IS_FOREST) || biome.is(BiomeTags.IS_TAIGA);
    }

    private static boolean inMine(ServerLevel level, BlockPos pos) {
        if (SnowSurface.exposed(level, pos)) return false;
        int surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, pos).getY();
        return pos.getY() <= surface - MINE_DEPTH;
    }

    /** Oyuncunun cevresinde, uzak bir noktadan 3 sesten birini rastgele calar. */
    public static void playFor(ServerLevel level, ServerPlayer player) {
        RandomSource r = level.getRandom();
        SoundEvent sound = switch (r.nextInt(3)) {
            case 0 -> ModSounds.YETI_STEPS.get();
            case 1 -> ModSounds.YETI_BREATH.get();
            default -> ModSounds.YETI_LAUGH.get();
        };
        double ang = r.nextDouble() * Math.PI * 2.0;
        double dist = MIN_DIST + r.nextDouble() * (MAX_DIST - MIN_DIST);
        double x = player.getX() + Math.cos(ang) * dist;
        double z = player.getZ() + Math.sin(ang) * dist;
        level.playSound(null, x, player.getY(), z, sound, SoundSource.HOSTILE, VOLUME, 0.85F + r.nextFloat() * 0.15F);
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        long now = level.getGameTime();
        if (now % 40L != 0L) return;
        if (WinterManager.daysSinceOrigin(level) < START_DAY) return;
        if (AtmosphereEvents.isSilentDay(level)) return; // sessiz gunde yeti sesi de yok

        RandomSource r = level.getRandom();
        for (ServerPlayer p : level.players()) {
            if (!p.isAlive() || p.isSpectator() || p.isCreative()) continue;
            UUID id = p.getUUID();
            Long next = NEXT.get(id);
            if (next == null) {
                NEXT.put(id, now + MIN_GAP + r.nextInt(MAX_GAP - MIN_GAP));
                continue;
            }
            if (now < next) continue;
            if (YetiEventManager.isChased(id)) continue;

            BlockPos pos = p.blockPosition();
            if (inForest(level, pos) || inMine(level, pos)) {
                playFor(level, p);
                NEXT.put(id, now + MIN_GAP + r.nextInt(MAX_GAP - MIN_GAP));
            } else {
                NEXT.put(id, now + 600L); // uygun yerde degil: 30 sn sonra tekrar bak
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        NEXT.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        NEXT.clear();
    }
}
