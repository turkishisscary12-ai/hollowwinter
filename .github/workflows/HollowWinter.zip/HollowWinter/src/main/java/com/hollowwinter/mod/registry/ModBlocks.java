package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.block.FrozenBlock;
import com.hollowwinter.mod.block.HeaterBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, HollowWinter.MODID);

    public static final RegistryObject<Block> HEATER = BLOCKS.register("heater",
            () -> new HeaterBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(3.5F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> 7)));

    public static final RegistryObject<Block> FROZEN_BLOCK = BLOCKS.register("frozen_block",
            () -> new FrozenBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.ICE)
                    .strength(0.0F)
                    .sound(SoundType.GLASS)));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
