package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.event.YetiEventManager;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

/**
 * /hollowwinter status                      : kis takvimini gosterir.
 * /hollowwinter event chase|window|watch    : yeti olayini hemen test eder (operator).
 * /hollowwinter event stop                  : aktif yeti olaylarini durdurur (operator).
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class WinterCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("hollowwinter")
                        .then(Commands.literal("status").executes(WinterCommand::status))
                        .then(Commands.literal("event")
                                .requires(src -> src.hasPermission(2))
                                .then(Commands.literal("chase").executes(ctx -> runEvent(ctx, "chase")))
                                .then(Commands.literal("window").executes(ctx -> runEvent(ctx, "window")))
                                .then(Commands.literal("watch").executes(ctx -> runEvent(ctx, "watch")))
                                .then(Commands.literal("stop").executes(ctx -> runEvent(ctx, "stop"))))
        );
    }

    private static int status(CommandContext<CommandSourceStack> ctx) {
        ServerLevel level = ctx.getSource().getServer().overworld();
        double day = WinterManager.daysSinceOrigin(level);
        WinterManager.Cycle cycle = WinterManager.getCycle(level);

        String text;
        if (cycle == null) {
            text = String.format(Locale.ROOT,
                    "Hollow Winter: gun %.1f - hazirlik donemi, kis %d. gunde baslar.",
                    day, WinterManager.GRACE_DAYS);
        } else {
            text = String.format(Locale.ROOT,
                    "Hollow Winter: gun %.1f - %s asamasi (%.1f / %.1f gun), hedef kar yuksekligi %.1f blok.",
                    day,
                    cycle.snowing() ? "KAR" : "ACIK HAVA",
                    cycle.daysIntoPhase(), cycle.phaseDays(),
                    cycle.targetLayers() / 8.0);
        }
        String message = text;
        ctx.getSource().sendSuccess(() -> Component.literal(message), false);
        return 1;
    }

    private static int runEvent(CommandContext<CommandSourceStack> ctx, String kind) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();

        if (kind.equals("stop")) {
            YetiEventManager.stopAll(player);
            ctx.getSource().sendSuccess(() -> Component.literal("Yeti olaylari durduruldu."), false);
            return 1;
        }

        boolean ok;
        String failure;
        switch (kind) {
            case "chase" -> {
                ok = YetiEventManager.forceChase(player);
                failure = "Kovalamaca baslatilamadi (zaten aktif bir olay var ya da arkanda uygun zemin yok).";
            }
            case "window" -> {
                ok = YetiEventManager.forceWindow(player);
                failure = "Pencere olayi baslatilamadi: ic mekanda, yakinda ve disi acik hava olan bir cam gerekli.";
            }
            default -> {
                ok = YetiEventManager.forceWatch(player);
                failure = "Izleme baslatilamadi (zaten aktif bir olay var ya da uygun yer bulunamadi).";
            }
        }

        if (ok) {
            ctx.getSource().sendSuccess(() -> Component.literal("Yeti olayi basladi: " + kind), false);
            return 1;
        }
        ctx.getSource().sendFailure(Component.literal(failure));
        return 0;
    }
}
