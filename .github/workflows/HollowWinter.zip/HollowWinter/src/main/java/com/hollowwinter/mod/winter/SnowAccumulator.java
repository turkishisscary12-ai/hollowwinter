package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.event.YetiEventManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Oyuncularin etrafinda kar biriktirir ve eritir (hangi biyom olursa olsun).
 *  - Kar asamasinda yagis varken: kar katman katman yukselir, WinterManager'in hedef kalinligina kadar.
 *  - Acik hava asamasinda: kar yavas yavas erir (hedef yukseklik WinterManager'da hesaplanir).
 * Kar katmani 8 = 1 blok; ust uste yigilarak yukselir. Yukseklik zirvede 43 blok olur.
 * NOT: Yalnizca oyunculara RADIUS blok yakinlikta, yuklu alanlar guncellenir.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class SnowAccumulator {

    /** Oyuncunun etrafinda kar degisecek yaricap (blok). */
    private static final int RADIUS = 56;
    /** Her oyuncu icin her tick denenen rastgele sutun sayisi: kar yagarken / erirken. */
    private static final int ADD_ATTEMPTS_PER_TICK = 8;
    private static final int MELT_ATTEMPTS_PER_TICK = 8;
    /**
     * Bir sutun hedef yukseklikten geride kaldiysa (orn. oyuncu yeni bir bolgeye geldi) tek denemede
     * en fazla bu kadar katman eklenir / erir. Normalde sutun hedefi yakindan izler, yani kar 1-2 katman
     * adimlarla, yavas yavas degisir.
     */
    private static final int MAX_LAYERS_PER_HIT = 8;
    /** Karin altinda ekinler (bugday, havuc vb.) da kirilsin mi? */
    private static final boolean BREAK_CROPS = true;

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        WinterManager.Cycle cycle = WinterManager.getCycle(level);
        if (cycle == null) return;

        boolean accumulate = cycle.snowing() && level.isRaining();
        boolean melt = !cycle.snowing();
        if (!accumulate && !melt) return;

        int target = cycle.targetLayers();
        int attempts = accumulate ? ADD_ATTEMPTS_PER_TICK : MELT_ATTEMPTS_PER_TICK;
        if (accumulate && StormManager.isStorm(level)) {
            // Firtina: kar daha hizli yukselir ve takvimin biraz ustune cikabilir
            attempts *= StormManager.STORM_SNOW_SPEEDUP;
            target = Math.min(344, target + StormManager.STORM_EXTRA_LAYERS);
        }
        RandomSource rand = level.getRandom();

        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            if (YetiEventManager.isChased(player.getUUID())) continue; // kovalamacadaki oyuncunun etrafinda kar birikmez
            BlockPos center = player.blockPosition();

            for (int i = 0; i < attempts; i++) {
                int x = center.getX() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                int z = center.getZ() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;
                if (ChaseSnow.isProtected(x, z) || HeatZones.isHeated(level, x, z)) continue;

                if (accumulate) addSnowAt(level, x, z, target);
                else meltSnowAt(level, x, z, target);
            }
        }
    }

    /** Bir sutundaki kar yiginini ust uste gezer. */
    private record Column(BlockPos pos, BlockState state, int depth) {}

    private static Column scan(ServerLevel level, int x, int z) {
        // Kar katmanlari "hareketi engellemedigi" icin heightmap en alttaki kar katmanini gosterir.
        BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));
        int depth = 0;
        BlockState state = level.getBlockState(pos);
        while (state.is(Blocks.SNOW)) {
            int layers = state.getValue(SnowLayerBlock.LAYERS);
            depth += layers;
            if (layers < 8) break;
            pos = pos.above();
            state = level.getBlockState(pos);
        }
        return new Column(pos, state, depth);
    }

    private static void addSnowAt(ServerLevel level, int x, int z, int target) {
        Column col = scan(level, x, z);
        BlockPos pos = col.pos();
        BlockState state = col.state();

        if (col.depth() >= target) return;
        if (pos.getY() >= level.getMaxBuildHeight() - 1) return;
        if (level.getBrightness(LightLayer.BLOCK, pos) > 11) return; // isik kaynagi yakininda kar birikmez

        int room = target - col.depth();

        if (state.is(Blocks.SNOW)) {
            int current = state.getValue(SnowLayerBlock.LAYERS);
            int add = Math.min(Math.min(MAX_LAYERS_PER_HIT, 8 - current), room);
            BlockState thicker = state.setValue(SnowLayerBlock.LAYERS, current + add);
            Block.pushEntitiesUp(state, thicker, level, pos);
            level.setBlockAndUpdate(pos, thicker);
        } else if (state.isAir() || state.canBeReplaced() || isBreakablePlant(state)) {
            BlockState snow = Blocks.SNOW.defaultBlockState()
                    .setValue(SnowLayerBlock.LAYERS, Math.min(MAX_LAYERS_PER_HIT, room));

            // Patika yolu ve tarla tam blok olmadigi icin kar tutmaz: topraga cevir
            BlockPos belowPos = pos.below();
            BlockState below = level.getBlockState(belowPos);
            if (below.is(Blocks.DIRT_PATH) || below.is(Blocks.FARMLAND)) {
                level.setBlockAndUpdate(belowPos, Blocks.DIRT.defaultBlockState());
            }

            // Zemin kari tutamiyorsa (orn. basamak, yaprak) bitkiyi bozmadan birak
            if (!snow.canSurvive(level, pos)) return;

            // Cicek, fidan, ekin gibi bitkiler kirilir (esya birakir), yerine kar gelir
            if (!state.isAir() && !state.canBeReplaced()) {
                level.destroyBlock(pos, true);
            }
            level.setBlockAndUpdate(pos, snow);
        }
    }

    /**
     * Kar altinda ezilecek bitkiler: cicekler, fidanlar, ekinler, mantarlar, uzun otlar, seker kamisi.
     * Ekinlerin de kirilmasini istemiyorsan BREAK_CROPS'u false yap.
     */
    private static boolean isBreakablePlant(BlockState state) {
        Block block = state.getBlock();
        if (block instanceof CropBlock) return BREAK_CROPS;
        return block instanceof BushBlock || block instanceof SugarCaneBlock;
    }

    private static void meltSnowAt(ServerLevel level, int x, int z, int target) {
        Column col = scan(level, x, z);
        if (col.depth() <= target) return; // hedefin altindaysa erimez

        // En ustteki kar blogunu bul: ya taramanin durdugu kismi kar blogu ya da hemen altindaki dolu blok
        BlockPos topPos = col.state().is(Blocks.SNOW) ? col.pos() : col.pos().below();

        // Hedef yukseklige kadar, tek denemede en fazla MAX_LAYERS_PER_HIT katman erit
        int remaining = Math.min(MAX_LAYERS_PER_HIT, col.depth() - target);
        while (remaining > 0) {
            BlockState top = level.getBlockState(topPos);
            if (!top.is(Blocks.SNOW)) return;

            int layers = top.getValue(SnowLayerBlock.LAYERS);
            if (layers <= remaining) {
                level.removeBlock(topPos, false);
                remaining -= layers;
                topPos = topPos.below();
            } else {
                level.setBlockAndUpdate(topPos, top.setValue(SnowLayerBlock.LAYERS, layers - remaining));
                remaining = 0;
            }
        }
    }
}
