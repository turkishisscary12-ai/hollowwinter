package com.hollowwinter.mod.menu;

import com.hollowwinter.mod.registry.ModBlocks;
import com.hollowwinter.mod.registry.ModMenus;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

/** Maden makinesi menusu: yuvasi yok, sadece veri + dugmeler. Veri: 0 hedef, 1 durum, 2 derinlik, 3 azami, 4 komut. */
public class MinerMenu extends AbstractContainerMenu {
    public static final int BTN_MINUS10 = 0;
    public static final int BTN_MINUS1 = 1;
    public static final int BTN_PLUS1 = 2;
    public static final int BTN_PLUS10 = 3;
    public static final int BTN_MAX = 4;
    public static final int BTN_START = 5;
    public static final int BTN_RECALL = 6;

    private final ContainerData data;
    private final ContainerLevelAccess access;

    public MinerMenu(int id, Inventory inv) {
        this(id, inv, new SimpleContainerData(6), ContainerLevelAccess.NULL);
    }

    public MinerMenu(int id, Inventory inv, ContainerData data, ContainerLevelAccess access) {
        super(ModMenus.MINER.get(), id);
        checkContainerDataCount(data, 6);
        this.data = data;
        this.access = access;
        this.addDataSlots(data);
    }

    public int getTarget() { return data.get(0); }
    public int getState() { return data.get(1); }
    public int getDepth() { return data.get(2); }
    public int getMaxDepth() { return data.get(3); }
    public int getFuel() { return data.get(5); }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id < BTN_MINUS10 || id > BTN_RECALL) return false;
        data.set(4, id); // sunucuda blok varligi komutu uygular
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.MINER.get());
    }
}
