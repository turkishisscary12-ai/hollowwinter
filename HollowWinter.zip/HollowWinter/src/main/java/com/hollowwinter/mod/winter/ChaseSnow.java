package com.hollowwinter.mod.winter;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Kovalamaca sirasinda oyuncunun etrafindaki kari siler (yeti karda takilmasin), kovalamaca bitince geri koyar.
 * Silinen sutunlar "korunur": SnowAccumulator bu sutunlarda kar eklemez / eritmez.
 * Alan oyuncuyu takip eder (her tick sinirli sayida sutun islenir; sunucu kasmasin).
 */
public final class ChaseSnow {
    private ChaseSnow() {}

    private static final int RADIUS = 22;
    private static final int CLEAR_BUDGET = 40;   // tick basina sutun
    private static final int RESTORE_BUDGET = 60;
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    /** Kovalamaca alanindaki tum sutunlar (kar olsun olmasin). */
    private static final Set<Long> PROTECTED = new HashSet<>();
    private static final List<Area> RESTORING = new ArrayList<>();

    public static boolean isProtected(int x, int z) {
        return !PROTECTED.isEmpty() && PROTECTED.contains(BlockPos.asLong(x, 0, z));
    }

    public static void beginRestore(Area area) {
        area.queue.clear();
        area.restoreQueue.addAll(area.saved.keySet());
        RESTORING.add(area);
    }

    public static void tickRestores(ServerLevel level) {
        if (RESTORING.isEmpty()) return;
        Iterator<Area> it = RESTORING.iterator();
        while (it.hasNext()) {
            Area a = it.next();
            for (int i = 0; i < RESTORE_BUDGET && !a.restoreQueue.isEmpty(); i++) {
                a.restoreColumn(level, a.restoreQueue.poll());
            }
            if (a.restoreQueue.isEmpty()) {
                PROTECTED.removeAll(a.visited);
                it.remove();
            }
        }
    }

    public static void clearAll() {
        PROTECTED.clear();
        RESTORING.clear();
    }

    public static final class Area {
        private final Set<Long> visited = new HashSet<>();
        private final Map<Long, int[]> saved = new HashMap<>(); // sutun -> {taban y, toplam katman}
        private final ArrayDeque<Long> queue = new ArrayDeque<>();
        private final ArrayDeque<Long> restoreQueue = new ArrayDeque<>();

        /** Oyuncunun etrafindaki yeni sutunlari siraya ekler. */
        public void follow(double px, double pz) {
            int cx = (int) Math.floor(px);
            int cz = (int) Math.floor(pz);
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    if (dx * dx + dz * dz > RADIUS * RADIUS) continue;
                    long key = BlockPos.asLong(cx + dx, 0, cz + dz);
                    if (visited.add(key)) {
                        PROTECTED.add(key);
                        queue.add(key);
                    }
                }
            }
        }

        /** Her tick cagrilir: siradaki sutunlarin karini siler. */
        public void process(ServerLevel level) {
            for (int i = 0; i < CLEAR_BUDGET && !queue.isEmpty(); i++) {
                clearColumn(level, queue.poll());
            }
        }

        private void clearColumn(ServerLevel level, long key) {
            int x = BlockPos.getX(key);
            int z = BlockPos.getZ(key);
            if (!level.hasChunkAt(new BlockPos(x, 0, z))) return;

            BlockPos base = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));
            BlockPos pos = base;
            int layers = 0;
            BlockState s = level.getBlockState(pos);
            while (s.is(Blocks.SNOW)) {
                layers += s.getValue(SnowLayerBlock.LAYERS);
                pos = pos.above();
                s = level.getBlockState(pos);
            }
            if (layers == 0) return;

            saved.put(key, new int[]{base.getY(), layers});
            for (int y = pos.getY() - 1; y >= base.getY(); y--) {
                level.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), FLAGS);
            }
        }

        private void restoreColumn(ServerLevel level, long key) {
            int[] data = saved.get(key);
            if (data == null) return;
            int x = BlockPos.getX(key);
            int z = BlockPos.getZ(key);
            if (!level.hasChunkAt(new BlockPos(x, 0, z))) return;

            int y = data[0];
            int remaining = data[1];
            while (remaining > 0) {
                BlockPos bp = new BlockPos(x, y, z);
                BlockState cur = level.getBlockState(bp);
                if (!(cur.isAir() || cur.canBeReplaced())) break; // oyuncu bir sey insa ettiyse karisma
                int n = Math.min(8, remaining);
                level.setBlock(bp, Blocks.SNOW.defaultBlockState().setValue(SnowLayerBlock.LAYERS, n), FLAGS);
                remaining -= n;
                y++;
            }
        }
    }
}
