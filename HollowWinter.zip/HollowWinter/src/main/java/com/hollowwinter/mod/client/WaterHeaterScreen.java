package com.hollowwinter.mod.client;

import com.hollowwinter.mod.block.WaterHeaterBlockEntity;
import com.hollowwinter.mod.menu.WaterHeaterMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Su isiticisi menusu: solda isi (0-15) ayari, sagda pil yuvalari. Dokusuz, kodla cizilir. */
public class WaterHeaterScreen extends AbstractContainerScreen<WaterHeaterMenu> {

    public WaterHeaterScreen(WaterHeaterMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = 72;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("-"), b -> press(WaterHeaterMenu.BTN_DOWN))
                .bounds(leftPos + 10, topPos + 56, 22, 18).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> press(WaterHeaterMenu.BTN_UP))
                .bounds(leftPos + 50, topPos + 56, 22, 18).build());
    }

    private void press(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partial);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partial, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        // panel
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF1E1E1E);
        g.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, 0xFFC6C6C6);

        // sol: isi paneli
        g.fill(x + 6, y + 16, x + 78, y + 80, 0xFF2B3A4A);
        int heat = menu.getHeat();
        g.drawCenteredString(font, Component.translatable("gui.hollowwinter.heat"), x + 42, y + 20, 0xFFFFFF);
        g.drawCenteredString(font, Component.literal(heat + " / " + WaterHeaterBlockEntity.MAX_HEAT),
                x + 42, y + 32, heatColor(heat));
        // 15 parcali bar
        for (int i = 0; i < WaterHeaterBlockEntity.MAX_HEAT; i++) {
            int bx = x + 10 + i * 4;
            int color = i < heat ? heatColor(i + 1) | 0xFF000000 : 0xFF111A24;
            g.fill(bx, y + 44, bx + 3, y + 52, color);
        }
        String key = heat == 0 ? "gui.hollowwinter.off"
                : heat <= 5 ? "gui.hollowwinter.drain_low"
                : heat <= 10 ? "gui.hollowwinter.drain_mid" : "gui.hollowwinter.drain_high";
        g.drawCenteredString(font, Component.translatable(key), x + 42, y + 68, 0xAAAAAA);

        // sag: pil yuvalari
        g.drawString(font, Component.translatable("gui.hollowwinter.batteries"), x + 98, y + 22, 0x404040, false);
        for (int i = 0; i < WaterHeaterBlockEntity.SLOTS; i++) slotBg(g, x + 98 + i * 22, y + 36);
        if (menu.isFrozen()) {
            g.drawString(font, Component.translatable("gui.hollowwinter.frozen"), x + 98, y + 60, 0x3366CC, false);
        }

        // oyuncu envanteri
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++) slotBg(g, x + 8 + col * 18, y + 84 + row * 18);
        for (int col = 0; col < 9; col++) slotBg(g, x + 8 + col * 18, y + 142);
    }

    private static void slotBg(GuiGraphics g, int sx, int sy) {
        g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
        g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
    }

    /** Mavi (dusuk) -> turuncu -> kirmizi (yuksek). */
    private static int heatColor(int heat) {
        float t = Math.max(0, Math.min(15, heat)) / 15.0F;
        int r = (int) (80 + 175 * t);
        int gr = (int) (170 - 110 * t);
        int b = (int) (255 - 215 * t);
        return (r << 16) | (gr << 8) | b;
    }
}
