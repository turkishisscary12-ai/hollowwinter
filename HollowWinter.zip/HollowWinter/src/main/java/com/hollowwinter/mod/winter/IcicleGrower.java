package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Buz sarkitlari 6. gunden sonra olusmaya baslar: oyuncularin etrafinda (yuzeyde) agac yapraklarinin ve
 * kaya cikintilarinin altina yavas yavas yerlesir. Dunya uretimi yerine calisma zamaninda olusur.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class IcicleGrower {
    public static final int START_DAY = 6;
    private static final int RADIUS = 48;
    private static final int ATTEMPTS = 6;          // saniyede oyuncu basina
    private static final float PLACE_CHANCE = 0.35F;
    private static final int MAX_NEARBY = 2;        // 5x5x3 icinde en fazla bu kadar sarkit

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % 20L != 0L) return;
        if (WinterManager.daysSinceOrigin(level) < START_DAY) return;

        RandomSource rand = level.getRandom();
        for (ServerPlayer player : level.players()) {
            if (player.isSpectator()) continue;
            BlockPos c = player.blockPosition();
            for (int i = 0; i < ATTEMPTS; i++) {
                int x = c.getX() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                int z = c.getZ() + rand.nextInt(RADIUS * 2 + 1) - RADIUS;
                if (!level.hasChunkAt(new BlockPos(x, 0, z))) continue;
                if (rand.nextFloat() < PLACE_CHANCE) tryPlace(level, x, z);
            }
        }
    }

    private static void tryPlace(ServerLevel level, int x, int z) {
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;      // yaprak dahil en ust
        int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z); // zemin ustu
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = top; y >= Math.max(level.getMinBuildHeight() + 1, top - 14); y--) {
            m.set(x, y, z);
            if (!level.getBlockState(m).isAir()) continue;
            // Yalnizca zemine yakin / agac yuksekliginde (cok yuksek degil)
            if (y < ground - 5 || y > ground + 12) continue;
            BlockPos above = m.above();
            BlockState a = level.getBlockState(above);
            boolean support = a.is(BlockTags.LEAVES) || a.isFaceSturdy(level, above, net.minecraft.core.Direction.DOWN);
            if (!support) continue;
            // Acik gokyuzune bakan (agac/kaya ustunde ortu yok): ustte yaprak disinda blok olmasin
            if (!openAbove(level, above, x, z)) continue;
            if (countNearby(level, m.immutable()) >= MAX_NEARBY) return;
            level.setBlock(m, ModBlocks.ICICLE.get().defaultBlockState(), 3);
            return;
        }
    }

    /** Destek blogunun ustunde (yaprak dahil olmayan) sert blok yoksa yuzeydedir. */
    private static boolean openAbove(ServerLevel level, BlockPos support, int x, int z) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int y = support.getY() + 1; y < support.getY() + 24 && y < level.getMaxBuildHeight(); y++) {
            m.set(x, y, z);
            BlockState s = level.getBlockState(m);
            if (!s.isAir() && !s.is(BlockTags.LEAVES) && !s.is(net.minecraft.world.level.block.Blocks.SNOW)) return false;
        }
        return true;
    }

    private static int countNearby(ServerLevel level, BlockPos p) {
        int n = 0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                for (int dy = -1; dy <= 1; dy++) {
                    m.set(p.getX() + dx, p.getY() + dy, p.getZ() + dz);
                    if (level.getBlockState(m).is(ModBlocks.ICICLE.get())) n++;
                }
        return n;
    }
}
