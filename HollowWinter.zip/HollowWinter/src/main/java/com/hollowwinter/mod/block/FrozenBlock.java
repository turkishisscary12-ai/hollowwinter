package com.hollowwinter.mod.block;

import net.minecraft.world.level.block.Block;

/** Buz kazmanin dondurdugu blok: yumrukla tek vurusta kirilir, esya birakmaz. */
public class FrozenBlock extends Block {
    public FrozenBlock(Properties properties) {
        super(properties);
    }
}
