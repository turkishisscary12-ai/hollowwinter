package com.hollowwinter.mod.item;

import com.hollowwinter.mod.cold.ColdHandler;
import com.hollowwinter.mod.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Cay: icince soguk %40 azalir ve 4 saniye boyunca soguk artmaz / donma hasari gelmez. Bardak geri doner. */
public class TeaItem extends Item {
    public static final float COLD_REDUCTION = 40.0F;
    public static final int WARM_TICKS = 80; // 4 saniye

    public TeaItem(Properties properties) {
        super(properties);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 32;
    }

    @Nullable
    @Override
    public net.minecraft.sounds.SoundEvent getDrinkingSound() {
        return SoundEvents.GENERIC_DRINK;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (entity instanceof ServerPlayer player) {
            ColdHandler.addCold(player, -COLD_REDUCTION);
            ColdHandler.grantWarmth(player, WARM_TICKS);
        }
        if (entity instanceof Player player && player.getAbilities().instabuild) {
            return stack;
        }
        stack.shrink(1);
        ItemStack cup = new ItemStack(ModItems.EMPTY_CUP.get());
        if (stack.isEmpty()) return cup;
        if (entity instanceof Player player && !player.getInventory().add(cup)) {
            player.drop(cup, false);
        }
        return stack;
    }
}
