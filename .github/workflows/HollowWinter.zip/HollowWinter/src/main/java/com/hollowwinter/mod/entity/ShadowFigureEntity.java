package com.hollowwinter.mod.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/**
 * Golge figur: ormanda uzakta dikilip oyuncuya bakan siyah siluet. Hicbir sey yapmaz, ses cikarmaz, vurulamaz.
 * Dogrudan ona bakarsan, 14 blok icine yaklasirsan, vurulursa, sabah olursa ya da 40 sn sonra sessizce kaybolur.
 * Dogurma mantigi: AtmosphereEvents.
 */
public class ShadowFigureEntity extends PathfinderMob {
    private static final int MAX_LIFE = 800;
    private static final int STARE_TICKS = 25;
    private static final double VANISH_DISTANCE = 14.0D;

    private UUID watched;
    private int life = 0;
    private int stare = 0;

    public ShadowFigureEntity(EntityType<? extends ShadowFigureEntity> type, Level level) {
        super(type, level);
        this.setSilent(true);
        this.setInvulnerable(true);
        this.setNoAi(true);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D);
    }

    public void setWatched(UUID player) {
        this.watched = player;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        ServerLevel level = (ServerLevel) this.level();
        life++;
        ServerPlayer player = watched == null ? null : level.getServer().getPlayerList().getPlayer(watched);
        if (player == null || player.level() != level || life > MAX_LIFE) {
            vanish();
            return;
        }

        // Oyuncuya dogru don
        double dx = player.getX() - getX();
        double dz = player.getZ() - getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;

        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < VANISH_DISTANCE) {
            vanish();
            return;
        }

        // Dogrudan ona bakiyorsa bir sure sonra kaybolur
        Vec3 look = player.getViewVector(1.0F).normalize();
        Vec3 to = this.getEyePosition().subtract(player.getEyePosition()).normalize();
        if (look.dot(to) > 0.985D && player.hasLineOfSight(this)) {
            if (++stare >= STARE_TICKS) {
                vanish();
            }
        } else if (stare > 0) {
            stare--;
        }
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1.2, getZ(), 12, 0.3, 0.8, 0.3, 0.01);
        }
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide) vanish();
        return false;
    }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean canBeCollidedWith() { return false; }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public boolean removeWhenFarAway(double dist) { return true; }
}
