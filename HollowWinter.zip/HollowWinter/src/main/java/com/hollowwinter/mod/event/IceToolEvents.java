package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.item.IceTool;
import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Buz esyalar: kisin 9. gunun'den itibaren, bir oyuncunun suya (buzu kirip actigi suya) attigi kazma, balta, kurek ya da
 * capa (malzemesi fark etmez) suda ~2 saniye kalinca buz versiyonuna donusur (buyuleri korunur).
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class IceToolEvents {

    private static final double ICE_FROM_DAY = 9.0;
    private static final int WATER_TICKS_NEEDED = 40;
    private static final int MAX_TRACK_AGE = 6000; // 5 dk sonra takibi birak
    private static final String WATER_KEY = "hollowwinter_water_ticks";

    private static final List<ItemEntity> TRACKED = new ArrayList<>();

    /** Buza donusen esya: su yuzeyinde sabit durur (batmaz, suruklenmez), boylece kolayca alinir. */
    private record Floater(ItemEntity entity, double y) {}
    private static final List<Floater> FLOATERS = new ArrayList<>();

    @Nullable
    private static Item iceVersion(ItemStack stack) {
        Item item = stack.getItem();
        if (item instanceof IceTool) return null;
        if (item instanceof PickaxeItem) return ModItems.ICE_PICKAXE.get();
        if (item instanceof AxeItem) return ModItems.ICE_AXE.get();
        if (item instanceof ShovelItem) return ModItems.ICE_SHOVEL.get();
        if (item instanceof HoeItem) return ModItems.ICE_HOE.get();
        return null;
    }

    @SubscribeEvent
    public static void onToss(ItemTossEvent event) {
        ItemEntity entity = event.getEntity();
        if (entity.level().isClientSide) return;
        if (iceVersion(entity.getItem()) != null) {
            TRACKED.add(entity);
        }
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        holdFloaters(level);
        if (TRACKED.isEmpty() || level.getGameTime() % 10L != 0L) return;

        boolean iceTime = WinterManager.daysSinceOrigin(level) >= ICE_FROM_DAY;

        Iterator<ItemEntity> it = TRACKED.iterator();
        while (it.hasNext()) {
            ItemEntity e = it.next();
            if (e.isRemoved() || e.level() != level || e.getAge() > MAX_TRACK_AGE) {
                it.remove();
                continue;
            }
            if (!iceTime) continue;

            int ticks = e.getPersistentData().getInt(WATER_KEY);
            if (e.isInWater()) {
                ticks += 10;
            } else {
                ticks = 0;
            }
            e.getPersistentData().putInt(WATER_KEY, ticks);

            if (ticks >= WATER_TICKS_NEEDED) {
                convert(level, e);
                it.remove();
            }
        }
    }

    private static void holdFloaters(ServerLevel level) {
        if (FLOATERS.isEmpty()) return;
        Iterator<Floater> it = FLOATERS.iterator();
        while (it.hasNext()) {
            Floater f = it.next();
            ItemEntity e = f.entity();
            if (e.isRemoved() || e.level() != level) {
                it.remove();
                continue;
            }
            e.setDeltaMovement(Vec3.ZERO);
            e.setPos(e.getX(), f.y(), e.getZ());
        }
    }

    private static void convert(ServerLevel level, ItemEntity old) {
        ItemStack oldStack = old.getItem();
        Item ice = iceVersion(oldStack);
        if (ice == null) return;

        ItemStack fresh = new ItemStack(ice);
        EnchantmentHelper.setEnchantments(EnchantmentHelper.getEnchantments(oldStack), fresh);

        ItemEntity result = new ItemEntity(level, old.getX(), old.getY(), old.getZ(), fresh);
        // Suyun en ustune cik ve orada sabit kal
        BlockPos water = old.blockPosition();
        for (int i = 0; i < 8 && level.getFluidState(water.above()).is(FluidTags.WATER); i++) {
            water = water.above();
        }
        double surfaceY = water.getY() + 0.78;
        result.setPos(old.getX(), surfaceY, old.getZ());
        result.setDeltaMovement(Vec3.ZERO);
        result.setNoGravity(true);
        result.setPickUpDelay(10);
        level.addFreshEntity(result);
        FLOATERS.add(new Floater(result, surfaceY));
        old.discard();

        level.sendParticles(ParticleTypes.SNOWFLAKE, old.getX(), old.getY() + 0.3, old.getZ(), 25, 0.3, 0.3, 0.3, 0.05);
        level.playSound(null, old.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.2F, 1.0F);
        level.playSound(null, old.blockPosition(), SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.5F, 1.6F);
    }
}
