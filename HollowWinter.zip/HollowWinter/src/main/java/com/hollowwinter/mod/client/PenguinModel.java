package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.PenguinEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Imparator penguen modeli. Doku 64x32: textures/entity/penguin.png
 * Tum parcalar "all" grubunda (ayak seviyesi = pivot). Kayarken grup 90 derece one yatar (yuz ustu).
 */
public class PenguinModel extends EntityModel<PenguinEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowWinter.MODID, "penguin"), "main");

    private final ModelPart all;
    private final ModelPart head;
    private final ModelPart flipperL;
    private final ModelPart flipperR;
    private final ModelPart footL;
    private final ModelPart footR;

    public PenguinModel(ModelPart root) {
        this.all = root.getChild("all");
        this.head = all.getChild("head");
        this.flipperL = all.getChild("flipperL");
        this.flipperR = all.getChild("flipperR");
        this.footL = all.getChild("footL");
        this.footR = all.getChild("footR");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition all = root.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));
        all.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -3.0F, 8.0F, 14.0F, 6.0F),
                PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition head = all.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 20).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F),
                PartPose.offset(0.0F, -15.0F, 0.0F));
        head.addOrReplaceChild("beak", CubeListBuilder.create().texOffs(28, 0).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 2.0F),
                PartPose.offset(0.0F, -2.0F, -3.0F));
        all.addOrReplaceChild("flipperL", CubeListBuilder.create().texOffs(28, 4).addBox(0.0F, 0.0F, -2.0F, 1.0F, 9.0F, 4.0F),
                PartPose.offset(4.0F, -14.0F, 0.0F));
        all.addOrReplaceChild("flipperR", CubeListBuilder.create().texOffs(38, 4).addBox(-1.0F, 0.0F, -2.0F, 1.0F, 9.0F, 4.0F),
                PartPose.offset(-4.0F, -14.0F, 0.0F));
        all.addOrReplaceChild("footL", CubeListBuilder.create().texOffs(48, 0).addBox(-1.5F, 0.0F, -3.0F, 3.0F, 1.0F, 4.0F),
                PartPose.offset(2.0F, -1.0F, -1.0F));
        all.addOrReplaceChild("footR", CubeListBuilder.create().texOffs(48, 0).addBox(-1.5F, 0.0F, -3.0F, 3.0F, 1.0F, 4.0F),
                PartPose.offset(-2.0F, -1.0F, -1.0F));
        all.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(28, 20).addBox(-1.5F, 0.0F, 0.0F, 3.0F, 1.0F, 3.0F),
                PartPose.offset(0.0F, -3.0F, 3.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(PenguinEntity entity, float limbSwing, float limbSwingAmount, float age,
                          float netHeadYaw, float headPitch) {
        if (entity.isSliding()) {
            // Yuz ustu kayma: govde one yatar, kanatlar yanlara acik, bas yukari
            all.xRot = Mth.HALF_PI;
            all.y = 21.0F;
            all.zRot = 0.0F;
            head.xRot = -0.9F;
            head.yRot = 0.0F;
            flipperL.zRot = -1.25F;
            flipperR.zRot = 1.25F;
            footL.xRot = 0.0F;
            footR.xRot = 0.0F;
        } else {
            all.xRot = 0.0F;
            all.y = 24.0F;
            // Sallanarak yuruyus
            float swing = limbSwing * 0.7F;
            all.zRot = Mth.sin(swing) * 0.14F * Math.min(1.0F, limbSwingAmount * 3.0F);
            head.xRot = headPitch * Mth.DEG_TO_RAD;
            head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
            flipperL.zRot = -0.12F - Mth.cos(swing) * 0.35F * limbSwingAmount;
            flipperR.zRot = 0.12F + Mth.cos(swing) * 0.35F * limbSwingAmount;
            footL.xRot = Mth.cos(swing) * 0.6F * limbSwingAmount;
            footR.xRot = -Mth.cos(swing) * 0.6F * limbSwingAmount;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay,
                               float r, float g, float b, float a) {
        all.render(poseStack, buffer, light, overlay, r, g, b, a);
    }
}
