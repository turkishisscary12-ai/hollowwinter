package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/** Donmus yaratiklar: kendi dokusu mavimsi tonlanir, ustune buz/kiragi dokusu biner. */
public class FrostLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation FROST =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/frost.png");
    private final LivingEntityRenderer<T, M> renderer;

    public FrostLayer(LivingEntityRenderer<T, M> renderer) {
        super(renderer);
        this.renderer = renderer;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || !ClientFrozenData.isFrozen(entity.getId())) return;
        ResourceLocation own = renderer.getTextureLocation(entity);
        renderColoredCutoutModel(getParentModel(), own, ps, buf, light, entity, 0.62F, 0.82F, 1.0F);
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(FROST));
        getParentModel().renderToBuffer(ps, vc, light, LivingEntityRenderer.getOverlayCoords(entity, 0.0F),
                1.0F, 1.0F, 1.0F, 0.85F);
    }
}
