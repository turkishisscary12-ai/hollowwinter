package com.hollowwinter.mod.item;

/** Isaret arayuzu: buz aletleri (tekrar buza cevrilmesinler). */
public interface IceTool {
}
