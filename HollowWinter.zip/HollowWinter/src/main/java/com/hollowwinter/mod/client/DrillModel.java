package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Maden makinesinin donen matkap ucu ("drill": yaka + sivri koni + 2 kesici kol) ve mili ("rod").
 * Blok varligi yerleskesinde (y yukari) cizilir. Doku: textures/entity/miner_drill.png (128x128).
 */
public class DrillModel {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(HollowWinter.MODID, "miner_drill"), "main");

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("drill",
                CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, 0.0F, -7.0F, 14.0F, 3.0F, 14.0F).texOffs(56, 0).addBox(-6.0F, -4.0F, -6.0F, 12.0F, 4.0F, 12.0F).texOffs(0, 17).addBox(-5.0F, -8.0F, -5.0F, 10.0F, 4.0F, 10.0F).texOffs(40, 17).addBox(-4.0F, -12.0F, -4.0F, 8.0F, 4.0F, 8.0F).texOffs(72, 17).addBox(-3.0F, -14.0F, -3.0F, 6.0F, 2.0F, 6.0F).texOffs(96, 17).addBox(-2.0F, -16.0F, -2.0F, 4.0F, 2.0F, 4.0F),
                PartPose.ZERO);
        root.addOrReplaceChild("blades",
                CubeListBuilder.create().texOffs(0, 31).addBox(-22.0F, 3.0F, -2.0F, 44.0F, 2.0F, 4.0F).texOffs(0, 37).addBox(-2.0F, 5.0F, -22.0F, 4.0F, 2.0F, 44.0F),
                PartPose.ZERO);
        root.addOrReplaceChild("rod",
                CubeListBuilder.create().texOffs(96, 37).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 16.0F, 4.0F),
                PartPose.ZERO);
        return LayerDefinition.create(mesh, 128, 128);
    }
}
