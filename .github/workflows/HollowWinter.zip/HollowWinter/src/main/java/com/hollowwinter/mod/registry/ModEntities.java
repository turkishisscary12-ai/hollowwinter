package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import com.hollowwinter.mod.entity.YetiSnowBlock;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HollowWinter.MODID);

    public static final RegistryObject<EntityType<YetiEntity>> YETI = ENTITIES.register("yeti",
            () -> EntityType.Builder.of(YetiEntity::new, MobCategory.MONSTER)
                    .sized(1.1F, 2.7F)
                    .clientTrackingRange(10)
                    .build(new ResourceLocation(HollowWinter.MODID, "yeti").toString()));

    public static final RegistryObject<EntityType<com.hollowwinter.mod.entity.MammothEntity>> MAMMOTH =
            ENTITIES.register("mammoth",
            () -> EntityType.Builder.of(com.hollowwinter.mod.entity.MammothEntity::new, MobCategory.CREATURE)
                    .sized(3.0F, 4.2F)
                    .clientTrackingRange(10)
                    .build(new ResourceLocation(HollowWinter.MODID, "mammoth").toString()));

    public static final RegistryObject<EntityType<com.hollowwinter.mod.entity.PenguinEntity>> PENGUIN =
            ENTITIES.register("penguin",
            () -> EntityType.Builder.of(com.hollowwinter.mod.entity.PenguinEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.0F)
                    .clientTrackingRange(8)
                    .build(new ResourceLocation(HollowWinter.MODID, "penguin").toString()));

    public static final RegistryObject<EntityType<com.hollowwinter.mod.entity.SledEntity>> SLED =
            ENTITIES.register("sled",
            () -> EntityType.Builder.<com.hollowwinter.mod.entity.SledEntity>of(com.hollowwinter.mod.entity.SledEntity::new, MobCategory.MISC)
                    .sized(1.2F, 0.5F)
                    .clientTrackingRange(10)
                    .updateInterval(3)
                    .build(new ResourceLocation(HollowWinter.MODID, "sled").toString()));

    public static final RegistryObject<EntityType<com.hollowwinter.mod.entity.OwlEntity>> OWL =
            ENTITIES.register("owl",
            () -> EntityType.Builder.of(com.hollowwinter.mod.entity.OwlEntity::new, MobCategory.AMBIENT)
                    .sized(0.5F, 0.8F)
                    .clientTrackingRange(16)
                    .build(new ResourceLocation(HollowWinter.MODID, "owl").toString()));

    public static final RegistryObject<EntityType<com.hollowwinter.mod.entity.ShadowFigureEntity>> SHADOW_FIGURE =
            ENTITIES.register("shadow_figure",
            () -> EntityType.Builder.of(com.hollowwinter.mod.entity.ShadowFigureEntity::new, MobCategory.MISC)
                    .sized(0.6F, 2.4F)
                    .clientTrackingRange(16)
                    .build(new ResourceLocation(HollowWinter.MODID, "shadow_figure").toString()));

    public static final RegistryObject<EntityType<YetiSnowBlock>> YETI_SNOW_BLOCK = ENTITIES.register("yeti_snow_block",
            () -> EntityType.Builder.<YetiSnowBlock>of(YetiSnowBlock::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(new ResourceLocation(HollowWinter.MODID, "yeti_snow_block").toString()));

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
    }
}
