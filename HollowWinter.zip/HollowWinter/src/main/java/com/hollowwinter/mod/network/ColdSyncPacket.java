package com.hollowwinter.mod.network;

import com.hollowwinter.mod.client.ClientColdData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucu -> Istemci: oyuncunun soguk degeri (0-100) ve o saniyedeki degisimi. */
public class ColdSyncPacket {
    private final float cold;
    private final float trend;

    public ColdSyncPacket(float cold, float trend) {
        this.cold = cold;
        this.trend = trend;
    }

    public static void encode(ColdSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeFloat(msg.cold);
        buf.writeFloat(msg.trend);
    }

    public static ColdSyncPacket decode(FriendlyByteBuf buf) {
        return new ColdSyncPacket(buf.readFloat(), buf.readFloat());
    }

    public static void handle(ColdSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        // ClientColdData sadece sayi tutan duz bir sinif, sunucuda yuklenmesi sorun degil.
        ClientColdData.update(msg.cold, msg.trend);
    }
}
