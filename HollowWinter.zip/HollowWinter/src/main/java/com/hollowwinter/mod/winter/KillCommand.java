package com.hollowwinter.mod.winter;

import com.hollowwinter.mod.HollowWinter;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.tree.CommandNode;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;

/** /kill komutunu operator gerektirmeden herkese acar (vanilla ile ayni sozdizimi). */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class KillCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        removeChild(d.getRoot(), "kill"); // vanilla'nin op isteyen dugumunu kaldir
        d.register(Commands.literal("kill")
                .executes(ctx -> {
                    Entity self = ctx.getSource().getEntityOrException();
                    self.kill();
                    ctx.getSource().sendSuccess(() -> Component.translatable("commands.kill.success.single", self.getDisplayName()), true);
                    return 1;
                })
                .then(Commands.argument("targets", EntityArgument.entities())
                        .executes(ctx -> {
                            Collection<? extends Entity> targets = EntityArgument.getEntities(ctx, "targets");
                            for (Entity e : targets) e.kill();
                            if (targets.size() == 1) {
                                ctx.getSource().sendSuccess(() -> Component.translatable("commands.kill.success.single",
                                        targets.iterator().next().getDisplayName()), true);
                            } else {
                                ctx.getSource().sendSuccess(() -> Component.translatable("commands.kill.success.multiple",
                                        targets.size()), true);
                            }
                            return targets.size();
                        })));
    }

    @SuppressWarnings("unchecked")
    private static void removeChild(CommandNode<CommandSourceStack> root, String name) {
        try {
            for (String f : new String[]{"children", "literals", "arguments"}) {
                Field field = CommandNode.class.getDeclaredField(f);
                field.setAccessible(true);
                ((Map<String, ?>) field.get(root)).remove(name);
            }
        } catch (ReflectiveOperationException ex) {
            HollowWinter.LOGGER.warn("Vanilla /kill kaldirilamadi: {}", ex.toString());
        }
    }
}
