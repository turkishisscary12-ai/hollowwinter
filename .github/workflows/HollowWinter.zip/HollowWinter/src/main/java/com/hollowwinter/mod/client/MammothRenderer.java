package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.MammothEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MammothRenderer extends MobRenderer<MammothEntity, MammothModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/mammoth.png");

    public MammothRenderer(EntityRendererProvider.Context context) {
        super(context, new MammothModel(context.bakeLayer(MammothModel.LAYER)), 1.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(MammothEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(MammothEntity entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) {
            poseStack.scale(0.5F, 0.5F, 0.5F);
            this.shadowRadius = 0.75F;
        } else {
            this.shadowRadius = 1.5F;
        }
    }
}
