package com.hollowwinter.mod.client;

/** Istemcide son bilinen soguk degeri. Sadece veri tutar, istemciye ozel kod icermez. */
public class ClientColdData {
    private static float cold = 0.0F;
    private static float trend = 0.0F;

    public static void update(float newCold, float newTrend) {
        cold = newCold;
        trend = newTrend;
    }

    /** 0-100 arasi soguk. */
    public static float cold() {
        return cold;
    }

    /** Pozitif: soguyor, negatif: isiniyor. */
    public static float trend() {
        return trend;
    }
}
