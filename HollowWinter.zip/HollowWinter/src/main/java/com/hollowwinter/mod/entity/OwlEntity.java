package com.hollowwinter.mod.entity;

import com.hollowwinter.mod.registry.ModItems;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Baykus: geceleri agac yapraklarinin ustunde oturur ve oyuncuya dikilip bakar. Yaklasirsan, vurulursa ya da
 * sabah olursa ucup gider. 6. gunden sonra dogan baykuslar "donmus" halde gelir (buz mavisi, parlayan gozler).
 */
public class OwlEntity extends PathfinderMob {
    public static final int FROZEN_DAY = 6;
    private static final EntityDataAccessor<Boolean> FROZEN =
            SynchedEntityData.defineId(OwlEntity.class, EntityDataSerializers.BOOLEAN);

    private int fleeTicks = -1;
    private Vec3 fleeDir = Vec3.ZERO;

    public OwlEntity(EntityType<? extends OwlEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(FROZEN, false);
    }

    public boolean isFrozenVariant() {
        return this.entityData.get(FROZEN);
    }

    public void setFrozenVariant(boolean v) {
        this.entityData.set(FROZEN, v);
    }

    @Override
    protected void registerGoals() {
        // Hareket hedefi yok: oturur, sadece bakar
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 40.0F, 1.0F));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        setFrozenVariant(WinterManager.daysSinceOrigin(level.getLevel()) >= FROZEN_DAY);
        return result;
    }

    /** Gece, yaprak ustunde (veya agac gövdesinde), acik havada. */
    public static boolean checkSpawn(EntityType<OwlEntity> type, ServerLevelAccessor level, MobSpawnType reason,
                                     BlockPos pos, RandomSource random) {
        ServerLevel sl = level.getLevel();
        if (sl.dimension() != Level.OVERWORLD) return false;
        if (!sl.isNight()) return false;
        if (!level.getBlockState(pos).isAir()) return false;
        var below = level.getBlockState(pos.below());
        return below.is(BlockTags.LEAVES) || below.is(BlockTags.LOGS);
    }

    @Override
    public boolean isPushable() {
        return fleeTicks >= 0;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) return;
        if (fleeTicks < 0) {
            Player near = this.level().getNearestPlayer(this, 3.5D);
            boolean day = this.level().isDay() && this.random.nextInt(150) == 0;
            if (near != null || day || this.hurtTime > 0) {
                Vec3 away = near != null
                        ? this.position().subtract(near.position()).multiply(1, 0, 1)
                        : new Vec3(this.random.nextDouble() - 0.5, 0, this.random.nextDouble() - 0.5);
                fleeDir = away.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : away.normalize();
                fleeTicks = 50;
                this.setNoGravity(true);
                this.playSound(SoundEvents.BAT_TAKEOFF, 0.8F, 0.6F);
            }
        } else {
            fleeTicks--;
            this.setDeltaMovement(fleeDir.x * 0.18, 0.14, fleeDir.z * 0.18);
            this.setYRot((float) (Math.toDegrees(Math.atan2(-fleeDir.x, fleeDir.z))));
            this.yBodyRot = this.getYRot();
            if (this.isFrozenVariant() && this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 0.4, getZ(), 1, 0.15, 0.15, 0.15, 0.0);
            }
            if (fleeTicks <= 0) this.discard();
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        int n = this.random.nextInt(3);
        if (n > 0) {
            this.spawnAtLocation(new ItemStack(isFrozenVariant() ? ModItems.FROZEN_FEATHER.get() : Items.FEATHER, n));
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("FrozenOwl", isFrozenVariant());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setFrozenVariant(tag.getBoolean("FrozenOwl"));
    }

    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.PARROT_AMBIENT; }

    @Override
    protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.PARROT_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.PARROT_DEATH; }

    @Override
    public float getVoicePitch() { return super.getVoicePitch() * 0.45F; }

    @Override
    public int getAmbientSoundInterval() { return 240; }

    @Override
    public boolean removeWhenFarAway(double dist) { return true; }
}
