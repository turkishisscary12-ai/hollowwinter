package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.SledEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class SledRenderer extends EntityRenderer<SledEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/sled.png");
    private final SledModel model;

    public SledRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new SledModel(context.bakeLayer(SledModel.LAYER));
        this.shadowRadius = 0.7F;
    }

    @Override
    public void render(SledEntity entity, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        ps.pushPose();
        ps.translate(0.0D, 0.375D, 0.0D);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - yaw));
        float hurt = entity.getHurtTime() - partialTick;
        float dmg = Math.max(0.0F, entity.getDamage() - partialTick);
        if (hurt > 0.0F) {
            ps.mulPose(Axis.XP.rotationDegrees(Mth.sin(hurt) * hurt * dmg / 10.0F * entity.getHurtDir()));
        }
        ps.scale(-1.0F, -1.0F, 1.0F);
        this.model.setupAnim(entity, 0, 0, 0, 0, 0);
        VertexConsumer vc = buffers.getBuffer(this.model.renderType(TEXTURE));
        this.model.renderToBuffer(ps, vc, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();
        super.render(entity, yaw, partialTick, ps, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(SledEntity entity) {
        return TEXTURE;
    }
}
