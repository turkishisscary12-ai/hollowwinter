package com.hollowwinter.mod.winter;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/** Kalin kar icinde, yuzeyin ustunde ayakta durulacak noktayi bulur (yeti dogurmak icin). */
public final class SnowSurface {
    private SnowSurface() {}

    /**
     * Verilen x,z sutununda kar yuzeyinin ustundeki noktayi doner.
     * Alan yuklu degilse ya da agac yapraginin ustundeyse null doner.
     */
    @Nullable
    public static Vec3 standPos(ServerLevel level, double x, double z) {
        BlockPos column = BlockPos.containing(x, 0, z);
        if (!level.hasChunkAt(column)) return null;

        // Kar katmanlari hareketi engellemedigi icin heightmap zemini (kar yiginin altini) gosterir.
        BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, column);
        BlockState state = level.getBlockState(pos);
        boolean snowy = false;

        for (int guard = 0; state.is(Blocks.SNOW) && guard < 700; guard++) {
            snowy = true;
            int layers = state.getValue(SnowLayerBlock.LAYERS);
            if (layers < 8) {
                // Kismen dolu son katman: oyuncu bu katmanin carpisma yuksekliginin ustunde durur.
                return new Vec3(x, pos.getY() + (layers - 1) * 0.125, z);
            }
            pos = pos.above();
            state = level.getBlockState(pos);
        }

        if (!snowy && level.getBlockState(pos.below()).is(BlockTags.LEAVES)) return null;
        return new Vec3(x, pos.getY(), z);
    }
}
