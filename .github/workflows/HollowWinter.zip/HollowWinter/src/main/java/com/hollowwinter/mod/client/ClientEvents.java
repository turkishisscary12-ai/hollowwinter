package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Sadece istemcide: HUD katmanlarini kaydeder. */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerBelowAll("cold_frost", ColdOverlay::renderFrost);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "cold_bar", ColdOverlay::renderBar);
    }
}
