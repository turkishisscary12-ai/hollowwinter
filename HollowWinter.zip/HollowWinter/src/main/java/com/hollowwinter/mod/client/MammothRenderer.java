package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.MammothEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MammothRenderer extends MobRenderer<MammothEntity, MammothModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/mammoth.png");

    private static final float ADULT_SCALE = 1.35F;

    public MammothRenderer(EntityRendererProvider.Context context) {
        super(context, new MammothModel(context.bakeLayer(MammothModel.LAYER)), 1.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(MammothEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(MammothEntity entity, PoseStack poseStack, float partialTick) {
        // Yetiskin 1.35x buyuk (hitbox 3.0 x 4.2 ile uyumlu), yavru yetiskinin yarisi
        float s = entity.isBaby() ? ADULT_SCALE * 0.5F : ADULT_SCALE;
        poseStack.scale(s, s, s);
        this.shadowRadius = 1.5F * s;
    }
}
