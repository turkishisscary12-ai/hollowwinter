package com.hollowwinter.mod.event;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.ShadowFigureEntity;
import com.hollowwinter.mod.registry.ModEntities;
import com.hollowwinter.mod.winter.SnowSurface;
import com.hollowwinter.mod.winter.StormManager;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Atmosfer (kis basladiktan sonra, acik havada):
 *  - Uzak sesler: ulumalar, agac catirdamasi, kar cokmesi, uzaktan ayak sesleri.
 *  - Bozuk ortam: ormanda gece ya da firtinada uzakta bir golge figur belirir, sana bakar, bakinca kaybolur.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class AtmosphereEvents {
    private static final Map<UUID, Long> NEXT_SOUND = new HashMap<>();
    private static final Map<UUID, Long> NEXT_WIND = new HashMap<>();
    private static final Map<UUID, Long> NEXT_FIGURE = new HashMap<>();
    private static final Map<UUID, UUID> FIGURE_OF = new HashMap<>();
    private static final List<Delayed> QUEUE = new ArrayList<>();

    private record Delayed(long time, ServerLevel level, Vec3 pos, SoundEvent sound, float vol, float pitch) {}

    /** Gun karakteri: dunya tohumu + gun numarasindan sabit. Yuzde 35'i "sessiz gun" (firtina yoksa). */
    public static boolean isSilentDay(ServerLevel level) {
        if (!WinterManager.hasWinterStarted(level) || StormManager.isStorm(level)) return false;
        long day = level.getDayTime() / 24000L;
        return RandomSource.create(level.getSeed() * 7919L + day * 104729L).nextInt(100) < 35;
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;
        if (!(player.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;
        if (!WinterManager.hasWinterStarted(level)) return;
        if (player.isSpectator() || !SnowSurface.exposed(level, player.blockPosition())) return;

        long now = level.getGameTime();
        RandomSource r = level.getRandom();
        boolean dark = level.isNight() || StormManager.isStorm(level);

        boolean silent = isSilentDay(level);
        if (silent) {
            // Tam sessizlik: uzak ses yok, sadece cok hafif ruzgar
            long nw = NEXT_WIND.computeIfAbsent(player.getUUID(), k -> now + 100 + r.nextInt(200));
            if (now >= nw) {
                NEXT_WIND.put(player.getUUID(), now + 260 + r.nextInt(300));
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        com.hollowwinter.mod.registry.ModSounds.CALM_WIND.get(), SoundSource.AMBIENT,
                        0.3F, 0.9F + r.nextFloat() * 0.2F);
            }
        }

        // ---- uzak sesler
        long ns = NEXT_SOUND.computeIfAbsent(player.getUUID(), k -> now + 400 + r.nextInt(600));
        if (!silent && now >= ns) {
            NEXT_SOUND.put(player.getUUID(), now + (dark ? 300 : 600) + r.nextInt(dark ? 700 : 1400));
            distantSound(level, player, r);
        }

        // ---- golge figur (ormanda, gece ya da firtinada)
        if (!dark) return;
        var biome = level.getBiome(player.blockPosition());
        if (!(biome.is(BiomeTags.IS_FOREST) || biome.is(BiomeTags.IS_TAIGA))) return;
        UUID existing = FIGURE_OF.get(player.getUUID());
        if (existing != null && level.getEntity(existing) != null) return;
        long nf = NEXT_FIGURE.computeIfAbsent(player.getUUID(), k -> now + 1200 + r.nextInt(2400));
        if (now < nf) return;
        NEXT_FIGURE.put(player.getUUID(), now + 3600 + r.nextInt(6000)); // 3-8 dk
        spawnFigure(level, player, r);
    }

    public static void testDistantSound(ServerLevel level, ServerPlayer player) {
        distantSound(level, player, level.getRandom());
    }

    public static boolean testSpawnFigure(ServerLevel level, ServerPlayer player) {
        return spawnFigure(level, player, level.getRandom());
    }

    private static void distantSound(ServerLevel level, ServerPlayer player, RandomSource r) {
        double angle = r.nextDouble() * Math.PI * 2;
        double dist = 28 + r.nextDouble() * 16;
        double x = player.getX() + Math.cos(angle) * dist;
        double z = player.getZ() + Math.sin(angle) * dist;
        BlockPos g = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, BlockPos.containing(x, 0, z));
        Vec3 pos = new Vec3(x, g.getY(), z);
        long now = level.getGameTime();
        switch (r.nextInt(5)) {
            case 0 -> play(level, pos, SoundEvents.WOLF_HOWL, 2.5F, 0.55F + r.nextFloat() * 0.15F);
            case 1 -> { // agac catirdamasi
                play(level, pos, SoundEvents.WOOD_BREAK, 2.5F, 0.5F);
                queue(now + 8, level, pos, SoundEvents.WOOD_HIT, 2.5F, 0.45F);
                queue(now + 20, level, pos, SoundEvents.WOOD_BREAK, 2.5F, 0.4F);
            }
            case 2 -> { // kar cokmesi
                play(level, pos, SoundEvents.SNOW_BREAK, 3.0F, 0.5F);
                queue(now + 6, level, pos, SoundEvents.SNOW_BREAK, 3.0F, 0.4F);
            }
            case 3 -> { // yaklasan agir ayak sesleri
                for (int i = 0; i < 6; i++) {
                    queue(now + i * 12L, level, pos.add((r.nextDouble() - 0.5) * 3, 0, (r.nextDouble() - 0.5) * 3),
                            SoundEvents.SNOW_STEP, 2.0F, 0.5F);
                }
            }
            default -> play(level, pos, SoundEvents.FOX_SCREECH, 2.0F, 0.5F);
        }
    }

    private static boolean spawnFigure(ServerLevel level, ServerPlayer player, RandomSource r) {
        // Oyuncunun baktigi yonde +-50 derece, 24-32 blok
        float yaw = player.getYRot() + (r.nextFloat() - 0.5F) * 100.0F;
        double rad = Math.toRadians(yaw);
        double dist = 24 + r.nextDouble() * 8;
        double x = player.getX() - Math.sin(rad) * dist;
        double z = player.getZ() + Math.cos(rad) * dist;
        BlockPos col = BlockPos.containing(x, 0, z);
        if (!level.hasChunkAt(col)) return false;
        BlockPos g = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, col);
        if (!level.getFluidState(g).isEmpty() || !level.getFluidState(g.below()).isEmpty()) return false;
        ShadowFigureEntity figure = ModEntities.SHADOW_FIGURE.get().create(level);
        if (figure == null) return false;
        figure.moveTo(x, g.getY(), z, 0, 0);
        if (!level.noCollision(figure, figure.getBoundingBox())) return false;
        figure.setWatched(player.getUUID());
        level.addFreshEntity(figure);
        FIGURE_OF.put(player.getUUID(), figure.getUUID());
        return true;
    }

    private static void play(ServerLevel level, Vec3 pos, SoundEvent sound, float vol, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, sound, SoundSource.AMBIENT, vol, pitch);
    }

    private static void queue(long time, ServerLevel level, Vec3 pos, SoundEvent sound, float vol, float pitch) {
        QUEUE.add(new Delayed(time, level, pos, sound, vol, pitch));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || QUEUE.isEmpty()) return;
        Iterator<Delayed> it = QUEUE.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (d.level().getGameTime() >= d.time()) {
                play(d.level(), d.pos(), d.sound(), d.vol(), d.pitch());
                it.remove();
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        NEXT_SOUND.remove(id);
        NEXT_WIND.remove(id);
        NEXT_FIGURE.remove(id);
        FIGURE_OF.remove(id);
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        NEXT_SOUND.clear();
        NEXT_WIND.clear();
        NEXT_FIGURE.clear();
        FIGURE_OF.clear();
        QUEUE.clear();
    }
}
