package com.hollowwinter.mod.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hollow Winter: her biyomda (col, orman, okyanus dahil) yagis KAR olarak yagsin.
 * Oyun yagmur yerine kar efekti cizer. Hava yokken zaten yagis olmadigi icin
 * kis baslamadan once gorsel bir etkisi yoktur.
 */
@Mixin(Biome.class)
public abstract class BiomeMixin {

    @Inject(method = "getPrecipitationAt", at = @At("HEAD"), cancellable = true)
    private void hollowwinter$alwaysSnow(BlockPos pos, CallbackInfoReturnable<Biome.Precipitation> cir) {
        cir.setReturnValue(Biome.Precipitation.SNOW);
    }
}
