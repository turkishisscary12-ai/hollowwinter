package com.hollowwinter.mod.mixin;

import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AbstractFurnaceBlockEntity.class)
public interface FurnaceAccessor {
    @Accessor("litTime")
    int hollowwinter$getLitTime();

    @Accessor("litDuration")
    int hollowwinter$getLitDuration();

    @Accessor("cookingProgress")
    void hollowwinter$setCookingProgress(int value);
}
