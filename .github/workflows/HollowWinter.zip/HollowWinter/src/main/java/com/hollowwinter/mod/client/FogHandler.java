package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Kovalamaca sisi (koyu) ve kar firtinasi (beyaz, cok yogun) icin sis (sadece istemci). */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, value = Dist.CLIENT)
public class FogHandler {

    /** Tam sisteki gorus mesafesi (blok). */
    private static final float CHASE_FOG_FAR = 16.0F;
    private static final float STORM_FOG_FAR = 8.0F;

    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        float kc = ClientFogData.smoothed();
        float ks = ClientFogData.smoothedStorm();
        if (kc < 0.01F && ks < 0.01F) return;
        if (event.getType() != FogType.NONE) return; // su/lav icindeysek dokunma

        float far = event.getFarPlaneDistance();
        float near = event.getNearPlaneDistance();
        float k = Math.max(kc, ks);
        float targetFar = far;
        if (kc >= 0.01F) targetFar = Math.min(targetFar, Mth.lerp(kc, far, CHASE_FOG_FAR));
        if (ks >= 0.01F) targetFar = Math.min(targetFar, Mth.lerp(ks, far, STORM_FOG_FAR));

        event.setNearPlaneDistance(Mth.lerp(k, near, 0.0F));
        event.setFarPlaneDistance(targetFar);
        event.setCanceled(true); // degisikliklerin uygulanmasi icin gerekli
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        float ks = ClientFogData.stormCurrent();
        float kc = ClientFogData.current();
        float r = event.getRed(), g = event.getGreen(), b = event.getBlue();
        if (ks >= 0.01F) { // firtina: beyaz-gri
            r = Mth.lerp(ks, r, 0.80F);
            g = Mth.lerp(ks, g, 0.84F);
            b = Mth.lerp(ks, b, 0.88F);
        }
        if (kc >= 0.01F) { // kovalamaca: koyu mavi-gri
            r = Mth.lerp(kc, r, 0.30F);
            g = Mth.lerp(kc, g, 0.34F);
            b = Mth.lerp(kc, b, 0.40F);
        }
        event.setRed(r);
        event.setGreen(g);
        event.setBlue(b);
    }
}
