package com.hollowwinter.mod.block;

import com.hollowwinter.mod.winter.HeatZones;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;

/**
 * Isi makinesi. Onundeki (izgara yonu) 3 genis, 24 uzun koridordaki tum kari eritir: kar ne kadar yuksek olursa olsun,
 * makinenin seviyesinden 5 blok yukseye kadar acilir ve oyuncuya gececek yer acilir. Isittigi sutunlarda 2 saniye
 * boyunca kar birikmez (makine calistigi surece yeni kar tutmaz). Kirmizi tas sinyali alirsa kapanir.
 */
public class HeaterBlock extends HorizontalDirectionalBlock {
    public static final int RANGE = 24;
    private static final int HALF_WIDTH = 1;
    private static final int HEIGHT = 5;
    private static final int RUN_INTERVAL = 4;      // tick
    private static final int HEAT_TICKS = 40;       // 2 saniye
    private static final int MELT_PER_COLUMN_RUN = 6;

    public HeaterBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    /** Izgara, oyuncunun baktigi yone doner (isi o yone gider). */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (!level.isClientSide && !oldState.is(this)) {
            level.scheduleTick(pos, this, RUN_INTERVAL);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!level.hasNeighborSignal(pos)) {
            heat(state, level, pos, random);
        }
        level.scheduleTick(pos, this, RUN_INTERVAL);
    }

    private void heat(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        Direction front = state.getValue(FACING);
        Direction side = front.getClockWise();
        long now = level.getGameTime();
        HeatZones.cleanup(now);

        for (int d = -1; d <= RANGE; d++) {
            for (int l = -HALF_WIDTH; l <= HALF_WIDTH; l++) {
                int x = pos.getX() + front.getStepX() * d + side.getStepX() * l;
                int z = pos.getZ() + front.getStepZ() * d + side.getStepZ() * l;
                BlockPos column = new BlockPos(x, pos.getY(), z);
                if (!level.hasChunkAt(column)) continue;

                HeatZones.mark(x, z, now + HEAT_TICKS);
                melt(level, column);
            }
        }

        // Buhar / isi efekti
        int d = 1 + random.nextInt(RANGE);
        int l = random.nextInt(3) - 1;
        double px = pos.getX() + 0.5 + front.getStepX() * d + side.getStepX() * l;
        double pz = pos.getZ() + 0.5 + front.getStepZ() * d + side.getStepZ() * l;
        level.sendParticles(ParticleTypes.CLOUD, px, pos.getY() + 0.5 + random.nextInt(3), pz, 2, 0.3, 0.3, 0.3, 0.01);
    }

    /** Sutunda makinenin seviyesinden HEIGHT blok yukseye kadar kari erit (tek seferde en fazla MELT_PER_COLUMN_RUN blok). */
    private void melt(ServerLevel level, BlockPos start) {
        int removed = 0;
        for (int dy = 0; dy < HEIGHT && removed < MELT_PER_COLUMN_RUN; dy++) {
            BlockPos p = start.above(dy);
            BlockState s = level.getBlockState(p);
            if (s.is(Blocks.SNOW) || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW)) {
                level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                removed++;
            }
        }
    }
}
