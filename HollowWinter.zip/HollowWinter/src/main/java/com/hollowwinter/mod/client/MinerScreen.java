package com.hollowwinter.mod.client;

import com.hollowwinter.mod.menu.MinerMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Maden makinesi kontrol paneli: derinlik ayari, baslat, geri cagir. Dokusuz, kodla cizilir. */
public class MinerScreen extends AbstractContainerScreen<MinerMenu> {

    public MinerScreen(MinerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 140;
        this.inventoryLabelY = 10000; // envanter yazisini gizle
    }

    @Override
    protected void init() {
        super.init();
        int x = leftPos, y = topPos;
        btn("-10", MinerMenu.BTN_MINUS10, x + 8, y + 44, 36);
        btn("-1", MinerMenu.BTN_MINUS1, x + 48, y + 44, 36);
        btn("+1", MinerMenu.BTN_PLUS1, x + 92, y + 44, 36);
        btn("+10", MinerMenu.BTN_PLUS10, x + 132, y + 44, 36);
        btn(Component.translatable("gui.hollowwinter.miner_max").getString(), MinerMenu.BTN_MAX, x + 8, y + 68, 44);
        btn(Component.translatable("gui.hollowwinter.miner_start").getString(), MinerMenu.BTN_START, x + 56, y + 68, 56);
        btn(Component.translatable("gui.hollowwinter.miner_recall").getString(), MinerMenu.BTN_RECALL, x + 116, y + 68, 52);
    }

    private void btn(String label, int id, int bx, int by, int w) {
        addRenderableWidget(Button.builder(Component.literal(label), b -> press(id)).bounds(bx, by, w, 18).build());
    }

    private void press(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partial, int mouseX, int mouseY) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xFF1E1E1E);
        g.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, 0xFFC6C6C6);
        g.fill(x + 6, y + 16, x + imageWidth - 6, y + 40, 0xFF2B3A4A);

        g.drawCenteredString(font, Component.translatable("gui.hollowwinter.miner_target"), x + 88, y + 19, 0xFFFFFF);
        g.drawCenteredString(font, Component.literal(menu.getTarget() + " / " + menu.getMaxDepth()),
                x + 88, y + 29, 0x7FD6FF);

        // ilerleme cubugu
        int bx = x + 8, by = y + 99, bw = imageWidth - 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, 0xFF373737);
        g.fill(bx, by, bx + bw, by + 8, 0xFF8B8B8B);
        int target = Math.max(1, menu.getTarget());
        int fill = Math.min(bw, Math.round(bw * (menu.getDepth() / (float) target)));
        g.fill(bx, by, bx + fill, by + 8, 0xFFE0A030);

        String key = switch (menu.getState()) {
            case 1 -> "gui.hollowwinter.miner_digging";
            case 2 -> "gui.hollowwinter.miner_rising";
            default -> "gui.hollowwinter.miner_idle";
        };
        g.drawCenteredString(font, Component.translatable(key), x + 88, y + 111, 0x303030);

        // yakit gostergesi
        int fx = x + 44, fy = y + 124, fw = imageWidth - 52;
        g.drawString(font, Component.translatable("gui.hollowwinter.miner_fuel"), x + 8, y + 124, 0x303030, false);
        g.fill(fx - 1, fy - 1, fx + fw + 1, fy + 9, 0xFF373737);
        g.fill(fx, fy, fx + fw, fy + 8, 0xFF8B8B8B);
        int ff = Math.round(fw * (menu.getFuel() / (float) com.hollowwinter.mod.block.MinerBlockEntity.MAX_FUEL));
        g.fill(fx, fy, fx + ff, fy + 8, menu.getFuel() > 0 ? 0xFF4A3016 : 0xFF8B8B8B);
        if (menu.getFuel() <= 0) {
            g.drawCenteredString(font, Component.translatable("gui.hollowwinter.miner_nofuel"), fx + fw / 2, fy, 0xAA2222);
        }
        g.drawCenteredString(font, Component.translatable("gui.hollowwinter.miner_depth", menu.getDepth()),
                x + 88, y + 88, 0x303030);
    }
}
