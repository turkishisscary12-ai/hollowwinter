package com.hollowwinter.mod.registry;

import com.hollowwinter.mod.HollowWinter;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModFluids {
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(ForgeRegistries.FLUIDS, HollowWinter.MODID);

    public static final RegistryObject<FlowingFluid> GASOLINE = FLUIDS.register("gasoline",
            () -> new ForgeFlowingFluid.Source(ModFluids.GASOLINE_PROPERTIES));
    public static final RegistryObject<FlowingFluid> GASOLINE_FLOWING = FLUIDS.register("flowing_gasoline",
            () -> new ForgeFlowingFluid.Flowing(ModFluids.GASOLINE_PROPERTIES));

    public static final ForgeFlowingFluid.Properties GASOLINE_PROPERTIES = new ForgeFlowingFluid.Properties(
            ModFluidTypes.GASOLINE, GASOLINE, GASOLINE_FLOWING)
            .block(ModBlocks.GASOLINE_BLOCK)
            .bucket(ModItems.GASOLINE_BUCKET)
            .slopeFindDistance(3)
            .levelDecreasePerBlock(1)
            .tickRate(8);

    public static void register(IEventBus bus) {
        FLUIDS.register(bus);
    }
}
