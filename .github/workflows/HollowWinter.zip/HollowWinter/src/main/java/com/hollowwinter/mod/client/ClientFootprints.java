package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.YetiEntity;
import com.hollowwinter.mod.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

/**
 * Karda ayak izleri (sadece gorsel, istemci tarafi): oyuncular ve yeti karda yururken sag-sol dönüşümlü iki
 * kare seklinde (Minecraft karakterinin ayagi gibi) iz birakir. Kar katmani degismez.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID, value = Dist.CLIENT)
public class ClientFootprints {
    private static final double RANGE_SQR = 40.0 * 40.0;
    private static final Map<Integer, Vec3> LAST = new HashMap<>();
    private static final Map<Integer, Boolean> LEFT = new HashMap<>();
    private static int cleanup = 0;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.isPaused()) return;

        for (Entity e : mc.level.entitiesForRendering()) {
            boolean yeti = e instanceof YetiEntity;
            if (!(e instanceof Player) && !yeti) continue;
            if (!(e instanceof LivingEntity le) || e.distanceToSqr(mc.player) > RANGE_SQR) continue;
            if (e.isSpectator() || e.isPassenger() || e.isInWater() || !e.onGround() || e.isInvisible()) continue;
            if (yeti && ((YetiEntity) e).getMode() == YetiEntity.MODE_WINDOW) continue; // hayalet yeti iz birakmaz

            Vec3 pos = e.position();
            Vec3 last = LAST.get(e.getId());
            if (last == null) {
                LAST.put(e.getId(), pos);
                continue;
            }
            double dx = pos.x - last.x, dz = pos.z - last.z;
            double stride = yeti ? 1.5 : 0.85;
            if (dx * dx + dz * dz < stride * stride) continue;

            double y = snowTop(e);
            if (Double.isNaN(y)) {
                LAST.put(e.getId(), pos);
                continue;
            }
            LAST.put(e.getId(), pos);

            double len = Math.sqrt(dx * dx + dz * dz);
            double fx = dx / len, fz = dz / len;
            boolean left = LEFT.merge(e.getId(), true, (a, b) -> !a);
            double side = (left ? -1 : 1) * (yeti ? 0.45 : 0.16);
            double x = pos.x + (-fz) * side;
            double z = pos.z + fx * side;
            double dir = Math.atan2(fz, fx);
            mc.level.addParticle(ModParticles.FOOTPRINT.get(), x, y + 0.012, z, dir, yeti ? 2.4 : 1.0, 0.0);
        }

        if (++cleanup > 600) {
            cleanup = 0;
            LAST.keySet().removeIf(id -> mc.level.getEntity(id) == null);
            LEFT.keySet().removeIf(id -> mc.level.getEntity(id) == null);
        }
    }

    /** Karin gorunen ust yuzeyinin yuksekligi; kar uzerinde degilse NaN. */
    private static double snowTop(Entity e) {
        BlockPos pos = e.blockPosition();
        BlockState state = e.level().getBlockState(pos);
        if (state.is(Blocks.SNOW)) {
            return pos.getY() + state.getValue(SnowLayerBlock.LAYERS) * 0.125;
        }
        BlockState below = e.level().getBlockState(pos.below());
        if (below.is(Blocks.SNOW_BLOCK) || below.is(Blocks.POWDER_SNOW)) {
            return pos.getY();
        }
        return Double.NaN;
    }
}
