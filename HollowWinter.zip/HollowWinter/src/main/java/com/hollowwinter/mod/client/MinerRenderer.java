package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.block.MinerBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/** Donen matkap ucunu ve mili cizer; uc, sunucudan gelen derinlige yumusakca iner/cikar. */
public class MinerRenderer implements BlockEntityRenderer<MinerBlockEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(HollowWinter.MODID, "textures/entity/miner_drill.png");
    /** Matkap yakasi, bosta durdugunda catinin hemen altinda (13/16 yukseklikte kesici kollar). */
    private static final float PIVOT_Y = 6.0F / 16.0F;
    private static final float SPIN_DEG_PER_TICK = 30.0F;

    private final ModelPart drill;
    private final ModelPart blades;
    private final ModelPart rod;

    public MinerRenderer(BlockEntityRendererProvider.Context context) {
        ModelPart root = context.bakeLayer(DrillModel.LAYER);
        this.drill = root.getChild("drill");
        this.blades = root.getChild("blades");
        this.rod = root.getChild("rod");
    }

    @Override
    public void render(MinerBlockEntity be, float partial, PoseStack ps, MultiBufferSource buffers,
                       int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;

        // Yumusak derinlik ve donus
        be.renderHead += (be.getHead() - be.renderHead) * 0.25F;
        float time = level.getGameTime() + partial;
        if (be.isActive()) {
            be.spin += (time - be.lastSpinTime) * SPIN_DEG_PER_TICK;
        }
        be.lastSpinTime = time;
        float head = Math.max(0.0F, be.renderHead);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        float spinRad = (float) Math.toRadians(be.spin % 360.0F);

        ps.pushPose();
        ps.translate(0.5D, PIVOT_Y - head, 0.5D);
        this.drill.yRot = spinRad;
        this.drill.render(ps, vc, light, overlay);
        // Kesici kollar bostayken katlidir (cerceve icinde kalir), inerken 3x3'luk deligi acacak sekilde acilir
        float open = Math.min(1.0F, head / 1.0F);
        if (open > 0.05F) {
            ps.pushPose();
            ps.scale(open, 1.0F, open);
            this.blades.yRot = spinRad;
            this.blades.render(ps, vc, light, overlay);
            ps.popPose();
        }
        if (head > 0.02F) {
            ps.pushPose();
            ps.translate(0.0D, 7.0D / 16.0D, 0.0D);   // kesici kollarin ustu
            ps.scale(1.0F, head, 1.0F);                // mil, catiya kadar uzanir
            this.rod.yRot = spinRad;
            this.rod.render(ps, vc, light, overlay);
            ps.popPose();
        }
        ps.popPose();
    }

    @Override
    public boolean shouldRenderOffScreen(MinerBlockEntity be) {
        return true;
    }
}
