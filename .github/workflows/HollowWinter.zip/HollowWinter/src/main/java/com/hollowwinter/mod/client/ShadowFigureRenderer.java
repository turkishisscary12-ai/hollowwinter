package com.hollowwinter.mod.client;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.entity.ShadowFigureEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/** Golge figur: ince ve uzun siyah siluet, parlayan soluk gozler. */
public class ShadowFigureRenderer extends HumanoidMobRenderer<ShadowFigureEntity, HumanoidModel<ShadowFigureEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(HollowWinter.MODID, "textures/entity/shadow_figure.png");
    private static final ResourceLocation EYES = new ResourceLocation(HollowWinter.MODID, "textures/entity/shadow_figure_eyes.png");

    public ShadowFigureRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE)), 0.0F);
        this.addLayer(new EyesLayer<ShadowFigureEntity, HumanoidModel<ShadowFigureEntity>>(this) {
            @Override
            public RenderType renderType() {
                return RenderType.eyes(EYES);
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(ShadowFigureEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ShadowFigureEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.95F, 1.35F, 0.95F);
    }
}
