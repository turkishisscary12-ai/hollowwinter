# Hollow Winter

Minecraft 1.20.1 (Forge 47.3.0) icin kis kiyameti modu.

## Kurulum
1. JDK 17 kur.
2. IntelliJ IDEA ile `build.gradle` dosyasini "Open as Project" ile ac.
3. Gradle wrapper yoksa: Forge 1.20.1 MDK'sindan `gradlew`, `gradlew.bat` ve `gradle/` klasorunu bu klasore kopyala
   (https://files.minecraftforge.net/ -> 1.20.1 -> MDK).
4. `./gradlew genIntellijRuns` sonra `runClient` ile test et.
5. `./gradlew build` ile jar `build/libs/` icine cikar.

## Su an olanlar
- Soguk sistemi (`cold/ColdHandler.java`): 0-100 soguk degeri, isi kaynaklari, zirh korumasi, gece/kar etkisi. %90+ 4 sn'de 1 can, %100 her saniye 1 can kaybi.
- Soguk HUD'u (`client/ColdOverlay.java`): hotbar ustunde renkli bar, kar tanesi ikonu, yuzde, isinma/soguma oku; %40+ ekran kenarlarinda buzlanma. Deger sunucudan `ColdSyncPacket` ile gelir.
- Ayak izleri (`winter/FootprintHandler.java`): karda yururken blok boyutunda cukur + kar tozu parcaciklari, yeni kar yagdikca dolar.
- Kurk zirh seti (`registry/`, `item/`): 4 parca + Kurk Parcasi (hayvanlardan duser). Tam set soguktan korur.
- Kis takvimi (`winter/WinterManager.java`, `WinterData.java`): sureler MINECRAFT GUNU. Mod dunyada ilk calistigindan 4 gun sonra kar baslar; 7-9 gun kar, sonra 5-6 gun acik hava; 20-30. gunlerde acik hava ~1 gune kisalir. `/hollowwinter status` ile takvim gorulur.
- Her biyomda kar efekti (`mixin/BiomeMixin.java`): yagmur yerine kar yagar.
- Kar birikimi ve erime (`winter/SnowAccumulator.java`): kar gunde ~1 blok yavasca yukselir, acik havada gunde ~3/8 blok erir, en fazla 43 blok. Cicek/fidan/ekin kirilip yerine kar gelir; patika ve tarla topraga donusup kar tutar.

## Ayarlar
- Kisin baslama gunu: `WinterManager.GRACE_DAYS`
- Takvim, hizlar ve yukseklik: `WinterManager` basindaki sabitler (GRACE_DAYS, MIN/MAX_SNOW_DAYS, EARLY_UNTIL_DAY, LATE_FROM_DAY, ACCUM/MELT_LAYERS_PER_DAY, MAX_LAYERS)
- Kar/erime hizi: `SnowAccumulator` basindaki ATTEMPTS sabitleri
- Not: kar sadece oyuncunun 56 blok yakinindaki yuklu alanda degisir

## Bilinen eksikler
- Mixin (`mixin/BiomeMixin.java`) her biyomda yagisi kar yapar. Henuz oyunda test edilmedi; calismazsa `Biome.getPrecipitationAt` adini kontrol et.

## Siradaki fikirler
- Kar firtinasi olayi
- Yakacak sistemi (ocak/kamp atesi odunla yansin)
- Schematic'lerden yapilar (NBT)

## Yeti
- Kis basladiktan 6 gun sonra olaylar acilir: pencere tikirtisi (dunyada max 3, gece %30), gece "Kac." kovalamacasi (90 sn, sis), sabah izleme + kar blogu (0.5 can, +10 soguk).
- Test: `/hollowwinter event chase|window|watch|stop` (op).
- Skin: `assets/hollowwinter/textures/entity/yeti.png` (64x64) dosyasini kendi skininle degistir.
- Spawn yumurtasi: Hollow Winter sekmesinde.

## Kar firtinasi
- Kar asamasinda gunluk %25 sansla 3-6 dk. Test: `/hollowwinter storm start|stop` (op). Ayarlar: `StormManager.java` ustu.

## Yeti kovalamaca (rework)
- Kovalamaca 350-550 blok uzakta gecer: oyuncu arkadasinin onunde kaybolur, bitince eski yerine doner. Uzakta kar silinir (bitince geri gelir). Yeti olmez/vurulmaz. Yakindaki oyunculardan sadece biri secilir.

## Isi makinesi (el esyasi)
- Tarif: 3 kirmizi tas + 2 piston (dizilimsiz). Sag tik basili tut: baktigin yondeki kari yavas yavas eritip 3x3'luk gecit acar; 2 sn kar birikmez.

## Su donmasi
- Kis basladiktan sonra sular ustten asagi yavasca buz olur; 5-10 gunde (dunyaya gore sabit) tamamen donar (sadece suyun ust 4 blogu). `/hollowwinter status` ilerlemeyi gosterir. Buzlar erimez.

## Buz esyalar
- Kisin 9. gunun'den sonra, buzu kirip actigin suya attigin kazma/balta/kurek/capa (her malzeme) ~2 sn sonra buz versiyonuna doner.
- Buz balta: 60 dayaniklilik, 5 hasar; oyuncuya +20 soguk, hepsine 2 sn yavaslik. Buz kazma: kazdigi blogun etrafindaki 3 blogu donmus bloga (tek yumrukta kirilir) cevirir. Buz kurek: 2x hizli. Buz capa: ozel guc yok.

## Donmus zemin ve cay duzeltmesi
- Kar baslamadan 1 gun once (gun 3'ten itibaren) acik yuzeydeki cim/toprak Donmus Cim / Donmus Toprak olur: ~3 kat yavas kirilir, kirilinca kendi isimleriyle duser.
- Cay: su dolu bardak sadece cay yapragi yakitiyla pisirilir (mixin: FurnaceMixin). Baska yakitla yanma baslamaz.

## Firtina duzeltmeleri
- Disaridakine agir yavaslik, cok yogun sis, zirhla bile soguk. Evlerin (tahta/tas/tugla cati) catilari %30 sansla (10 sn'de bir zar) sokulup ucar. Firtina boyunca kar 3x hizli birikir, bitince durur.

## Yeti ortam sesleri
- Ormanda/madende 5-12 dk'da bir uzaktan yeti yurume/nefes/gulme sesi (rastgele biri). Yakindakiler de duyar. Test: `/hollowwinter sound`. Sesler `assets/hollowwinter/sounds/yeti_steps|yeti_breath|yeti_laugh.ogg`; kendi (Pixabay) dosyalarinla ayni adla degistirebilirsin (mono OGG).

## Yeti kovalamaca duzeltmeleri
- Kar topu carptigi blogu kirar; yetiye yakin (9 blok) kar yigini birakmaz. Yeti sikisirsa/duvarin icine girerse etrafindaki bloklari kirar (gerekirse oyuncunun arkasina isinlanir).
- Yere vurma: 8 sn'de bir yeti ~0.7 sn hazirlanir, oyuncuya dogru duz giden sok dalgasi cikar (24 blok, 2 kalp hasar, ziplayinca/yana kacinca kurtulur). Kovalamaca hizi 0.25 -> 0.30.

## Su Isiticisi (water_heater) + Pil (battery)
- Tarif: `GBG / _P_ / _C_` (G=cam, B=su kovasi, P=piston, C=bakir). Pil: redstone / bakir / redstone (dikey).
- Suyun YANINDAKI bloga konur (suyun icine konmaz), baktigin yone ufler. Sag tik: pil takar; bos elle: bitmis pilleri alir, yoksa menu acar (solda isi 0-15, sagda 3 pil yuvasi).
- Isi arttikca yaricap (3-8) ve saniyede eriyen buz sayisi artar; pil tuketimi 1-5: 1/sn, 6-10: 3/sn, 11-15: 9/sn (pil kapasitesi 1200). Calisirken bolge yeniden donmaz. Ayarlar: `WaterHeaterBlockEntity`, `BatteryItem.CAPACITY`.
- Kis basladiktan sonra (4. gun) acik havada 1 dk kalirsa DONAR ve bozulur (dokusu degisir, kendisi dusmez, pilleri duser). Kapali alanda bozulmaz.

## Cay calisi + Cilek calisi
- Cay artik yapraktan craft edilmez (tarif kaldirildi). Cay calisi (orman/tayga) sag tikla 1-2 cay yapragi + 1 tohum verir; tohum toprak/cimene ekilir, calı 10 dk'da yeniden buyur.
- Cilek calisi (ova/orman): bazilari bos, bazilari meyveli. Sag tik 1-2 cilek. 5. gunden sonra meyveler donar -> Donmus Cilek (aclik + %5 soguk). Cilek eldeyken zemine sag tik calı eker.
- Calilar kar altinda ezilmez. Dunya uretimi (biome modifier) sadece YENI olusan chunk'larda calisir; eski dunyada /give ile test et. Sabitler: `FruitBushBlock` (REGROW_TICKS, FREEZE_DAY), `FrozenStrawberryItem.COLD_ADDED`.

## Donmus yaratiklar (12. gunden sonra)
- 12. gunden sonra ACIK HAVADA dogan zombi, iskelet, orumcek, creeper, koyun, inek, domuz, tavuk donmus dogar (mavimsi ton + buz dokusu katmani, `FrostLayer`). Madende / kapali yerde doganlar normal. Eskiden var olan yaratiklar etkilenmez.
- Donmus yaratik oldugunde dusurdukleri esyalar donmus surumu olur (ayni sans/miktar): zombi eti, kemik, ok, yay, cig etler, deri, tuy, ip, orumcek gozu, barut. Esya modelleri vanilla dokunun ustune buz katmani koyar (`frozen_*.json`).
- Donmus esyalar ocakta/firinda eritilince normal haline doner (etler pismis ete doner). Donmus et yenebilir (cig et degerleriyle).
- Sinir: koyunun yunu normal kalir (ayri katman), bu yuzden koyun daha az buzlu gorunur.

## Buz sarkiti (icicle)
- Yeryuzunde tavan/yaprak altlarinda (agac, kayalik cikinti) dogal olusur. Dayanagi kirilirsa ya da ok carparsa duser; dusme hasari vanilla sarkitla ayni (mesafe basina >=6, en fazla 40). Dustugunde kirilir ve esya birakir. Dunya uretimi sadece yeni chunk'larda; test icin `/give @s hollowwinter:icicle`.

## Mamut
- Ozel model (`MammothModel`, kod ile; doku 256x128 `textures/entity/mammoth.png`). 9. gunden sonra acik havada 2-4'lu suru, %25 yavru (yarim boyut). Birbirine saldirmaz; Monster'lara saldirir (yetiler haric: hayalet/kovalamaca yetisine degil); oyuncuya vurulursa suruyla karsilik verir.
- Bugday / tatli meyve / cilek ile beslenip ureyebilir. Drop: kurk (pelt) 1-3, cig et 2-5, kemik 0-2.
- Dogus ayari: `data/hollowwinter/forge/biome_modifier/add_mammoth_spawns.json` (weight, minCount, maxCount); gun: `MammothEntity.SPAWN_DAY`. Test: `/summon hollowwinter:mammoth` ya da yumurta.

## Uyku
- Sunucu acilirken `playersSleepingPercentage` %1 yapilir: tek kisi uyusa gece herkes icin atlanir (uyumayanlar dahil). Degeri `SleepEvents.SLEEP_PERCENT`.

## Mamut dusenleri + Viking Miğferi
- Mamut: kurk 1-3, CIG mamut eti 2-4 (atesteyken pismis duser), mamut kaburga kemigi 1-3 (vanilla kemik yerine).
- Pismis mamut eti 14 aclik (bifteginden 8 fazla); cig 4. Ocak/fuurn/kamp ateşinde pisirilir.
- Viking Miğferi: `B_B / _S_` (B = mamut kaburga kemigi, S = catlak tas tuglasi). Koruma 3 (demir kaski 2), dayaniklilik demir seviyesi. Dokusu `viking_layer_1.png` (boynuzlar duz boyali, ayri 3D boynuz yok).

## Duzeltmeler (son)
- Buz baltasi (ve diger buz aletleri) dokusundaki beyaz arka plan seffaf yapildi.
- Buz sarkitlari 6. gunden sonra olusur (`IcicleGrower`, dunya uretimi kaldirildi).
- Mamut 120 can, hitbox 3.0x4.2, model 1.35x buyuk.
- Su isiticisi suyun ICINE konabilir: zemine gomulu ayri model (`water_heater_submerged`), buz yuzeyine dogru yukari tarar. Karada eskisi gibi.
- Donmus cilek calisi kirilinca donmus cilek verir.
- Kar nerf: birikme 8 -> 6 katman/gun, azami 344 -> 280 katman, firtinada hiz 3x -> 2x. Firtina sansi gunluk %25 -> %16.

## El tipi Isi Makinesi pilli
- Pille calisir: 1 pil = 2 dk surekli kullanim, en fazla 2 pil (4 dk). Yeni craft edilen makine BOSTUR. Bosken sag tik: envanterdeki en fazla 2 dolu pil otomatik takilir. Sabitler: `HeaterItem.TICKS_PER_BATTERY`.

## Otomatik Maden Makinesi (miner) + Matkap Ucu (drill_bit)
- Tarifler: Matkap ucu `CCC / _G_` (C=catlak tas tuglasi, G=altin kulcesi). Makine `OOO / GDG / SSS` (O=obsidyen, G=cam, D=matkap ucu, S=tas).
- Sag tik: kontrol paneli (hedef derinlik -10/-1/+1/+10/Bedrock, Baslat, Geri cagir). Cikis agzi (bakir boru ucu) oyuncuya bakar; oraya sandik/envanter konursa maden dolar, yoksa onune firlatir, sandik doluysa makine bekler.
- Iniste 3x3 katman katman kazar (toprak ~0.2 sn, tas 1 sn, sert kaya/maden 3 sn, obsidyen 5 sn / katman), bedrock veya hedef derinlige gelince yukari cikar ve BOSTA bekler (elle tekrar baslatilir). Ayarlar: `MinerBlockEntity` basindaki sabitler.
- Matkap ucu ve mil `BlockEntityRenderer` ile cizilir (`MinerRenderer`, `DrillModel`), donus + yumusak inis/cikis. Enerji/yakit gerekmez.
- Maden makinesi: kirilan 3x3 katmanin tum esyalari boruyla cikis agzina gider (boruda parcacik/ses efekti); agzin onundeki sandik/envantere dolar.

## Benzin (maden makinesi yakıtı)
- Mağaralarda (y<0) benzin gölleri çıkar (sadece yeni chunklarda). Kova ile ya da boş benzin kutusuyla alınır.
- Boş benzin kutusu: `INI / I I / III` (I=demir külçe, N=demir parçası). Sağ tık ile benzin kaynağından dolar.
- Dolu kutuya makineye sağ tıkla = 1000 yakıt. Depo 4000, her katman 5 yakıt. Yakıt bitince makine yukarı çıkar.
- Test: `/give @s hollowwinter:gas_can_full`. Dünya açılmazsa `add_gasoline_lakes.json` dosyasını sil.
- Ayarlar: `MinerBlockEntity.MAX_FUEL`, `FUEL_PER_LAYER`, `GasCanItem.FUEL_UNITS`, göl sıklığı: placed_feature `rarity_filter`.

## Mamut cesedi
- Yeni chunklarda nadir çıkar (rarity 200, `placed_feature/mammoth_carcass.json`). Test: `/give @s hollowwinter:mammoth_carcass`.
- Kırılınca kaburga, post, kemik düşer. Dünya açılmazsa `add_mammoth_carcass.json` dosyasını sil.

## Yapılar (schematic)
- `camp` (kamp, 1 sandık), `house` (ev, çift tuzaklı sandık), `woodcutter_house` (oduncu evi, sandıksız). Dosyalar: `data/hollowwinter/structures/*.nbt`.
- Ganimet: `loot_tables/chests/camp.json`, `house.json`. Sıklık: `worldgen/structure_set/*.json` (spacing).
- Biyomlar: `tags/worldgen/biome/has_winter_structures.json`. Yeni chunklarda çıkar. Test: `/locate structure hollowwinter:camp`.
- Dünya açılmazsa `worldgen/structure_set` altındaki dosyaları sil.

## Penguen
- 5. günden sonra buzlu biyomlarda (snowy_plains, ice_spikes, frozen_river/ocean, snowy_beach) 3-8'lik gruplar. Buz üstünde yüz üstü kayar. Hiçbir şey düşürmez. Morina/somonla beslenip ürer.
- Test: `/give @s hollowwinter:penguin_spawn_egg`. Ayar: `add_penguin_spawns.json`, `PenguinEntity.SPAWN_DAY`, kayma hızı `SlideGoal.speed`.

## Penguen evcilleştirme, kızak, ısıtıcı yönü
- Penguene morina/somon ver: %33 şansla evcilleşir. Evcil penguen sahibini takip eder, boş elle sağ tık = otur/kalk, balık = can/üreme.
- Kızak: `PPP / S_S / III` (P=tahta, S=sopa, I=demir). Yere koy, sağ tıkla bin; W/A/D ile sür, karda/buzda kayar, çimde yavaş. İki kişilik. Hız: `SledEntity.getGroundFriction`.
- El ısıtıcısı artık bakılan yöne (yukarı/aşağı dahil) tünel açar.
- Kızağa fener/meşale: elinde tutup kızağa sağ tık → gittiği yeri aydınlatır. El ısıtıcısı: aynı şekilde takılır, önünü eritir (pil gerekir; ısıtıcı takılıyken pille sağ tık = şarj). Çıkarmak: eğilip boş elle sağ tık.

## Baykuş
- Geceleri orman/tayga ağaç yapraklarının üstünde çıkar, oyuncuya dikilip bakar. 3.5 blok yaklaşırsan, vurulursan ya da sabah olursa uçup gider. 6. günden sonra "donmuş" (buz mavisi, parlayan gözler) doğar. Drop: tüy (donmuşsa donmuş tüy).
- Test: `/give @s hollowwinter:owl_spawn_egg`. Ayar: `add_owl_spawns_*.json`, `OwlEntity.FROZEN_DAY`.


## Atmosfer (5.1.0)
- Fırtına sisi: `FogHandler.STORM_FOG_FAR` = 8 blok.
- Uzak sesler (kış başlayınca, açık havada): uluma, ağaç çatırdaması, kar çökmesi, uzaktan ayak sesleri, tilki çığlığı. Sıklık: `AtmosphereEvents.onPlayerTick`.
- Gölge figür (orman/tayga, gece ya da fırtına): uzakta siyah siluet, sana bakar; doğrudan bakarsan / 14 blok yaklaşırsan / vurursan / 40 sn sonra kaybolur.
- Test: `/hollowwinter distant`, `/hollowwinter shadow` (op).
- Sessiz günler: kış başlayınca günlerin %35'i "sessiz gün" (dünya tohumuna bağlı, fırtına yoksa). O gün uzak sesler ve yeti ortam sesleri çalmaz, sadece çok hafif rüzgar (`calm_wind.ogg`) duyulur. Oran: `AtmosphereEvents.isSilentDay` içindeki `< 35`.
- Ayak izi (yeniden yazıldı): karda yürüyen oyuncular ve yeti, sağ-sol dönüşümlü kare ayak izi bırakır (sadece görsel, kar katmanı artık çökmez). Yeti izi ~2.4 kat büyük ve daha uzun kalır. Kod: `client/ClientFootprints.java`, `FootprintParticle.java`; texture `textures/particle/footprint.png`.

## Yeti avi (5.1.0)
- `event/YetiHunt`: 6. günden sonra gece/fırtınada açık havadaki oyuncuyu her 4-8 dk'da (fırtınada 2-4 dk) yeti avlar. %50 pusu (7-10 blok yakında kardan fırlar), %50 takip (34-42 blok uzaktan yürür). Gerçek düşman: 6 hasar, canı %50 altına inerse kaçar (6 dk sonra tekrar), 3 dk/sabah/90 blok uzaklaşma sonunda kaybolur. Sessiz günde av yok.
- Yeti yakınken (30 blok) kalp atışı sesi, 18 blok içinde Darkness efekti (ekran kararır).
- Yeti (normal/kovalayıcı/av) 4 blok çevresindeki meşaleleri ve yanan kamp ateşlerini tek tek söndürür (mobGriefing kapalıysa yapmaz).
- Kovalamaca şansı 0.25 -> 0.4, sabah izleme 0.35 -> 0.5.
- Test: `/hollowwinter hunt` (takip), `/hollowwinter hunt ambush` (pusu). Ayarlar: YetiHunt üstündeki sabitler.
