package com.hollowwinter.mod.item;

import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Tiers;

/** Buz capa: ozel gucu yok. */
public class IceHoeItem extends HoeItem implements IceTool {
    public IceHoeItem(Properties properties) {
        super(Tiers.IRON, -2, -1.0F, properties.durability(180));
    }
}
