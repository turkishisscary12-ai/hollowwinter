package com.hollowwinter.mod.cold;

import com.hollowwinter.mod.HollowWinter;
import com.hollowwinter.mod.item.FurArmorItem;
import com.hollowwinter.mod.network.ColdSyncPacket;
import com.hollowwinter.mod.network.ModNetwork;
import com.hollowwinter.mod.winter.WinterManager;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Hollow Winter - Temel soguk sistemi.
 * Her saniye oyuncunun "soguk" degeri (0-100) guncellenir:
 *  - Dunya surekli donuk: taban olarak soguk artar.
 *  - Gece, yagis/kar, aciktaki alan ve suda soguk daha hizli artar.
 *  - Deri zirh ve kapali alan soguklugu yavaslatir.
 *  - Yakinda yanan ates/ocak/lav varsa soguk hizla duser.
 * Degerler yuksekse yavaslama, kazma yorgunlugu ve donma hasari gelir.
 */
@Mod.EventBusSubscriber(modid = HollowWinter.MODID)
public class ColdHandler {

    private static final String COLD_KEY = "hollowwinter_cold";
    private static final String WARM_KEY = "hollowwinter_warm_until";
    private static final float MAX_COLD = 100.0F;
    private static final int HEAT_RADIUS = 4;

    /** Disaridan (yeti vurusu, kar topu vb.) oyuncunun soguk degerine ekleme yapar ve HUD'a bildirir. */
    public static void addCold(ServerPlayer player, float amount) {
        CompoundTag data = player.getPersistentData();
        float cold = Math.max(0.0F, Math.min(MAX_COLD, data.getFloat(COLD_KEY) + amount));
        data.putFloat(COLD_KEY, cold);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new ColdSyncPacket(cold, amount >= 0.0F ? 1.0F : -1.0F));
    }

    /** Verilen sure (tick) boyunca soguk artmaz ve donma hasari gelmez (sicak icecek). */
    public static void grantWarmth(ServerPlayer player, int ticks) {
        player.getPersistentData().putLong(WARM_KEY, player.level().getGameTime() + ticks);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.isCreative() || player.isSpectator()) return;
        if (player.tickCount % 20 != 0) return; // saniyede bir

        ServerLevel level = player.serverLevel();
        CompoundTag data = player.getPersistentData();
        float cold = data.getFloat(COLD_KEY);

        boolean winter = WinterManager.hasWinterStarted(level);
        boolean canSeeSky = level.canSeeSky(player.blockPosition());

        // Kis baslamadan once soguk neredeyse yok (oyuncuya zaman taniyoruz)
        float change = winter ? 1.0F : -0.2F;

        if (winter) {
            if (level.isNight()) change += 0.5F;
            if (canSeeSky && level.isRaining()) change += 1.0F;
            if (!canSeeSky) change -= 0.3F; // siginak
        }
        if (player.isInWater()) change += 3.0F;

        change -= coldProtection(player);

        boolean warm = data.getLong(WARM_KEY) > level.getGameTime();

        if (isNearHeat(level, player.blockPosition())) {
            change = -5.0F;
        }

        if (warm) change = Math.min(change, 0.0F);

        cold = Math.max(0.0F, Math.min(MAX_COLD, cold + change));
        data.putFloat(COLD_KEY, cold);

        applyEffects(player, cold, warm);

        // HUD icin istemciye gonder (bar + yuzde + ok). Pozitif egilim = soguyor, negatif = isiniyor.
        // Bar zaten bossa "isiniyor" oku gostermeye gerek yok.
        float trend = (cold <= 0.0F && change <= 0.0F) ? 0.0F : change;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new ColdSyncPacket(cold, trend));
    }

    /**
     * Zirhlarin soguk korumasi (saniyedeki soguk artisindan dusulur).
     * Deri: parca basi 0.2 | Kurk: parca basi 0.5, tam set (4 parca) +0.5 bonus.
     * Tam kurk set = 2.5 koruma -> kis tabani (1.0) ve gece/yagis cezasini rahatca karsilar.
     */
    private static float coldProtection(ServerPlayer player) {
        float protection = 0.0F;
        int furPieces = 0;
        for (ItemStack stack : player.getArmorSlots()) {
            if (stack.getItem() instanceof FurArmorItem) {
                protection += 0.5F;
                furPieces++;
            } else if (stack.getItem() instanceof ArmorItem armor
                    && armor.getMaterial() == ArmorMaterials.LEATHER) {
                protection += 0.2F;
            }
        }
        if (furPieces == 4) protection += 0.5F;
        return protection;
    }

    private static boolean isNearHeat(ServerLevel level, BlockPos center) {
        for (BlockPos pos : BlockPos.betweenClosed(
                center.offset(-HEAT_RADIUS, -2, -HEAT_RADIUS),
                center.offset(HEAT_RADIUS, 2, HEAT_RADIUS))) {
            if (isHeatSource(level.getBlockState(pos))) return true;
        }
        return false;
    }

    private static boolean isHeatSource(BlockState state) {
        if (state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
                || state.is(Blocks.LAVA) || state.is(Blocks.MAGMA_BLOCK)) {
            return true;
        }
        if (state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE)
                || state.is(Blocks.FURNACE) || state.is(Blocks.BLAST_FURNACE)
                || state.is(Blocks.SMOKER)) {
            return state.getValue(BlockStateProperties.LIT);
        }
        return false;
    }

    private static void applyEffects(ServerPlayer player, float cold, boolean warm) {
        if (cold >= 50.0F) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
        }
        if (cold >= 80.0F) {
            player.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 60, 0, false, false));
        }
        // Donma hasari (zirh saymaz, "donarak oldu" mesaji cikar):
        //  - %90 ve ustu : 4 saniyede bir 1 can (yarim kalp)
        //  - %100        : her saniye 1 can (yarim kalp)
        if (warm) return;
        if (cold >= MAX_COLD) {
            player.hurt(player.damageSources().freeze(), 1.0F);
        } else if (cold >= 90.0F && player.tickCount % 80 == 0) {
            player.hurt(player.damageSources().freeze(), 1.0F);
        }
    }
}
