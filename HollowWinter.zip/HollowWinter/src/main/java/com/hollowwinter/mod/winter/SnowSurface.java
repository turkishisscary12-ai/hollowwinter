package com.hollowwinter.mod.winter;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/** Kalin kar icinde, yuzeyin ustunde ayakta durulacak noktayi bulur (yeti dogurmak icin). */
public final class SnowSurface {
    private SnowSurface() {}

    /**
     * Verilen x,z sutununda kar yuzeyinin ustundeki noktayi doner.
     * Alan yuklu degilse ya da agac yapraginin ustundeyse null doner.
     */
    @Nullable
    public static Vec3 standPos(ServerLevel level, double x, double z) {
        BlockPos column = BlockPos.containing(x, 0, z);
        if (!level.hasChunkAt(column)) return null;

        // Kar katmanlari hareketi engellemedigi icin heightmap zemini (kar yiginin altini) gosterir.
        BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, column);
        BlockState state = level.getBlockState(pos);
        boolean snowy = false;

        for (int guard = 0; state.is(Blocks.SNOW) && guard < 700; guard++) {
            snowy = true;
            int layers = state.getValue(SnowLayerBlock.LAYERS);
            if (layers < 8) {
                // Kismen dolu son katman: oyuncu bu katmanin carpisma yuksekliginin ustunde durur.
                return new Vec3(x, pos.getY() + (layers - 1) * 0.125, z);
            }
            pos = pos.above();
            state = level.getBlockState(pos);
        }

        if (!snowy && level.getBlockState(pos.below()).is(BlockTags.LEAVES)) return null;
        return new Vec3(x, pos.getY(), z);
    }

    /**
     * Konum acik havada mi (ustunde cati/blok yok)? Kar katmanlari sayilmaz; kalin kar skylight'i
     * kestigi icin canSeeSky yerine heightmap kullanilir.
     */
    public static boolean exposed(ServerLevel level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return false;
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, pos);
        return top.getY() <= pos.getY() + 1;
    }

    /**
     * Kar yigininin ALTINDAKI zemin (kar silinirse ayakta durulacak nokta). Su, lav ya da yaprak ustu ise null.
     */
    @Nullable
    public static Vec3 groundPos(ServerLevel level, double x, double z) {
        BlockPos column = BlockPos.containing(x, 0, z);
        if (!level.hasChunkAt(column)) return null;
        BlockPos pos = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, column);
        if (!level.getFluidState(pos).isEmpty() || !level.getFluidState(pos.below()).isEmpty()) return null;
        if (level.getBlockState(pos.below()).is(BlockTags.LEAVES)) return null;
        return new Vec3(x, pos.getY(), z);
    }
}
